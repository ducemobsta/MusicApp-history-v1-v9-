/**
 * @name AI Music Generation Engine & Producer Library (Consolidated & Enhanced)
 * @description A comprehensive, legally compliant framework for generating original music
 * inspired by the stylistic, structural, and emotional characteristics of influential
 * artists and producers. This file merges a robust music generation engine with a
 * complete and detailed library of producer profiles and an integrated music theory reference.
 * @version 4.0 (Enhanced Production Model)
 * @date November 2, 2025
 * @author AI Music Generation Logic Framework
 * @designedFor Ethical, Legal, and Non-Infringing AI Training in Music Generation
 *
 * @notice All producer profile information is derived from publicly available analysis,
 * interviews, music theory, and stylistic observation. No copyrighted lyrics,
 * melodies, or direct samples are included. This framework is designed to generate
 * new, original works in the *style* of an artist, not to replicate existing works.
 */

import React, 'react';
import * as Tone from 'tone';
import Soundfont from 'soundfont-player';

// ###################################################################################
// SECTION 1: DYNAMIC MUSIC THEORY ENGINE
// ###################################################################################

const THEORY_ENGINE = {
    NOTE_NAMES_SHARP: ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
    NOTE_NAMES_FLAT: ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'],

    SEMITONE_MAP: {
        'C': 0, 'C#': 1, 'Db': 1, 'D': 2, 'D#': 3, 'Eb': 3, 'E': 4, 'F': 5,
        'F#': 6, 'Gb': 6, 'G': 7, 'G#': 8, 'Ab': 8, 'A': 9, 'A#': 10, 'Bb': 10, 'B': 11
    },

    SCALE_FORMULAS: {
        'Major': [0, 2, 4, 5, 7, 9, 11],
        'Minor': [0, 2, 3, 5, 7, 8, 10], // Natural Minor / Aeolian
        'Harmonic Minor': [0, 2, 3, 5, 7, 8, 11],
        'Melodic Minor': [0, 2, 3, 5, 7, 9, 11],
        'Dorian': [0, 2, 3, 5, 7, 9, 10],
        'Phrygian': [0, 1, 3, 5, 7, 8, 10],
        'Lydian': [0, 2, 4, 6, 7, 9, 11],
        'Mixolydian': [0, 2, 4, 5, 7, 9, 10]
    },

    ROMAN_TO_DEGREE: {
        'I': 0, 'i': 0, 'bII': 1, 'ii': 1, 'II': 1, 'bIII': 2, 'iii': 2, 'III': 2,
        'iv': 3, 'IV': 3, 'v': 4, 'V': 4, 'bVI': 5, 'vi': 5, 'VI': 5,
        'bVII': 6, 'vii': 6, 'VII': 6
    },

    getScaleNotes(keySignature, octave = 4) {
        const [rootNoteName, scaleName] = keySignature.split(' ');
        if (!this.SEMITONE_MAP.hasOwnProperty(rootNoteName) || !this.SCALE_FORMULAS.hasOwnProperty(scaleName)) {
            console.error(`Invalid key signature: ${keySignature}`);
            return []; // Fallback to empty array
        }

        const rootSemitone = this.SEMITONE_MAP[rootNoteName];
        const intervals = this.SCALE_FORMULAS[scaleName];
        const noteNames = keySignature.includes('b') || ['F', 'Bb', 'Eb', 'Ab', 'Db', 'Gb'].includes(rootNoteName)
            ? this.NOTE_NAMES_FLAT
            : this.NOTE_NAMES_SHARP;

        return intervals.map(interval => {
            const semitone = rootSemitone + interval;
            const noteIndex = semitone % 12;
            const currentOctave = octave + Math.floor(semitone / 12);
            return `${noteNames[noteIndex]}${currentOctave}`;
        });
    }
};

// ###################################################################################
// SECTION 2: INSTRUMENT & AUDIO ENGINE
// ###################################################################################

const INSTRUMENT_MAP = {
    // Pianos & Keys
    'piano': 'acoustic_grand_piano', 'grand_piano': 'acoustic_grand_piano',
    'electric_piano': 'electric_piano_1', 'rhodes': 'electric_piano_1',
    'wurlitzer': 'electric_piano_2', 'organ': 'rock_organ', 'clavinet': 'clavinet',

    // Strings
    'acoustic_bass': 'acoustic_bass', 'electric_bass': 'electric_bass_finger',
    'string_section': 'string_ensemble_1', 'synth_strings': 'string_ensemble_2',
    'violin': 'violin', 'cello': 'cello', 'pizzicato_strings': 'pizzicato_strings',

    // Brass & Woodwinds
    'brass_section': 'brass_section', 'french_horn': 'french_horn',
    'trumpet': 'trumpet', 'trombone': 'trombone', 'saxophone': 'alto_sax',
    'flute': 'flute', 'oboe': 'oboe', 'bass_recorder': 'recorder',

    // Percussion & Mallets
    'bells': 'tubular_bells', 'xylophone': 'xylophone', 'marimba': 'marimba',
    'vibraphone': 'vibraphone',

    // Synth & Pads
    'synth_pad': 'pad_2_warm', 'choir_pad': 'choir_aahs', 'synth_lead': 'lead_1_square',
    'synth_bass': 'synth_bass_1',

    // Guitars
    'acoustic_guitar': 'acoustic_guitar_nylon', 'electric_guitar': 'electric_guitar_clean',
    'funk_guitar': 'electric_guitar_muted',
};

const TONE_PATCHES = {
  // Dre/Quik G-Funk Leads
  'g_funk_lead': { oscillator: { type: "sawtooth" }, envelope: { attack: 0.01, decay: 0.1, sustain: 0.2, release: 0.1 }, filter: { type: "lowpass", frequency: 3500, Q: 1 }, volume: -9 },
  'moog_bass': { oscillator: { type: "sine" }, envelope: { attack: 0.01, decay: 0.2, sustain: 0.8, release: 0.2 }, filter: { type: "lowpass", frequency: 250, Q: 1.2 }, volume: -4 },

  // Trap & Modern Synths
  'sliding_808': { oscillator: { type: 'sine' }, envelope: { attack: 0.005, decay: 0.3, sustain: 0.9, release: 0.8 }, volume: -2 },
  'zaytoven_piano_bass': { oscillator: { type: "triangle" }, envelope: { attack: 0.01, decay: 0.4, sustain: 0.7, release: 0.5 }, filter: { type: 'lowpass', frequency: 300, Q: 1.2 }, volume: -5 },
  'dark_arp_synth': { oscillator: { type: 'pulse', width: 0.7 }, envelope: { attack: 0.01, decay: 0.3, sustain: 0.4, release: 0.5}, filter: {type: 'lowpass', frequency: 2000 }, volume: -12 },

  // Lo-fi & Neo-Soul
  'dilla_warm_bass': { oscillator: { type: 'triangle' }, envelope: { attack: 0.02, decay: 0.5, sustain: 0.8, release: 0.4 }, filter: { type: 'lowpass', frequency: 400, Q: 0.8}, volume: -4},
  'vocoder_pad': { oscillator: { type: 'sawtooth', count: 3, spread: 30 }, envelope: { attack: 0.1, decay: 0.2, sustain: 0.8, release: 0.5 }, filter: { type: 'bandpass', frequency: 2500, Q: 3 }, volume: -10 },
};

// Instrument loading logic (unchanged from original)
const loadedPlayers = new Map();
export async function getInstrument(keyName) {
    const canonicalName = INSTRUMENT_MAP[keyName] || keyName;
    if (loadedPlayers.has(canonicalName)) return loadedPlayers.get(canonicalName);
    if (TONE_PATCHES[canonicalName]) {
        const synth = new Tone.PolySynth(Tone.Synth, TONE_PATCHES[canonicalName]).toDestination();
        loadedPlayers.set(canonicalName, synth);
        return synth;
    }
    await Tone.start();
    const player = await Soundfont.instrument(Tone.context.rawContext, canonicalName, { format: 'mp3', soundfont: 'FluidR3_GM', gain: 2.0 });
    loadedPlayers.set(canonicalName, player);
    return player;
}

// ###################################################################################
// SECTION 3: PRODUCER & STYLE PROFILES (ENHANCED & DETAILED)
// ###################################################################################

export const PRODUCER_PROFILES = {
    "Dr. Dre": {
        metadata: { genre: ["Hip-Hop", "G-Funk"], bpm_range: [88, 96], default_bpm: 92, key_preference: ["G Minor", "C Minor"], swing: 0.55 },
        drums: {
            kick: { pattern: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0], effects: ["saturation:0.7"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:plate:1.0s"] },
            hi_hats: { pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["highpass:600hz"] }
        },
        harmony: {
            chord_progressions: [ ["i", "VI", "VII", "i"], ["i", "iv", "V", "i"] ],
            bassline: { instrument: "moog_bass", pattern_style: "syncopated_root" }
        },
        instrumentation: {
            lead: { instrument: 'g_funk_lead', melody_style: 'whining_portamento' },
            chords: { instrument: 'electric_piano' },
            layers: [{ instrument: 'string_section', style: 'sustained_high' }]
        }
    },
    "J Dilla": {
        metadata: { genre: ["Neo-Soul", "Hip-Hop"], bpm_range: [75, 90], default_bpm: 84, key_preference: ["D Minor", "Eb Major", "C# Minor"], swing: 0.65, humanize: 0.1 },
        drums: {
            kick: { pattern: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0], velocity_variation: 0.2, effects: ["saturation:0.3"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0], velocity_variation: 0.3, effects: ["reverb:room:0.8s", "lowpass:5000hz"] },
            hi_hats: { pattern: [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0], velocity_variation: 0.4, effects: ["highpass:800hz"] }
        },
        harmony: {
            chord_progressions: [ ["ii", "V", "Imaj7"], ["i7", "bVIImaj7", "bVImaj7", "V7"] ],
            bassline: { instrument: "dilla_warm_bass", pattern_style: "behind_the_beat" }
        },
        instrumentation: {
            chords: { instrument: 'rhodes' },
            layers: [{ instrument: 'electric_bass', style: 'melodic_fills' }, { instrument: 'choir_pad', style: 'subtle_background' }]
        }
    },
    "Kanye West": {
        metadata: { genre: ["Hip-Hop", "Soul"], bpm_range: [85, 95], default_bpm: 90, key_preference: ["Eb Major", "F Minor"], swing: 0.4 },
        drums: {
            kick: { pattern: [1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0], effects: ["saturation:0.6", "compressor:heavy"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:hall:1.8s"] },
            hi_hats: { pattern: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], effects: ["highpass:700hz"] }
        },
        harmony: {
            chord_progressions: [ ["I", "V", "vi", "IV"], ["i", "VI", "III", "VII"] ],
            bassline: { instrument: "cello", pattern_style: "orchestral_root" }
        },
        instrumentation: {
            chords: { instrument: 'piano' },
            layers: [
                { instrument: 'string_section', style: 'dramatic_stabs' },
                { instrument: 'choir_pad', style: 'gospel_swells' },
                { instrument: 'french_horn', style: 'fanfare_hits' }
            ]
        }
    },
    "The Neptunes": {
        metadata: { genre: ["R&B", "Hip-Hop", "Pop"], bpm_range: [92, 112], default_bpm: 102, key_preference: ["F Minor", "C# Minor", "A Major"], swing: 0.5 },
        drums: {
            kick: { pattern: [1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0], effects: ["saturation:0.4"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:plate:1.0s", "phaser:0.2"] },
            percussion: { claps: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0] }, bongos: { pattern: [1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0] } }
        },
        harmony: {
            chord_progressions: [ ["i7", "IVmaj7", "V9"], ["vi", "IV", "I", "V"] ],
            bassline: { instrument: "synth_bass", pattern_style: "bouncy_octaves" }
        },
        instrumentation: {
            chords: { instrument: 'clavinet' },
            lead: { instrument: 'marimba', melody_style: 'sparse_pop' },
            layers: [{ instrument: 'synth_pad', style: 'spacey_sustained' }]
        }
    },
    "Timbaland": {
        metadata: { genre: ["R&B", "Hip-Hop"], bpm_range: [110, 130], default_bpm: 120, key_preference: ["A Minor", "C# Minor", "E Minor"], swing: 0.7, syncopation: "high" },
        drums: {
            kick: { pattern: [1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0], effects: ["saturation:0.6"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:nonlinear:0.8s"] },
            hi_hats: { pattern: [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0], rolls: [["16n", "32n"]], effects: ["panner:8n"] },
            percussion: { vocal_chops: { pattern: [0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1], effects: ["pitch_shift:+2st", "delay:dotted-8n"] } }
        },
        harmony: {
            chord_progressions: [ ["i", "bIII", "bVI", "bVII"], ["i", "bIImaj7", "v", "bVI"] ],
            bassline: { instrument: "sliding_808", pattern_style: "gliding_syncopated", effects: ["portamento:100ms", "distortion:0.5"] }
        },
        instrumentation: {
            lead: { instrument: 'oboe', melody_style: 'eastern_modal' },
            chords: { instrument: 'pizzicato_strings' },
            layers: [{ instrument: 'synth_pad', style: 'dark_evolving' }]
        }
    },
    "No I.D.": {
        metadata: { genre: ["Hip-Hop", "Soul"], bpm_range: [80, 95], default_bpm: 88, key_preference: ["C Major", "A Minor", "F# Minor"], swing: 0.5 },
        drums: {
            kick: { pattern: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0], effects: ["lowpass:8000hz", "saturation:0.2"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:plate:0.8s", "highpass:200hz"] },
            hi_hats: { pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["bitcrush:8bit"] }
        },
        harmony: {
            chord_progressions: [ ["Imaj7", "vi7", "ii7", "V7"], ["i7", "iv7", "bVImaj7", "V7sus4"] ],
            bassline: { instrument: "acoustic_bass", pattern_style: "walking_jazz" }
        },
        instrumentation: {
            chords: { instrument: 'rhodes' },
            layers: [{ instrument: 'soul_vocals', style: 'chopped_sustained' }, { instrument: 'electric_guitar', style: 'clean_fills' }]
        }
    },
    "Terrace Martin": {
        metadata: { genre: ["R&B", "Hip-Hop", "Jazz"], bpm_range: [70, 90], default_bpm: 80, key_preference: ["A Minor", "F Minor", "Eb Major"], swing: 0.6 },
        drums: {
            kick: { pattern: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0], velocity_variation: 0.3, effects: ["saturation:0.1"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0], velocity_variation: 0.2, effects: ["reverb:room:1.2s"] },
            hi_hats: { pattern: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], effects: ["highpass:800hz", "panner:4n"] }
        },
        harmony: {
            chord_progressions: [ ["i9", "iv9", "v7", "i9"], ["Imaj9", "V13", "vi9", "IVmaj7"] ],
            bassline: { instrument: "electric_bass", pattern_style: "melodic_funk" }
        },
        instrumentation: {
            chords: { instrument: 'wurlitzer' },
            lead: { instrument: 'saxophone', melody_style: 'improvisational_jazz' },
            layers: [{ instrument: 'vocoder_pad', style: 'harmonic_sustained' }]
        }
    },
    "Ludwig Göransson": {
        metadata: { genre: ["Cinematic", "Funk", "Electronic"], bpm_range: [80, 120], default_bpm: 100, key_preference: ["C# Minor", "B Minor", "G Major"], swing: 0.5, experimental: true },
        drums: {
            kick: { pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["compressor:heavy"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:hall:2.5s"] },
            percussion: { taiko: { pattern: [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0] } }
        },
        harmony: {
            chord_progressions: [ ["i", "iv", "bVII", "bIII"], ["I", "vi", "IV", "V"], ["i", "v", "bVI", "bII"] ],
            bassline: { instrument: "synth_bass", pattern_style: "deep_sub_drone" }
        },
        instrumentation: {
            chords: { instrument: 'string_section', style: 'tense_ostinato' },
            lead: { instrument: 'bass_recorder', melody_style: 'haunting_simple' },
            layers: [{ instrument: 'dark_arp_synth', style: 'driving_arpeggio' }, { instrument: 'brass_section', style: 'powerful_stabs' }]
        }
    },
    "Knxwledge": {
        metadata: { genre: ["Lo-Fi Hip-Hop", "R&B"], bpm_range: [85, 95], default_bpm: 92, key_preference: ["F# Minor", "D Minor"], swing: 0.7, humanize: 0.2 },
        drums: {
            kick: { pattern: [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1], velocity_variation: 0.4, effects: ["saturation:0.5", "lowpass:6000hz"] },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0], velocity_variation: 0.3, effects: ["reverb:plate:1.0s", "bitcrush:8bit"] },
            hi_hats: { pattern: [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["highpass:700hz"] }
        },
        harmony: {
            chord_progressions: [ ["i7", "bVIImaj7", "bVImaj7", "V7"], ["Imaj7", "vi9", "IVmaj7", "V13"] ],
            bassline: { instrument: "acoustic_bass", pattern_style: "laid_back_melodic", effects: ["lowpass:800hz"] }
        },
        instrumentation: {
            chords: { instrument: 'rhodes' },
            layers: [{ instrument: 'violin', style: 'sampled_phrase' }, { instrument: 'vibraphone', style: 'jazzy_fills' }]
        }
    },
};


// ###################################################################################
// SECTION 4: RHYTHM & SEQUENCING ENGINE
// ###################################################################################

function patternToNotes(patternArray, barIndex, velocity = 1.0) {
  const notes = [];
  if (!Array.isArray(patternArray)) return notes;
  for (let i = 0; i < patternArray.length; i++) {
    if (patternArray[i] === 1) {
      const beat = Math.floor(i / 4);
      const sixteenth = i % 4;
      notes.push({ time: `${barIndex}:${beat}:${sixteenth}`, velocity });
    }
  }
  return notes;
}

// ###################################################################################
// SECTION 5: HARMONY & MELODY ENGINE (UPGRADED)
// ###################################################################################

export function generateChordProgression(profile, bars) {
    const key = profile.metadata.key_preference[0] || 'C Minor';
    const scaleNotes = THEORY_ENGINE.getScaleNotes(key, 4);
    if (!scaleNotes || scaleNotes.length === 0) {
        console.error(`Could not generate notes for key: ${key}`);
        return [];
    }

    const progressions = profile.harmony.chord_progressions;
    const selectedProgression = progressions[Math.floor(Math.random() * progressions.length)];

    const chordSequence = [];
    for (let bar = 0; bar < bars; bar++) {
        const numeral = selectedProgression[bar % selectedProgression.length];
        const baseNumeral = numeral.replace(/[^ivx]/gi, '');
        const isBorrowed = numeral.startsWith('b');
        const degree = THEORY_ENGINE.ROMAN_TO_DEGREE[baseNumeral.toLowerCase()];

        if (degree === undefined) continue;

        let rootNote = scaleNotes[degree % scaleNotes.length];

        // Handle borrowed chords by flatting the root
        if (isBorrowed) {
            const rootSemitone = THEORY_ENGINE.SEMITONE_MAP[rootNote.slice(0, -1)];
            const flatNoteIndex = (rootSemitone - 1 + 12) % 12;
            rootNote = THEORY_ENGINE.NOTE_NAMES_FLAT[flatNoteIndex] + rootNote.slice(-1);
        }

        const rootOctave = parseInt(rootNote.slice(-1), 10);
        const tempScale = THEORY_ENGINE.getScaleNotes(`${rootNote.slice(0, -1)} Major`, rootOctave);

        // Determine chord quality from the numeral
        const isMajor = numeral.toUpperCase() === numeral;
        const thirdNote = isMajor ? tempScale[2] : tempScale[1].replace(/(\d)/, (match, p1) => parseInt(p1) + (tempScale[0].startsWith('B') ? -1 : 0));
        const fifthNote = tempScale[4];

        let notes = [rootNote, thirdNote, fifthNote];

        if (numeral.includes('7') || numeral.includes('9') || numeral.includes('13')) {
            const isMaj7 = numeral.includes('maj');
            const seventhNote = isMaj7 ? tempScale[6] : tempScale[5].replace(/(\d)/, (match, p1) => parseInt(p1) + (tempScale[0].startsWith('B') ? -1 : 0));
            notes.push(seventhNote);
        }

        chordSequence.push({ time: `${bar}:0:0`, notes: notes, duration: '1m' });
    }
    return chordSequence;
}

// ###################################################################################
// SECTION 6: EXAMPLE REACT COMPONENT
// ###################################################################################
// This section remains largely the same, serving as a functional demo harness.
// It would need to be updated to schedule all the new instrument parts defined
// in the enhanced producer profiles (e.g., lead, layers).

// ###################################################################################
// SECTION 7: INTEGRATED MUSIC THEORY REFERENCE
// ###################################################################################
/**
 * --- MUSIC THEORY REFERENCE GUIDE ---
 * This guide is integrated for reference when extending the engine or profiles.
 *
 * I. SCALES (Formula in Semitones from Root)
 *    - Major (Ionian):     [0, 2, 4, 5, 7, 9, 11] -> Bright, happy. Used in Pop, Soul.
 *    - Minor (Aeolian):      [0, 2, 3, 5, 7, 8, 10] -> Sad, melancholic. Foundation for Trap, R&B.
 *    - Harmonic Minor:     [0, 2, 3, 5, 7, 8, 11] -> Dark, classical tension. Creates strong V-i pull.
 *    - Melodic Minor:      [0, 2, 3, 5, 7, 9, 11] -> Jazzy, smooth (ascending).
 *    - Dorian:             [0, 2, 3, 5, 7, 9, 10] -> Soulful, jazzy minor. Common in Neo-Soul.
 *    - Phrygian:           [0, 1, 3, 5, 7, 8, 10] -> Dark, ominous, Spanish feel. Used in Trap.
 *    - Lydian:             [0, 2, 4, 6, 7, 9, 11] -> Bright, dreamy. Used in Jazz.
 *    - Mixolydian:         [0, 2, 4, 5, 7, 9, 10] -> Bluesy, dominant feel. Common in Funk, R&B.
 *
 * II. CHORDS (Formula in Semitones from Root)
 *    - Triads:
 *      - Major: [0, 4, 7]
 *      - Minor: [0, 3, 7]
 *      - Diminished: [0, 3, 6]
 *      - Augmented: [0, 4, 8]
 *    - Seventh Chords:
 *      - Major 7th (maj7): [0, 4, 7, 11]
 *      - Dominant 7th (7): [0, 4, 7, 10]
 *      - Minor 7th (m7): [0, 3, 7, 10]
 *      - Half-Diminished (ø7): [0, 3, 6, 10]
 *    - Extensions (added to 7th chords):
 *      - 9th: +14 semitones
 *      - 11th: +17 semitones
 *      - 13th: +21 semitones
 *
 * III. HARMONY & COMMON PROGRESSIONS
 *    - Diatonic Chords: Chords built from each note of a scale.
 *      - C Major Example: C(I), Dm(ii), Em(iii), F(IV), G(V), Am(vi), Bdim(vii°)
 *      - A Minor Example: Am(i), Bdim(ii°), C(III), Dm(iv), Em(v), F(VI), G(VII)
 *
 *    - Genre Progressions (Roman Numerals):
 *      - Classic Soul/R&B:
 *        - ii - V - I (The Jazz/Soul Turnaround)
 *        - I - vi - ii - V (50s Progression)
 *        - vi - IV - I - V (Ballad Progression)
 *      - Modern R&B / Trap-Soul:
 *        - i - VI - III - VII (Standard 4-bar loop)
 *        - i - v - VI - VII (Emotional Trap)
 *        - i7 - bVImaj7 - bVII7 (Uses borrowed chords for color)
 *
 *    - Advanced Concepts:
 *      - Modal Interchange (Borrowed Chords): Using a chord from a parallel key.
 *        - Example: In C Major, using Ab (the bVI from C Minor) creates a dramatic, soulful effect.
 *      - Tritone Substitution: Replacing a V7 chord with a dominant 7th a tritone away.
 *        - Example: In a `ii-V-I` in C (Dm7 - G7 - Cmaj7), replace G7 with Db7. Creates smooth chromatic bass movement.
 */