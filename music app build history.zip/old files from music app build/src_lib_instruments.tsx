// src/lib/instruments.ts

import * as Tone from 'tone';
// Note: You need to install soundfont-player: npm install soundfont-player
import Soundfont, { Player } from 'soundfont-player';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';


// --- CONFIGURATION ---
// Configuration for the public SoundFont CDN
const SOUNDFONT_FAMILY = 'FluidR3_GM';
const SOUNDFONT_FORMAT = 'mp3';
const CDN_BASE = 'https://gleitz.github.io/midi-js-soundfonts';

// --- INSTRUMENT MAPPING ---
// Maps user-friendly names to the canonical SoundFont instrument names.
export const INSTRUMENT_MAP: { [key: string]: string } = {
    'piano': 'acoustic_grand_piano',
    'violin': 'violin',
    'cello': 'cello',
    'bass': 'acoustic_bass',
    'bass-guitar': 'electric_bass_finger',
    'flute': 'flute',
    'clarinet': 'clarinet',
    'trumpet': 'trumpet',
    'french-horn': 'french_horn',
    'saxophone': 'alto_sax',
    'bells': 'tubular_bells',
    'marimba': 'marimba',
};

// --- INTERNAL CACHES ---
const loadedPlayers = new Map<string, Player>();
const loadingPromises = new Map<string, Promise<Player>>();

// --- CORE FUNCTIONS ---

/**
 * Returns a list of available instrument keys.
 */
export function listAvailable(): string[] {
    return Object.keys(INSTRUMENT_MAP);
}

/**
 * Lazily loads a single instrument. Returns a Tone.js-compatible player.
 * Falls back to a basic synth if the SoundFont fails to load.
 */
export async function getInstrument(keyName: string): Promise<Player> {
    const canonicalName = INSTRUMENT_MAP[keyName] || keyName;
    if (loadedPlayers.has(canonicalName)) {
        return loadedPlayers.get(canonicalName)!;
    }
    if (loadingPromises.has(canonicalName)) {
        return loadingPromises.get(canonicalName)!;
    }

    const promise = (async () => {
        try {
            await Tone.start();
            // soundfont-player requires a raw AudioContext
            const audioCtx = Tone.context.rawContext as AudioContext;
            const player = await Soundfont.instrument(audioCtx, canonicalName, {
                format: SOUNDFONT_FORMAT,
                soundfont: SOUNDFONT_FAMILY,
                gain: 2.0 // Boost gain slightly as SoundFonts can be quiet
            });
            loadedPlayers.set(canonicalName, player);
            return player;
        } catch (error) {
            console.warn(`SoundFont for '${keyName}' failed to load, using synth fallback.`, error);
            // Fallback to a simple Tone.js synth if loading fails
            const fallbackSynth = new Tone.PolySynth(Tone.Synth).toDestination();
            const fallbackPlayer: Player = {
                play: (note, time, options) => {
                    const duration = options?.duration || 1;
                    fallbackSynth.triggerAttackRelease(note.toString(), duration, time);
                    return { stop: () => {} };
                },
                stop: () => fallbackSynth.releaseAll(),
                schedule: (time: number, events: any[]) => {
                    events.forEach(event => {
                         fallbackSynth.triggerAttackRelease(event.note, event.duration, time + event.time);
                    });
                    return { stop: () => {} };
                }
            };
            loadedPlayers.set(canonicalName, fallbackPlayer);
            return fallbackPlayer;
        }
    })();

    loadingPromises.set(canonicalName, promise);
    const player = await promise;
    loadingPromises.delete(canonicalName);
    return player;
}


/**
 * Pre-downloads and caches a list of instruments for faster access later.
 */
export async function preloadInstruments(instrumentList: string[]): Promise<{ success: string[], failed: string[] }> {
    const results = { success: [], failed: [] };
    for (const key of instrumentList) {
        try {
            await getInstrument(key);
            results.success.push(key);
        } catch (e) {
            results.failed.push(key);
        }
    }
    return results;
}

/**
 * Fetches instrument files from the CDN and packages them into a downloadable ZIP file.
 */
export async function downloadInstrumentPack(instrumentList: string[]) {
    const zip = new JSZip();
    const folder = zip.folder('SoundFont_Pack');
    if (!folder) return;

    const promises = instrumentList.map(async (key) => {
        const canonicalName = INSTRUMENT_MAP[key];
        if (!canonicalName) return;

        // This is a simplified example; a real implementation would need to
        // parse the instrument JS file to find all the audio files it references.
        // For now, we'll just save a placeholder/link.
        const instrumentUrl = `${CDN_BASE}/${SOUNDFONT_FAMILY}/${canonicalName}-${SOUNDFONT_FORMAT}.js`;
        try {
            const response = await fetch(instrumentUrl);
            const data = await response.blob();
            folder.file(`${canonicalName}.js`, data);
        } catch (error) {
            console.error(`Failed to fetch ${canonicalName}:`, error);
        }
    });

    await Promise.all(promises);

    zip.generateAsync({ type: 'blob' }).then((content) => {
        saveAs(content, 'AI_Music_Studio_SoundFonts.zip');
    });
}