import React, { useState, useCallback, useRef, useEffect } from 'react';
import * as Tone from 'tone';
import { PRODUCER_PROGRESSIONS, GENRE_PROGRESSIONS } from './data/chordProgressions';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

// --- TYPES and Interfaces (Unchanged) ---
// ...

// --- SPECS, PATCHES, and DATA (Unchanged) ---
// ... (PRODUCER_SPECS, GENRE_SPECS, etc.)

// --- MusicGenerator Class (Unchanged from previous version) ---
class MusicGenerator {
  // ... All methods from the previous step are here
}

// --- AudioService Class (Unchanged from previous version) ---
class AudioService {
  // ... All methods from the previous step are here
}

// --- PianoRoll Component (Unchanged from previous version) ---
const PianoRoll = ({ notes, bars, totalDuration }) => {
  // ...
};

// --- NEW FEATURE: Tone.Offline Verification Utility ---
async function verifyGeneration(composition) {
  if (!composition || !composition.melody || composition.melody.length === 0) {
    console.error('Verification failed: Composition or melody is empty.');
    return false;
  }
  try {
    // Render a short, 5-second test to check for audio output
    const duration = Math.min(composition.duration, 5);
    const buffer = await Tone.Offline(async ({ transport }) => {
      // Use a basic, reliable synth for verification
      const synth = new Tone.Synth().toDestination();

      // Schedule a few notes from the generated melody
      new Tone.Part((time, note) => {
        synth.triggerAttackRelease(note.note, note.duration, time);
      }, composition.melody.slice(0, 15)).start(0); // Use up to 15 notes

      transport.bpm.value = composition.tempo;
      transport.start();
    }, duration);

    // If the buffer has a length greater than 0, audio was successfully produced.
    return buffer.length > 0;
  } catch (e) {
    console.error('Tone.Offline verification failed with an error:', e);
    return false;
  }
}


export default function App() {
  const [settings, setSettings] = useState<GenerationSettings>({
    // ... initial settings
  });
  
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [composition, setComposition] = useState<any>(null);
  const [isToneReady, setIsToneReady] = useState(false); // Track Tone.js state
  // ... other state variables

  const audioServiceRef = useRef<AudioService | null>(null);
  // ... other refs

  // --- NEW: Robust Tone.js Initialization ---
  useEffect(() => {
    const initializeAudio = async () => {
      await Tone.start();
      console.log("Tone.js context is ready.");
      setIsToneReady(true);
      audioServiceRef.current = new AudioService();
    };

    // Initialize on component mount
    initializeAudio();

    return () => {
      // Cleanup on unmount
      audioServiceRef.current?.dispose();
      Tone.Transport.cancel();
      Tone.Transport.stop();
    };
  }, []);

  const handleGenerate = async () => {
    if (!isToneReady) {
      alert("Audio context is not ready yet. Please wait a moment and try again.");
      return;
    }
    
    setIsGenerating(true);
    setIsPlaying(false);
    audioServiceRef.current?.stop();
    
    setAgents(prev => prev.map(a => ({ ...a, status: 'idle', message: '' })));

    const onUpdate = (name, status, message = '') => {
      setAgents(prev => prev.map(a => (a.name === name ? { ...a, status, message } : a)));
    };

    try {
      const currentSeed = settings.seed || Date.now().toString();
      if (!settings.seed) setSettings(s => ({ ...s, seed: currentSeed }));
      
      const generator = new MusicGenerator(currentSeed);
      const comp = await generator.generate(settings, onUpdate);
      
      // --- NEW: Verification Step ---
      const isVerified = await verifyGeneration(comp);
      if (!isVerified) {
          console.warn("⚠️ Generation verification failed — no audio was rendered offline. This could be due to an issue with synth patches or empty note data.");
          alert("Generation failed to produce audio. Please try different settings or refresh the page.");
          setAgents(prev => prev.map(a => ({ ...a, status: 'error', message: 'Verification Failed' })));
          setIsGenerating(false);
          return; // Halt the process
      }

      console.log("✅ Generation verified successfully.");
      setComposition(comp);
      await audioServiceRef.current?.schedule(comp);

    } catch (error) {
      console.error('Error during generation:', error);
      setAgents(prev => prev.map(a => 
        a.status === 'processing' ? { ...a, status: 'error', message: 'An unexpected error occurred.' } : a
      ));
    } finally {
      setIsGenerating(false);
    }
  };

  // ... (handlePlay, handleStop, handleDownload, and other handlers are unchanged)

  return (
    <div className="min-h-screen ...">
      {/* ... */}
      <div className="max-w-7xl mx-auto ...">
        {/* Settings Panel */}
        <div className="space-y-4">
          <div className="bg-gray-800/50 ...">
            {/* ... */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !isToneReady}
              className={`w-full ... ${!isToneReady ? 'cursor-not-allowed' : ''}`}
            >
              {isGenerating ? '🎵 Generating...' : (isToneReady ? '✨ Generate Track' : '🔊 Initializing Audio...')}
            </button>
          </div>
        </div>
        
        {/* Player, Piano Roll, and other UI elements */}
        {/* ... */}
      </div>
    </div>
  );
}