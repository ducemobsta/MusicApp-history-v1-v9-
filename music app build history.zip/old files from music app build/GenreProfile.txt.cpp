// In RealEngine.h
#pragma once
#include <string>
#include <vector>
#include <map>
// ... other includes

struct GenreProfile {
    std::string name;
    // Using string representations for now is easier than MIDI offsets
    std.vector<std::vector<std::string>> progressions; 
    // Example: { {"i", "v", "vi", "IV"}, {"i", "VI", "iv", "v"} }
    
    // You can add more rules here later
    // float harmonyDensity;
    // float melodicLeapProb;
};