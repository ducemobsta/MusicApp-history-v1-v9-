#!/bin/bash

# Termux AI Music Studio Setup Script
echo "🎵 Setting up AI Music Studio in Termux..."

# Update and upgrade packages
echo "📦 Updating packages..."
pkg update -y && pkg upgrade -y

# Install required packages
echo "📥 Installing dependencies..."
pkg install -y nodejs python git wget

# Install Python dependencies
echo "🐍 Installing Python packages..."
pip install numpy

# Create project directory structure
echo "📁 Creating project structure..."
mkdir -p ai-music-studio/{public,src,python}

cd ai-music-studio

# Create package.json for React app
echo "📄 Creating package.json..."
cat > package.json << 'EOF'
{
  "name": "ai-music-studio",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "tone": "^14.7.77"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@vitejs/plugin-react": "^4.0.0",
    "typescript": "^5.0.0",
    "vite": "^4.4.0"
  }
}
EOF

# Create Vite configuration
echo "⚙️ Creating Vite config..."
cat > vite.config.js << 'EOF'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 3000
  }
})
EOF

# Create TypeScript config
echo "📝 Creating TypeScript config..."
cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
EOF

cat > tsconfig.node.json << 'EOF'
{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true
  },
  "include": ["vite.config.ts"]
}
EOF

# Create HTML entry point
echo "🌐 Creating HTML entry..."
cat > public/index.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AI Music Studio Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/tone@latest/build/Tone.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/nbrosowsky/tonejs-instruments@master/Tonejs-Instruments.js"></script>
    <style>
      body {
        margin: 0;
        padding: 0;
        background: #0f172a;
      }
    </style>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
EOF

# Create main React entry point
echo "⚛️ Creating React entry point..."
cat > src/main.tsx << 'EOF'
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './ai-music-studio.tsx'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
EOF

# Create the main AI Music Studio component
echo "🎹 Creating AI Music Studio component..."
cat > src/ai-music-studio.tsx << 'EOF'
import React, { useState, useCallback, useRef, useEffect } from 'react';
import * as Tone from 'tone';

/**
* ai-music-studio.tsx
* Full React component using Tone.js + tonejs-instruments (CDN).
*/

/*
Type helpers (light)
    --- */
type Genre = 'Trap' | 'Trap-Soul' | 'R&B' | 'Soul' | '90s Rap' | 'Lo-fi' | 'Drill' | 'G-Funk' | 'Neo-Soul';
type Producer = 'Pharrell' | 'Timbaland' | 'Zaytoven' | 'Just Blaze' | 'Missy Elliott' | 'Dr. Dre' | 'J Dilla' | 'Kanye West' | 'DJ Quik' | 'No I.D.' | 'Default';
type AgentStatus = 'idle' | 'processing' | 'complete' | 'error';

interface GenerationSettings {
  genre: Genre;
  producer: Producer;
  key: string;
  tempo: number;
  bars: number;
}

interface Agent {
  name: string;
  status: AgentStatus;
  output: any;
}

/*
Provide minimal producer & genre data
    --- */

const PRODUCER_SPECS: Record<Producer, any> = {
  'Pharrell': { saturation: 0.2, reverb: { mix: 0.3, decay: 1.2 }, swing: 0.4, synth: 'plucky-funk', signature: 'Minimalist funk' },
  'Timbaland': { saturation: 0.6, reverb: { mix: 0.25, decay: 0.8 }, swing: 0.7, synth: 'digital-FM', signature: 'Stuttering rhythms' },
  'Zaytoven': { saturation: 0.9, reverb: { mix: 0.4, decay: 1.5 }, swing: 0.2, synth: 'digital-FM', signature: 'Piano melodies' },
  'Just Blaze': { saturation: 0.3, reverb: { mix: 0.5, decay: 2.5 }, swing: 0.5, synth: 'analog-saw', signature: 'Soulful samples' },
  'Missy Elliott': { saturation: 0.8, reverb: { mix: 0.35, decay: 1.0 }, swing: 0.8, synth: 'digital-FM', signature: 'Experimental sound FX' },
  'Dr. Dre': { saturation: 0.7, reverb: { mix: 0.4, decay: 2.0 }, swing: 0.5, synth: 'analog-saw', signature: 'G-Funk, deep bass' },
  'J Dilla': { saturation: 0.3, reverb: { mix: 0.3, decay: 0.8 }, swing: 0.6, synth: 'rhodes-ep', signature: 'Off-kilter rhythms' },
  'Kanye West': { saturation: 0.5, reverb: { mix: 0.6, decay: 3.0 }, swing: 0.4, synth: 'analog-saw', signature: 'Soul samples' },
  'DJ Quik': { saturation: 0.4, reverb: { mix: 0.35, decay: 1.5 }, swing: 0.6, synth: 'rhodes-ep', signature: 'West Coast G-Funk' },
  'No I.D.': { saturation: 0.3, reverb: { mix: 0.4, decay: 1.8 }, swing: 0.5, synth: 'rhodes-ep', signature: 'Soulful sampling' },
  'Default': { saturation: 0.4, reverb: { mix: 0.3, decay: 1.5 }, swing: 0.3, synth: 'analog-saw', signature: 'Balanced' }
};

const GENRE_SPECS: Record<Genre, any> = {
  'Trap': { bpm: { min: 130, max: 170, common: [140] }, scales: ['A minor'], description: 'Hard 808s', kickPattern: [1,0,0,0,1,0,1,0], snarePattern: [0,0,0,0,1,0,0,0], hihatDensity: 'high', progressions: [['i','bVI','bIII','bVII']] },
  'Trap-Soul': { bpm: { min: 60, max: 100, common: [80] }, scales: ['A minor'], description: 'Emotional melodies', kickPattern: [1,0,0,0,1,0,0,0], snarePattern: [0,0,0,0,1,0,0,0], hihatDensity: 'medium', progressions: [['i','VI','III','VII']] },
  'R&B': { bpm: { min: 90, max: 120, common: [95] }, scales: ['C major'], description: 'Smooth grooves', kickPattern: [1,0,0,0,1,0,0,0], snarePattern: [0,0,1,0,0,0,1,0], hihatDensity: 'medium', progressions: [['ii','V','I']] },
  'Soul': { bpm: { min: 90, max: 120, common: [95] }, scales: ['C major'], description: 'Gospel-inspired', kickPattern: [1,0,0,0,1,0,0,0], snarePattern: [0,0,1,0,0,0,1,0], hihatDensity: 'low', progressions: [['I','V','vi','IV']] },
  '90s Rap': { bpm: { min: 80, max: 110, common: [90] }, scales: ['A minor'], description: 'Boom-bap', kickPattern: [1,0,0,0,1,0,0,0], snarePattern: [0,0,1,0,0,0,1,0], hihatDensity: 'medium', progressions: [['i','VII','VI','V']] },
  'Lo-fi': { bpm: { min: 80, max: 110, common: [85] }, scales: ['C major'], description: 'Chill vibes', kickPattern: [1,0,0,0,1,0,0,0], snarePattern: [0,0,1,0,0,0,1,0], hihatDensity: 'low', progressions: [['ii','V','I','IV']] },
  'Drill': { bpm: { min: 60, max: 80, common: [70] }, scales: ['C minor'], description: 'Aggressive sliding hi-hats', kickPattern: [1,0,0,0,0,0,1,0], snarePattern: [0,0,0,1,0,0,0,0], hihatDensity: 'very-high', progressions: [['i','bIII','bVI','bVII']] },
  'G-Funk': { bpm: { min: 85, max: 100, common: [90] }, scales: ['C minor'], description: 'West Coast funk', kickPattern: [1,0,0,0,1,0,0,0], snarePattern: [0,0,1,0,0,0,1,0], hihatDensity: 'medium', progressions: [['i','VI','VII','i']] },
  'Neo-Soul': { bpm: { min: 70, max: 90, common: [80] }, scales: ['D minor'], description: 'Jazz harmony', kickPattern: [1,0,0,0,0,0,1,0,0,1,0,0], snarePattern: [0,0,0,1,0,0,0,1,0,0,0], hihatDensity: 'low', progressions: [['i','VII','VI','V']] }
};

const NOTE_MAP: Record<string, string[]> = {
  'C major': ['C4','D4','E4','F4','G4','A4','B4','C5'], 
  'A minor': ['A3','B3','C4','D4','E4','F4','G4','A4'], 
  'D minor': ['D3','E3','F3','G3','A3','Bb3','C4','D4'], 
  'C minor': ['C3','D3','Eb3','F3','G3','Ab3','Bb3','C4'] 
};

/* ---
  Forward declare SampleLibrary (global from CDN) 
  --- */
declare global {
  interface Window { SampleLibrary?: any; }
}

const SampleLibrary = (window as any).SampleLibrary;

/* ---
  Music generator
  --- */

class MusicGenerator {
  async generate(settings: GenerationSettings, onUpdate: (name: string, status: AgentStatus) => void) {
    const spec = GENRE_SPECS[settings.genre];
    const producer = PRODUCER_SPECS[settings.producer];
    const scale = NOTE_MAP[settings.key] || NOTE_MAP['A minor'];

    onUpdate('Theme Director', 'processing');
    await this.delay(300);
    const theme = { mood: producer.signature, key: settings.key };
    onUpdate('Theme Director', 'complete');

    onUpdate('Harmony Designer', 'processing');
    await this.delay(400);
    const harmony = this.generateHarmony(scale, settings.bars, spec, producer);
    onUpdate('Harmony Designer', 'complete');

    onUpdate('Rhythm Architect', 'processing');
    await this.delay(450);
    const rhythm = this.generateRhythm(settings.bars, spec, producer);
    onUpdate('Rhythm Architect', 'complete');

    onUpdate('Melody Composer', 'processing');
    await this.delay(350);
    const melody = this.generateMelody(scale, settings.bars, producer);
    onUpdate('Melody Composer', 'complete');

    onUpdate('Audio Synthesizer', 'processing');
    await this.delay(250);
    onUpdate('Audio Synthesizer', 'complete');

    return {
      rhythm,
      harmony,
      melody,
      bass: this.generateBass(harmony, producer),
      tempo: settings.tempo,
      producer: settings.producer,
      genre: settings.genre,
      mixParams: producer,
      theme
    };
  }

  generateRhythm(bars: number, spec: any, producer: any) {
    const beatsPerBar = 16;
    const patterns: any = { kick: [], snare: [], hihat: [] };

    for (let b = 0; b < bars; b++) {
      for (let i = 0; i < beatsPerBar; i++) {
        const time = `0:${b}:${i/4}`;
        const kickIdx = i % spec.kickPattern.length;
        if (spec.kickPattern[kickIdx]) patterns.kick.push({ time, velocity: 0.9 });

        const snareIdx = i % spec.snarePattern.length;
        if (spec.snarePattern[snareIdx]) patterns.snare.push({ time, velocity: 0.9 });

        const hhChance = spec.hihatDensity == 'very-high' ? 0.9 : spec.hihatDensity == 'high' ? 0.7 : spec.hihatDensity == 'medium' ? 0.5 : 0.3;
        if (i % 2 == 0 || Math.random() < hhChance) patterns.hihat.push({ time, velocity: 0.4 });
      }
    }
    return patterns;
  }

  generateHarmony(scale: string[], bars: number, spec: any, producer: any) {
    const chords: any[] = [];
    const prog = ['i','v','I','V'];
    for (let i = 0; i < bars; i++) {
      const root = i % scale.length;
      const notes = [ scale[root % scale.length], scale[(root+2)%scale.length], scale[(root+4)%scale.length]];
      chords.push({ time: `0:${i}:0`, notes, duration: '1m' });
    }
    return chords;
  }

  generateMelody(scale: string[], bars: number, producer: any) {
    const notes: any[] = [];
    const density = producer?.minimalist ? 2 : 4;
    for (let b = 0; b < bars; b++) {
      for (let i = 0; i < density; i++) {
        const idx = (b * density + i) % scale.length;
        notes.push({ time: `0:${b}:${i}`, note: scale[idx], duration: '4n', velocity: 0.6 });
      }
    }
    return notes;
  }

  generateBass(harmony: any[], producer: any) {
    return harmony.map((c: any) => ({ time: c.time, note: c.notes[0].replace('4','2'), duration: '1m' }));
  }

  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/*
AudioService: Tone.js + tonejs-instruments integration
---
*/
class AudioService {
  private instruments: Record<string, any> = {};
  private parts: any[] = [];
  private analyser: Tone.Analyser | null = null;
  private reverb: Tone.Reverb | null = null;
  private isInit = false;

  async init() {
    if (!this.isInit) {
      await Tone.start();
      this.isInit = true;
    }
  }

  private async loadInstrumentSet(names: string[]) {
    if (!SampleLibrary && !(window as any).SampleLibrary) {
      throw new Error('SampleLibrary not found. Ensure Tonejs-Instruments CDN script is added to index.html.');
    }
    const lib = (window as any).SampleLibrary;
    const instruments: Record<string, any> = {};
    
    for (const name of names) {
      if (this.instruments[name]) {
        instruments[name] = this.instruments[name];
        continue;
      }
      const inst = lib.load({ 
        instruments: name, 
        baseUrl: 'https://nbrosowsky.github.io/tonejs-instruments/samples/' 
      });
      await Tone.loaded();
      this.instruments[name] = inst;
      instruments[name] = inst;
    }
    return instruments;
  }

  async schedule(comp: any) {
    await this.init();
    this.stop();
    this.cleanup();

    const producer = comp.mixParams;
    this.reverb = new Tone.Reverb({ decay: producer.reverb.decay, wet: producer.reverb.mix });
    await this.reverb.generate();
    const master = new Tone.Gain(0.85).connect(this.reverb).toDestination();

    const producerMap: Record<string, string[]> = {
      'Pharrell': ['guitar-acoustic','piano','bass-electric'],
      'Timbaland': ['piano','bass-electric','drumkit'],
      'Zaytoven': ['piano','drumkit'],
      'Just Blaze': ['strings','piano','bass-electric'],
      'Missy Elliott': ['piano','bass-electric'],
      'Dr. Dre': ['bass-electric','piano'],
      'J Dilla': ['piano'],
      'Kanye West': ['piano','bass-electric'],
      'DJ Quik': ['guitar-electric','bass-electric'],
      'No I.D': ['piano','bass-electric'],
      'Default': ['piano','bass-electric']
    };

    const setNames = producerMap[comp.producer] || ['piano','bass-electric'];
    const loaded = await this.loadInstrumentSet(setNames);

    Object.values(loaded).forEach((inst: any) => {
      try { inst.connect(master); } catch (e) { try { inst.toDestination(); } catch (e2) {} }
    });

    if (!this.analyser) {
      this.analyser = new Tone.Analyser('waveform', 1024);
      Tone.getDestination().connect(this.analyser);
    }

    // Kick
    this.parts.push(
      new Tone.Part((time: any, e: any) => {
        const drumkit = loaded['drumkit'];
        const bassInst = loaded['bass-electric'];
        if (drumkit?.triggerAttack) {
          drumkit.triggerAttack('C1', time, e.velocity || 1);
        } else if (bassInst?.triggerAttack) {
          bassInst.triggerAttack('C2', time, e.velocity || 1);
        }
      }, comp.rhythm.kick).start(0)
    );

    // Snare
    this.parts.push(
      new Tone.Part((time: any, e: any) => {
        const drumkit = loaded['drumkit'];
        if (drumkit?.triggerAttack) {
          drumkit.triggerAttack('D2', time, e.velocity || 1);
        } else {
          const piano = loaded['piano'];
          piano?.triggerAttackRelease && piano.triggerAttackRelease('E4', '8n', time, e.velocity || 1);
        }
      }, comp.rhythm.snare).start(0)
    );

    // Hi-hat
    this.parts.push(
      new Tone.Part((time: any, e: any) => {
        const piano = loaded['piano'];
        const guitar = loaded['guitar-acoustic'] || loaded['guitar-electric'];
        if (guitar?.triggerAttack) {
          guitar.triggerAttackRelease('B4', '32n', time, e.velocity || 0.4);
        } else if (piano?.triggerAttack) {
          piano.triggerAttackRelease('G5', '32n', time, e.velocity || 0.3);
        }
      }, comp.rhythm.hihat).start(0)
    );

    // Harmony
    this.parts.push(
      new Tone.Part((time: any, chord: any) => {
        const lead = loaded['piano'] || loaded['guitar-acoustic'] || loaded['strings'];
        if (!lead) return;
        try {
          lead.triggerAttackRelease && lead.triggerAttackRelease(chord.notes, chord.duration || '1m', time);
        } catch {
          const note = Array.isArray(chord.notes) ? chord.notes[0] : chord.notes;
          lead.triggerAttackRelease && lead.triggerAttackRelease(note, chord.duration || '1m', time);
        }
      }, comp.harmony).start(0)
    );

    // Bass
    this.parts.push(
      new Tone.Part((time: any, n: any) => {
        const bass = loaded['bass-electric'];
        if (bass?.triggerAttackRelease) {
          bass.triggerAttackRelease(n.note, n.duration || '1m', time, n.velocity || 0.9);
        }
      }, comp.bass).start(0)
    );

    // Melody
    this.parts.push(
      new Tone.Part((time: any, n: any) => {
        const lead = loaded['guitar-electric'] || loaded['piano'] || loaded['strings'];
        if (lead?.triggerAttackRelease) {
          lead.triggerAttackRelease(n.note, n.duration || '4n', time, n.velocity || 0.7);
        }
      }, comp.melody).start(0)
    );

    Tone.Transport.bpm.value = comp.tempo;
    Tone.Transport.loop = true;
    Tone.Transport.loopEnd = `${comp.harmony.length}m`;
  }

  play() { Tone.Transport.start(); }
  stop() { Tone.Transport.stop(); Tone.Transport.position = '0:0:0'; }
  getAnalyser() { return this.analyser; }

  cleanup() {
    this.parts.forEach(p => p.dispose && p.dispose());
    this.parts = [];
    this.instruments = {};
    Tone.Transport.cancel();
  }

  dispose() {
    this.stop();
    this.cleanup();
    this.analyser?.dispose();
    this.reverb?.dispose();
  }
}

/* ---
React component UI
--- */
export default function App() {
  const [settings, setSettings] = useState<GenerationSettings>({
    genre: 'Trap',
    producer: 'Default',
    key: 'A minor',
    tempo: 140,
    bars: 8
  });

  const [agents, setAgents] = useState<Agent[]>([
    { name: 'Theme Director', status: 'idle', output: null },
    { name: 'Harmony Designer', status: 'idle', output: null },
    { name: 'Rhythm Architect', status: 'idle', output: null },
    { name: 'Melody Composer', status: 'idle', output: null },
    { name: 'Audio Synthesizer', status: 'idle', output: null }
  ]);

  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [composition, setComposition] = useState<any>(null);
  const [showDetails, setShowDetails] = useState(false);

  const audioServiceRef = useRef<AudioService | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  useEffect(() => {
    audioServiceRef.current = new AudioService();
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      audioServiceRef.current?.dispose();
    };
  }, []);

  const drawVisualizer = useCallback(() => {
    if (!canvasRef.current || !audioServiceRef.current) return;
    const analyser = audioServiceRef.current.getAnalyser();
    if (!analyser) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const values = analyser.getValue() as Float32Array;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = 2;
    ctx.beginPath();
    const sliceWidth = canvas.width / values.length;
    for (let i = 0; i < values.length; i++) {
      const v = (values[i] + 1) / 2;
      const y = v * canvas.height;
      const x = i * sliceWidth;
      if (i == 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = '#8b5cf6';
    ctx.stroke();
    animationFrameRef.current = requestAnimationFrame(drawVisualizer);
  }, []);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setIsPlaying(false);
    audioServiceRef.current?.stop();

    setAgents(prev => prev.map(a => ({ ...a, status: 'idle', output: null })));

    const onUpdate = (name: string, status: AgentStatus) => {
      setAgents(prev => prev.map(a => a.name === name ? { ...a, status } : a));
    };

    try {
      const generator = new MusicGenerator();
      const comp = await generator.generate(settings, onUpdate);
      setComposition(comp);
      await audioServiceRef.current?.schedule(comp);
    } catch (err) {
      console.error(err);
      setAgents(prev => prev.map(a => a.status === 'processing' ? { ...a, status: 'error' } : a));
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePlay = () => {
    if (!composition) return;
    audioServiceRef.current?.play();
    setIsPlaying(true);
    drawVisualizer();
  };

  const handleStop = () => {
    audioServiceRef.current?.stop();
    setIsPlaying(false);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
  };

  const getProducerColor = (producer: Producer) => {
    const colors: Record<Producer, string> = {
      'Pharrell': 'from-yellow-500 to-orange-500',
      'Timbaland': 'from-blue-500 to-cyan-500',
      'Zaytoven': 'from-purple-500 to-pink-500',
      'Just Blaze': 'from-red-500 to-orange-500',
      'Missy Elliott': 'from-pink-500 to-purple-500',
      'Dr. Dre': 'from-green-500 to-emerald-500',
      'J Dilla': 'from-amber-500 to-yellow-500',
      'Kanye West': 'from-indigo-500 to-purple-500',
      'DJ Quik': 'from-teal-500 to-cyan-500',
      'No I.D.': 'from-slate-500 to-gray-500',
      'Default': 'from-gray-500 to-slate-500'
    };
    return colors[producer];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black text-white p-4 md:p-6">
      <header className="text-center mb-8">
        <h1 className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-orange-500 mb-2">
          AI Music Studio Pro
        </h1>
        <p className="text-gray-400 text-sm md:text-base">Sample-based instruments via tonejs-instruments</p>
      </header>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <div className="space-y-4">
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-4 md:p-6 shadow-2xl">
            <h2 className="text-xl font-bold mb-4 text-purple-400"> Generation Settings</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs md:text-sm mb-2 font-medium text-gray-300">Genre</label>
                  <select className="w-full bg-gray-700 border border-gray-600 rounded-lg p-2 text-sm" value={settings.genre}
                    onChange={e => {
                      const genre = e.target.value as Genre;
                      const spec = GENRE_SPECS[genre];
                      setSettings(prev => ({ ...prev, genre, tempo: spec.bpm.common[0], key: spec.scales[0] }));
                    }}
                  >
                    {Object.keys(GENRE_SPECS).map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">{GENRE_SPECS[settings.genre].description}</p>
                </div>
                <div>
                  <label className="block text-xs md:text-sm mb-2 font-medium text-gray-300">Producer</label>
                  <select className="w-full bg-gray-700 border border-gray-600 rounded-lg p-2 text-sm" value={settings.producer}
                    onChange={e => setSettings(prev => ({ ...prev, producer: e.target.value as Producer }))}
                  >
                    {Object.keys(PRODUCER_SPECS).map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                  <p className="text-xs text-gray-500 mt-1">{PRODUCER_SPECS[settings.producer].signature}</p>
                </div>
              </div>
              <div>
                <label className="block text-xs md:text-sm mb-2 font-medium text-gray-300">Musical Key</label>
                <select className="w-full bg-gray-700 border border-gray-600 rounded-lg p-2 text-sm" value={settings.key}
                  onChange={e => setSettings(prev => ({ ...prev, key: e.target.value }))}
                >
                  {Object.keys(NOTE_MAP).map(k => <option key={k} value={k}>{k}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs md:text-sm mb-2 flex justify-between font-medium">
                  <span className="text-gray-300">Tempo</span>
                  <span className="text-purple-400 font-bold">{settings.tempo} BPM</span>
                </label>
                <input type="range" min={GENRE_SPECS[settings.genre].bpm.min} max={GENRE_SPECS[settings.genre].bpm.max}
                  value={settings.tempo} onChange={e => setSettings(prev => ({ ...prev, tempo: parseInt(e.target.value) }))}
                  className="w-full accent-purple-500" />
              </div>

              <div>
                <label className="block text-xs md:text-sm mb-2 flex justify-between font-medium">
                  <span className="text-gray-300">Length</span>
                  <span className="text-pink-400 font-bold">{settings.bars} bars</span>
                </label>
                <input type="range" min="4" max="16" step="4" value={settings.bars}
                  onChange={e => setSettings(prev => ({ ...prev, bars: parseInt(e.target.value) }))}
                  className="w-full accent-pink-500" />
              </div>

              <button onClick={handleGenerate} disabled={isGenerating}
                className={`w-full bg-gradient-to-r ${getProducerColor(settings.producer)} text-white font-bold py-3 rounded-lg disabled:opacity-50`}>
                {isGenerating ? ' Generating...' : ' Generate Music' }
              </button>
            </div>
          </div>

          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-4 md:p-6 shadow-2xl">
            <h2 className="text-xl font-bold mb-4 text-purple-400"> Playback</h2>

            <canvas ref={canvasRef} width={400} height={120} className="w-full h-28 bg-black/50 rounded-lg mb-4 border border-gray-600" />

            <div className="flex gap-2">
              <button onClick={isPlaying ? handleStop : handlePlay} disabled={!composition || isGenerating}
                className={`flex-1 ${isPlaying ? 'bg-red-600' : 'bg-green-600'} text-white font-bold py-3 rounded-lg`}>
                {isPlaying ? ' Stop' : ' Play' }
              </button>
              <button onClick={() => setShowDetails(!showDetails)} disabled={!composition}
                className="px-4 bg-blue-600 text-white font-bold py-3 rounded-lg">
                {showDetails ? ' Hide' : ' Details' }
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-4 md:p-6 shadow-2xl">
            <h2 className="text-xl font-bold mb-4 text-purple-400"> AI Agent Pipeline</h2>
            <div className="flex items-center justify-between flex-wrap gap-3">
              {agents.map((agent, i) => (
                <React.Fragment key={agent.name}>
                  <div className={`flex flex-col items-center p-3 rounded-lg border-2 ${
                    agent.status === 'processing' ? 'border-blue-500 bg-blue-500/20':
                    agent.status === 'complete' ? 'border-green-500 bg-green-500/20':
                    agent.status === 'error' ? 'border-red-500 bg-red-500/20':
                    'border-gray-600 bg-gray-700/30'
                  }`}>
                    <div className="text-2xl mb-1">
                      {agent.status === 'processing' ? '⚡' : agent.status === 'complete' ? '✓' : agent.status === 'error' ? '✗' : '○'}
                    </div>
                    <div className="text-xs font-semibold text-center">{agent.name}</div>
                  </div>
                  {i < agents.length - 1 && <div className="text-gray-500 text-xl hidden sm:block">→</div>}
                </React.Fragment>
              ))}
            </div>
          </div>

          {composition && (
            <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-4 md:p-6 shadow-2xl">
              <h2 className="text-xl font-bold mb-4 text-purple-400"> Composition Overview</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-purple-900/30 p-4 rounded-lg border border-purple-500/30">
                  <div className="text-gray-400 text-xs mb-1">Genre</div>
                  <div className="font-bold text-sm md:text-base">{composition.genre}</div>
                </div>
                <div className="bg-pink-900/30 p-4 rounded-lg border border-pink-500/30">
                  <div className="text-gray-400 text-xs mb-1">Producer</div>
                  <div className="font-bold text-sm md:text-base">{composition.producer}</div>
                </div>
                <div className="bg-orange-900/30 p-4 rounded-lg border border-orange-500/30">
                  <div className="text-gray-400 text-xs mb-1">Tempo</div>
                  <div className="font-bold text-sm md:text-base">{composition.tempo} BPM</div>
                </div>
                <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-500/30">
                  <div className="text-gray-400 text-xs mb-1">Key</div>
                  <div className="font-bold text-sm md:text-base">{settings.key}</div>
                </div>
              </div>
            </div>
          )}
          {showDetails && composition && (
            <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-4 md:p-6 shadow-2xl">
              <h2 className="text-xl font-bold mb-4 text-purple-400"> Technical Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="bg-gray-900/50 p-3 rounded-lg">
                  <div className="text-purple-400 font-bold mb-2"> Rhythm</div>
                  <div className="text-xs space-y-1">
                    <div>Kick hits: {composition.rhythm.kick.length}</div>
                    <div>Snare hits: {composition.rhythm.snare.length}</div>
                    <div>Hi-hat hits: {composition.rhythm.hihat.length}</div>
                  </div>
                </div>
                <div className="bg-gray-900/50 p-3 rounded-lg">
                  <div className="text-pink-400 font-bold mb-2"> Harmony</div>
                  <div className="text-xs space-y-1">
                    <div>Chords: {composition.harmony.length}</div>
                  </div>
                </div>
                <div className="bg-gray-900/50 p-3 rounded-lg">
                  <div className="text-orange-400 font-bold mb-2"> Melody</div>
                  <div className="text-xs space-y-1">
                    <div>Notes: {composition.melody.length}</div>
                  </div>
                </div>
                <div className="bg-gray-900/50 p-3 rounded-lg">
                  <div className="text-blue-400 font-bold mb-2"> Mix</div>
                  <div className="text-xs space-y-1">
                    <div>Saturation: {(composition.mixParams.saturation * 100).toFixed(0)}%</div>
                    <div>Reverb decay: {composition.mixParams.reverb.decay.toFixed(1)}s</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <footer className="text-center mt-8 text-gray-500 text-xs md:text-sm">
        <p className="font-semibold">AI Music Studio Pro — Sample-based playback</p>
        <p className="mt-2"> Producers baked in: Pharrell • Timbaland • Zaytoven • Just Blaze • Missy Elliott • Dr. Dre • J Dilla • Kanye West • DJ Quik • No I.D.</p>
      </footer>
    </div>
  );
}
EOF

# Create Python DSP module
echo "🐍 Creating Python DSP module..."
cat > python/producer_dsp.py << 'EOF'
import numpy as np
import wave
import struct
from typing import Tuple, Callable, Dict

SR = 44100

# ---
# Basic primitives & helpers
# ---

def sine(freq: float, length: float, sr: int = SR, phase: float = 0.0) -> np.ndarray:
    t = np.linspace(0, length, int(sr * length), False)
    return np.sin(2 * np.pi * freq * t + phase)

def square(freq: float, length: float, sr: int = SR) -> np.ndarray:
    return np.sign(sine(freq, length, sr))

def triangle(freq: float, length: float, sr: int = SR) -> np.ndarray:
    t = np.linspace(0, length, int(sr * length), False)
    return 2.0 * (2.0 * (t * freq - np.floor(0.5 + t * freq))) * ((-1)**0) # simple saw-like baseline

def white_noise(length: float, sr: int = SR) -> np.ndarray:
    return np.random.normal(0, 1.0, int(sr * length))

def env_adsr(length: float, attack: float, decay: float, sustain_level: float, release: float, sr: int = SR) -> np.ndarray:
    n = int(length * sr)
    env = np.zeros(n)
    a_n = min(int(attack * sr), n)
    d_n = min(int(decay * sr), n - a_n)
    r_n = min(int(release * sr), n - a_n - d_n)
    s_n = n - (a_n + d_n + r_n)
    if a_n > 0:
        env[:a_n] = np.linspace(0, 1.0, a_n)
    if d_n > 0:
        env[a_n:a_n+d_n] = np.linspace(1.0, sustain_level, d_n)
    if s_n > 0:
        env[a_n+d_n:a_n+d_n+s_n] = sustain_level
    if r_n > 0:
        env[a_n+d_n+s_n:a_n+d_n+s_n+r_n] = np.linspace(sustain_level, 0.0, r_n)
    return env

def one_pole_lowpass(signal: np.ndarray, cutoff: float, sr: int = SR) -> np.ndarray:
    # simple one-pole lowpass
    x = np.copy(signal)
    rc = 1.0 / (2 * np.pi * cutoff)
    dt = 1.0 / sr
    alpha = dt / (rc + dt)
    for i in range(1, len(x)):
        x[i] = x[i-1] + alpha * (signal[i] - x[i-1])
    return x

def saturate(signal: np.ndarray, drive: float = 0.2) -> np.ndarray:
    # tanh saturation
    return np.tanh(signal * (1.0 + drive * 10.0))

def linear_fade(signal: np.ndarray, fade_in: int = 0, fade_out: int = 0) -> np.ndarray:
    n = len(signal)
    out = signal.copy()
    if fade_in > 0:
        in_window = np.linspace(0.0, 1.0, min(fade_in, n))
        out[:len(in_window)] *= in_window
    if fade_out > 0:
        out_window = np.linspace(1.0, 0.0, min(fade_out, n))
        out[-len(out_window):] *= out_window
    return out

def normalize(sig: np.ndarray, peak: float = 0.98) -> np.ndarray:
    m = np.max(np.abs(sig)) + 1e-12
    return sig * (peak / m)

def write_wav(filename: str, sig: np.ndarray, sr: int = SR):
    sig16 = np.int16(normalize(sig) * 32767)
    with wave.open(filename, 'w') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(sig16.tobytes())

# ---
# Producer-specific instruments
# ---

# TIMBALAND: deep tuned kick, click transient, saturation, lowpass
def timbaland_kick(frequency: float = 60.0, decay: float = 0.3, length: float = 0.6, sr: int = SR) -> np.ndarray:
    sub = sine(frequency, length, sr)
    env = env_adsr(length, attack=0.001, decay=decay, sustain_level=0.0, release=0.001, sr=sr)
    sub = sub * env
    click = square(frequency * 3, 0.05, sr) * env_adsr(0.05, 0.001, 0.02, 0.0, 0.01, sr)
    kick = sub + 0.15 * click
    kick = one_pole_lowpass(kick, cutoff=120.0, sr=sr)
    return normalize(saturate(kick, drive=0.25))

def timbaland_snare(length: float = 0.25, sr: int = SR) -> np.ndarray:
    noise = white_noise(length, sr) * env_adsr(length, 0.001, 0.08, 0.0, 0.01, sr)
    tone = square(180.0, length, sr) * env_adsr(length, 0.001, 0.12, 0.0, 0.01, sr)
    snare = noise + 0.5 * tone
    snare = one_pole_lowpass(snare, cutoff=5000.0, sr=sr)
    return normalize(saturate(snare, drive=0.12))

def timbaland_perc(length: float = 0.06, sr: int = SR) -> np.ndarray:
    snap = white_noise(length, sr) * env_adsr(length, 0.001, 0.02, 0.0, 0.001, sr)
    snap = one_pole_lowpass(snap, 8000.0, sr)
    return normalize(snap * 0.6)

# KANYE: short truncated kick and sample-style snare/hihat processing
def kanye_kick(frequency: float = 65.0, decay: float = 0.1, length: float = 0.4, sr: int = SR) -> np.ndarray:
    wave = sine(frequency, length, sr) * env_adsr(length, 0.001, decay, 0.0, 0.001, sr)
    n = int(decay * sr)
    wave = wave[:max(1, n)]
    wave = np.pad(wave, (0, int(length*sr)-len(wave)))
    wave = one_pole_lowpass(wave, cutoff=100.0, sr=sr)
    return normalize(saturate(wave, drive=0.18))

def kanye_snare(length: float = 0.25, sr: int = SR) -> np.ndarray:
    noise = white_noise(length, sr) * env_adsr(length, 0.001, 0.15, 0.0, 0.01, sr)
    tone = sine(220.0, length, sr) * env_adsr(length, 0.001, 0.12, 0.0, 0.01, sr)
    snare = noise + 0.4 * tone
    snare = one_pole_lowpass(snare, cutoff=5000.0, sr=sr)
    return normalize(saturate(snare, drive=0.15))

def kanye_hihat(length: float = 0.08, sr: int = SR) -> np.ndarray:
    hat = white_noise(length, sr) * env_adsr(length, 0.001, 0.06, 0.0, 0.001, sr)
    hat = one_pole_lowpass(hat, cutoff=10000.0, sr=sr)
    # emulate a small delay tail by adding attenuated, slightly delayed copy
    tail = np.pad(hat[:-int(0.01*sr)], (int(0.01*sr), 0)) * 0.25
    return normalize(hat + tail)

# DJ QUIK: sine-heavy kick with triangle body; ghost snare layering
def djquik_kick(frequency: float = 70.0, decay: float = 0.4, length: float = 0.6, sr: int = SR) -> np.ndarray:
    sub = sine(frequency, length, sr) * env_adsr(length, 0.001, decay, 0.0, 0.01, sr)
    body = triangle(frequency * 2, length, sr) * env_adsr(length, 0.001, decay*0.6, 0.0, 0.01, sr) * 0.15
    kick = sub + body
    kick = one_pole_lowpass(kick, cutoff=150.0, sr=sr)
    return normalize(saturate(kick, drive=0.12))

def djquik_snare(length: float = 0.25, sr: int = SR) -> np.ndarray:
    main = white_noise(length, sr) * env_adsr(length, 0.001, 0.18, 0.0, 0.01, sr)
    square_tone = square(180.0, length, sr) * env_adsr(length, 0.001, 0.12, 0.0, 0.01, sr) * 0.12
    ghost = white_noise(length, sr) * env_adsr(length, 0.001, 0.08, 0.0, 0.01, sr) * 0.4
    ghost = np.pad(ghost[:int(0.02*sr)], (int(0.02*sr), 0)) * 0.4
    snare = main + square_tone + ghost
    snare = one_pole_lowpass(snare, cutoff=6000.0, sr=sr)
    return normalize(saturate(snare, drive=0.1))

# NO I.D.: crisp analog-style snare, jazz hat
def no_id_snare(length: float = 0.25, sr: int = SR) -> np.ndarray:
    noise = white_noise(length, sr) * env_adsr(length, 0.001, 0.22, 0.0, 0.01, sr)
    tone = square(200.0, length, sr) * 0.12
    snare = noise + tone
    snare = one_pole_lowpass(snare, cutoff=5000.0, sr=sr)
    return normalize(saturate(snare, drive=0.08))

def no_id_hihat(length: float = 0.06, sr: int = SR) -> np.ndarray:
    hat = white_noise(length, sr) * env_adsr(length, 0.001, 0.06, 0.0, 0.001, sr)
    hat = one_pole_lowpass(hat, cutoff=9000.0, sr=sr)
    return normalize(hat)

# DEFAULT fallback instruments
def default_kick(frequency: float = 60.0, decay: float = 0.3, length: float = 0.6, sr: int = SR) -> np.ndarray:
    return timbaland_kick(frequency, decay, length, sr) * 0.9

def default_snare(length: float = 0.25, sr: int = SR) -> np.ndarray:
    return no_id_snare(length, sr) * 0.9

# ---
# Producer -> routine mapping
# ---

ProducerDSP = Dict[str, Callable[..., np.ndarray]]

PRODUCER_DSP: Dict[str, ProducerDSP] = {
    'Pharrell': {
        'kick': timbaland_kick,
        'snare': timbaland_snare,
        'perc': timbaland_perc
    },
    'Timbaland': {
        'kick': timbaland_kick,
        'snare': timbaland_snare,
        'perc': timbaland_perc
    },
    'Zaytoven': {
        'kick': timbaland_kick,
        'snare': timbaland_snare,
        'perc': timbaland_perc
    },
    'Just Blaze': {
        'kick': default_kick,
        'snare': default_snare,
        'perc': timbaland_perc
    },
    'Missy Elliott': {
        'kick': timbaland_kick,
        'snare': timbaland_snare,
        'perc': timbaland_perc
    },
    'Dr. Dre': {
        'kick': djquik_kick,
        'snare': djquik_snare,
        'perc': djquik_snare
    },
    'J Dilla': {
        'kick': djquik_kick,
        'snare': no_id_snare,
        'perc': timbaland_perc
    },
    'Kanye West': {
        'kick': kanye_kick,
        'snare': kanye_snare,
        'perc': kanye_hihat
    },
    'DJ Quik': {
        'kick': djquik_kick,
        'snare': djquik_snare,
        'perc': djquik_snare
    },
    'No I.D.': {
        'kick': default_kick,
        'snare': no_id_snare,
        'perc': no_id_hihat
    },
    'Default': {
        'kick': default_kick,
        'snare': default_snare,
        'perc': timbaland_perc
    }
}

# ______
# High-level helpers
# ______

def render_drum_hit(producer: str, drum: str, **kwargs) -> np.ndarray:
    dsp = PRODUCER_DSP.get(producer, PRODUCER_DSP['Default'])
    fn = dsp.get(drum, PRODUCER_DSP['Default'].get(drum))
    if fn is None:
        raise ValueError(f"No DSP function for {producer} {drum}")
    return fn(**kwargs)

def mix_hits_to_bar(hits: list, bar_length: float = 1.0, sr: int = SR) -> np.ndarray:
    total = np.zeros(int(bar_length * sr))
    for hit in hits:
        pos = hit.get('pos', 0.0)
        sig = hit['sig']
        start = int(pos * sr)
        end = start + len(sig)
        if end > len(total):
            # truncate
            sig = sig[:len(total)-start]
            end = len(total)
        total[start:end] += sig
    return normalize(total)

def generate_simple_pattern(producer: str, pattern: Dict[str, list], bpm: int = 120, bars: int = 1, sr: int = SR) -> np.ndarray:
    seconds_per_beat = 60.0 / bpm
    bar_length = seconds_per_beat * 4
    out = np.zeros(int(bar_length * bars * sr))
    for b in range(bars):
        for drum, hits in pattern.items():
            for hit in hits:
                beat_pos = hit['beat'] # 0..(beats-1), fractional allowed
                pos_seconds = b * bar_length + beat_pos * seconds_per_beat
                sig = render_drum_hit(producer, drum)
                start = int(pos_seconds * sr)
                end = start + len(sig)
                if end > len(out):
                    sig = sig[:len(out)-start]
                    end = len(out)
                out[start:end] += sig
    return normalize(out)

# ______
# Example / quick test
# ______

if __name__ == '__main__':
    # quick smoke test to produce 4 bars of a simple trap-like pattern for Timbaland and Kanye 
    PATTERN = {
        'kick': [{'beat': 0.0}, {'beat': 1.5}, {'beat': 3.0}],
        'snare': [{'beat': 1.0}, {'beat': 3.0}],
        'perc': [{'beat': 0.75}, {'beat': 2.75}]
    }

    print("Rendering Timbaland 4-bar loop...")
    timb = generate_simple_pattern('Timbaland', PATTERN, bpm=140, bars=4, sr=SR)
    write_wav('timbaland_loop.wav', timb, SR)
    print("Saved timbaland_loop.wav")

    print("Rendering Kanye 4-bar loop...")
    kanye = generate_simple_pattern('Kanye West', PATTERN, bpm=140, bars=4, sr=SR)
    write_wav('kanye_loop.wav', kanye, SR)
    print("Saved kanye_loop.wav")

    print("Done.")
EOF

# Install npm dependencies
echo "📦 Installing npm dependencies..."
npm install

echo "✅ Setup complete!"
echo ""
echo "🎵 To start the AI Music Studio:"
echo "   cd ai-music-studio"
echo "   npm run dev"
echo ""
echo "🐍 To test the Python DSP module:"
echo "   cd ai-music-studio/python"
echo "   python producer_dsp.py"
echo ""
echo "📱 The app will be available at: http://localhost:3000"
echo "   (You may need to allow Termux to run on local network)"