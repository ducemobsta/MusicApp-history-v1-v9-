// In genreSampler.js, modify the exported API

export const GenreSamplerAPI = {
    // ... other functions
    triggerCustom(group, name, genre = 'soul') { // Add optional genre override
        if (players[group] && players[group].has(name)) {
            const player = players[group].player(name);
            player.start();
            routeToFX(player, genre); // Use the provided genre
        }
    },
    triggerKeyNote(note, duration = '4n', genre = 'ambient') { // New function for AI
        if (samplers.keys) {
            routeToFX(samplers.keys, genre);
            samplers.keys.triggerAttackRelease(note, duration);
        }
    },
    // ...
};