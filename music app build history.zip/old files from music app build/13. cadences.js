// Ensure cadences are musically satisfying
const ensureCadence = (chords, key) => {
  const scale = NOTE_MAP[key];
  const lastChord = chords[chords.length - 1];
  if (lastChord.notes[0].slice(0, -1) !== scale[0].slice(0, -1)) {
    chords.push({ time: `${chords.length}:0:0`, notes: [scale[0]], duration: '1m', section: 'outro', velocity: 0.7 });
  }
  return chords;
};

// Generate Harmony with cadence check
generateHarmony(scale, bars, spec, structure, settings) {
  const chords = [];
  // ... (existing code for generating chords)
  return { harmony: ensureCadence(chords, settings.key), progressionName: activeProgressionName };
}