#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "RealEngine.h" // Include the engine we created
#include <functional>

class MusicGeneratorVSTAudioProcessor : public juce::AudioProcessor,
                                        public juce::Timer // Inherit from Timer
{
public:
    MusicGeneratorVSTAudioProcessor();
    ~MusicGeneratorVSTAudioProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;
    bool acceptsMidi() const override;
    bool producesMidi() const override;
    double getTailLengthSeconds() const override;
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;
    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    // --- Custom Public Methods ---

    /**
     * @brief Starts the AI generation process. Called by the PluginEditor.
     * @param promptText The full prompt to be sent to the AI.
    */
    void startAIGeneration(const juce::String& promptText);

    /**
     * @brief A callback to notify the UI of status changes.
     * The editor can set this function to update its display.
    */
    std::function<void(const juce::String& newStatus, bool isError)> onStatusChanged;
    
    // The engine that contains all our music generation logic
    RealEngine realEngine;

private:
    // --- Timer Callback ---
    /**
     * @brief This function is called periodically by the juce::Timer
     * to check if the AI response file is ready.
    */
    void timerCallback() override;

    // --- File Bridge System ---
    // Paths to the files used for communication with the external script
    juce::File bridgeDir;
    juce::File promptFile;
    juce::File responseFile;
    juce::File statusFile;

    // --- Private Helper ---
    /**
     * @brief Parses the JSON response and triggers the music generation.
     * @param jsonText The raw JSON string from the response file.
    */
    void processAIResponse(const juce::String& jsonText);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MusicGeneratorVSTAudioProcessor)
};