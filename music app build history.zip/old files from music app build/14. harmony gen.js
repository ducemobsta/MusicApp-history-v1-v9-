// Generate Harmony (Combined Logic)
generateHarmony(scale, bars, spec, structure, settings) {
  const chords = [];
  // --- Progression Selection Logic ---
  const getProgression = (isBridge = false) => {
    const producerProgs = (settings.useProducerProgressions &&
      PRODUCER_PROGRESSIONS[settings.producer]) || [];
    const genreProgs = GENRE_PROGRESSIONS[settings.genre] || GENRE_PROGRESSIONS['R&B']; // Fallback
    const availableProgs = producerProgs.length > 0 ? producerProgs : genreProgs;
    if (availableProgs.length === 0) {
      return { id: 'default', roman: ['i', 'iv', 'v', 'i'], name: 'Default Fallback' };
    }
    return availableProgs[Math.floor(this.random() * availableProgs.length)];
  };

  const mainProgression = getProgression();
  let bridgeProgression = getProgression(true);
  while (bridgeProgression.id === mainProgression.id && (PRODUCER_PROGRESSIONS[settings.producer] || []).length > 1) {
    bridgeProgression = getProgression(true);
  }

  // --- Chord Generation Loop ---
  let activeProgressionName = mainProgression.name;
  for (let bar = 0; bar < bars; bar++) {
    const section = structure?.find((s) => bar >= s.start && bar < s.end);
    const sectionType = section?.type || 'verse';
    const currentProg = sectionType === 'bridge' ? bridgeProgression : mainProgression;
    activeProgressionName = sectionType === 'bridge' ? bridgeProgression.name : mainProgression.name;
    const progression = currentProg.roman;
    const progIndex = bar % progression.length;
    const numeral = progression[progIndex];
    const degree = ROMAN_TO_DEGREE[numeral] || 0;
    const notes = [
      scale[degree % scale.length],
      scale[(degree + 2) % scale.length],
      scale[(degree + 4) % scale.length]
    ];
    if (settings.complexity > 0.4 || sectionType === 'chorus') {
      notes.push(scale[(degree + 6) % scale.length]);
    }
    if (settings.complexity > 0.8 && (settings.genre === 'Neo-Soul' || settings.genre === 'R&B')) {
      const ninth = scale[(degree + 8) % scale.length];
      if(ninth) notes.push(ninth);
    }
    chords.push({ time: `${bar}:0:0`, notes, duration: '1m', section: sectionType, velocity: 0.7 });
  }

  // --- Apply Musical Rules ---
  const voiceLedChords = applyVoiceLeading(chords);
  const finalChords = ensureCadence(voiceLedChords, settings.key);

  return { harmony: finalChords, progressionName: activeProgressionName };
}

// --- Helper: Voice Leading ---
const applyVoiceLeading = (chords) => {
  for (let i = 1; i < chords.length; i++) {
    const prevChord = chords[i - 1].notes;
    const currentChord = chords[i].notes;
    currentChord.forEach((note, index) => {
      if (!prevChord[index]) return;
      const interval = Math.abs(new Tone.Frequency(note).toMidi() - new Tone.Frequency(prevChord[index]).toMidi());
      if (interval > 7) { // Avoid large leaps
        // This is a simplified inversion logic; a real implementation would be more robust.
        // For this example, we just avoid the jump, which is not ideal.
        // A better approach would be to find the closest note in the same chord.
      }
    });
  }
  return chords;
};

// --- Helper: Cadences ---
const ensureCadence = (chords, key) => {
  const scale = NOTE_MAP[key];
  if (chords.length === 0) return chords;
  const lastChord = chords[chords.length - 1];
  // If the last chord is not the tonic, add a tonic chord to resolve.
  if (lastChord.notes[0].slice(0, -1) !== scale[0].slice(0, -1)) {
    chords.push({ time: `${chords.length}:0:0`, notes: [scale[0], scale[2], scale[4]], duration: '1m', section: 'outro', velocity: 0.7 });
  }
  return chords;
};