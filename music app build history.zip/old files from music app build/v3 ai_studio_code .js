import React, { useState, useCallback, useRef, useEffect } from 'react';
import * as Tone from 'tone';
import { PRODUCER_PROGRESSIONS, GENRE_PROGRESSIONS } from './data/chordProgressions';
import JSZip from 'jszip'; // For zipping stems
import { saveAs } from 'file-saver'; // For saving files

// --- UPDATED TYPES ---
type Genre = 'Trap' | 'Trap-Soul' | 'R&B' | 'Soul' | '90s Rap' | 'Lo-fi' | 'Drill' | 'G-Funk' | 'Neo-Soul';
type Producer = 'Pharrell' | 'Timbaland' | 'Zaytoven' | 'Just Blaze' | 'Missy Elliott' | 'Dr. Dre' | 'J Dilla' | 'Kanye West' | 'DJ Quik' | 'No I.D.' | 'Default';
type AgentStatus = 'idle' | 'processing' | 'complete' | 'error';
type SongStructure = 'intro' | 'verse' | 'chorus' | 'bridge' | 'outro';
type MelodicContour = 'arch' | 'rising' | 'falling' | 'random';

// --- NEW FEATURE: Energy Curve & Producer Mix ---
interface GenerationSettings {
  genre: Genre;
  producer: Producer;
  producerB: Producer; // Second producer for mixing
  producerMix: number; // 0 = 100% A, 1 = 100% B
  key: string;
  tempo: number;
  duration: number;
  complexity: number;
  variation: number;
  useStructure: boolean;
  melodicContour: MelodicContour;
  energyCurve: { verse: number; chorus: number; bridge: number; };
  useLoFiVinyl: boolean;
  seed: string;
  // Real-time tweakable params
  reverbMix: number;
  saturation: number;
}

interface Agent {
  name: string;
  status: AgentStatus;
  output: any;
  message: string;
}

interface UploadedSample {
  name: string;
  type: 'wav' | 'midi' | 'ogg';
  buffer: AudioBuffer | null;
  url: string;
}

// --- UPDATED INSTRUMENT PATCHES (with layering) ---
// ... (Instrument patches remain the same as previous version)

// --- UPDATED PRODUCER SPECS (with detailed profiles & layering) ---
const PRODUCER_SPECS: Record<Producer, any> = {
  'Pharrell': {
    effects: { saturation: 0.2, reverb: { mix: 0.3, decay: 1.2 } },
    rhythm: { swing: 0.4, humanization: { timing: 0.02, velocity: 0.1 } },
    signature: '✨ Minimalist funk, metallic drums',
    patches: { lead: ['future-pluck'], bass: ['quik-moog-bass'], pad: ['alicia-breath-pad'] }
  },
  'Timbaland': {
    effects: { saturation: 0.6, reverb: { mix: 0.25, decay: 0.8 } },
    rhythm: { swing: 0.7, humanization: { timing: 0.06, velocity: 0.3 } },
    signature: '⚡ Stuttering rhythms, vocal chops',
    patches: { lead: ['quik-pluck-lead'], bass: ['808-glide'], pad: ['alicia-breath-pad'] }
  },
  'J Dilla': {
    effects: { saturation: 0.3, reverb: { mix: 0.3, decay: 0.8 } },
    rhythm: { swing: 0.6, humanization: { timing: 0.08, velocity: 0.25 } },
    signature: '📼 Off-kilter rhythms, jazz chords',
    patches: { 
      lead: ['alicia-wurli'], 
      bass: ['alicia-bass'], 
      // --- NEW FEATURE: Instrument Blending ---
      pad: ['alicia-breath-pad', 'analog-brass'] 
    }
  },
  // ... (Fill in other producers with the new structure)
  'Default': {
    effects: { saturation: 0.4, reverb: { mix: 0.3, decay: 1.5 } },
    rhythm: { swing: 0.3, humanization: { timing: 0.01, velocity: 0.1 } },
    signature: '⚖️ Balanced, clean production',
    patches: { lead: ['future-pluck'], bass: ['quik-moog-bass'], pad: ['alicia-breath-pad'] }
  }
};

// ... (GENRE_SPECS, NOTE_MAP, ROMAN_TO_DEGREE are unchanged)

class MusicGenerator {
  // --- NEW FEATURE: Seedable Randomness ---
  private random: () => number;

  constructor(seed: string) {
    let h = 1779033703, i = 0, k;
    for (; i < seed.length; i++) {
        h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
        k = h << 13 | h >>> 19;
    }
    this.random = () => {
      h = Math.imul(h ^ h >>> 16, 2246822507);
      h = Math.imul(h ^ h >>> 13, 3266489909);
      return ((h ^= h >>> 16) >>> 0) / 4294967296;
    };
  }
  
  // --- NEW FEATURE: Producer Blending ---
  private blendProducers(pA: any, pB: any, mix: number) {
    if (!pB || mix === 0) return pA;
    if (mix === 1) return pB;
    const blend = (valA: number, valB: number) => valA * (1 - mix) + valB * mix;
    return {
      effects: {
        saturation: blend(pA.effects.saturation, pB.effects.saturation),
        reverb: { 
          mix: blend(pA.effects.reverb.mix, pB.effects.reverb.mix),
          decay: blend(pA.effects.reverb.decay, pB.effects.reverb.decay)
        }
      },
      rhythm: {
        swing: blend(pA.rhythm.swing, pB.rhythm.swing),
        humanization: {
          timing: blend(pA.rhythm.humanization.timing, pB.rhythm.humanization.timing),
          velocity: blend(pA.rhythm.humanization.velocity, pB.rhythm.humanization.velocity),
        }
      },
      patches: mix < 0.5 ? pA.patches : pB.patches, // Simple patch selection
      signature: `${Math.round((1-mix)*100)}% ${pA.signature} + ${Math.round(mix*100)}% ${pB.signature}`
    }
  }

  async generate(settings: GenerationSettings, onUpdate: (name: string, status: AgentStatus, message?: string) => void, samples: UploadedSample[]) {
    const spec = GENRE_SPECS[settings.genre];
    const producerA = PRODUCER_SPECS[settings.producer] || PRODUCER_SPECS['Default'];
    const producerB = PRODUCER_SPECS[settings.producerB] || PRODUCER_SPECS['Default'];
    const producer = this.blendProducers(producerA, producerB, settings.producerMix);

    const scale = NOTE_MAP[settings.key] || NOTE_MAP['A minor'];
    const bars = Math.ceil((settings.tempo / 60) * settings.duration / 4);

    onUpdate('Theme Director', 'processing', 'Defining blended mood...');
    const theme = { mood: producer.signature, key: settings.key };
    await this.delay(200);
    onUpdate('Theme Director', 'complete', `Mood: ${producer.signature}`);

    // --- CONCEPTUAL HOOK: Adaptive Key Modulation ---
    // Here you would analyze the energy curve to plan key changes.
    // e.g., if energyCurve.bridge > energyCurve.verse, plan a modulation
    // to a related key (e.g., up a 4th) for the bridge section.
    // The `currentKey` would then be passed to harmony/melody agents.
    
    onUpdate('Structure Architect', 'processing', 'Planning song sections...');
    const structure = settings.useStructure ? this.generateStructure(bars, spec.structure) : null;
    await this.delay(200);
    onUpdate('Structure Architect', 'complete', `Created a ${structure ? structure.length : 'linear'}-part structure.`);

    onUpdate('Harmony Designer', 'processing', 'Selecting chord progressions...');
    const harmony = this.generateHarmony(scale, bars, structure, settings);
    await this.delay(300);
    onUpdate('Harmony Designer', 'complete', `Using a ${settings.producer}-style progression.`);

    onUpdate('Rhythm Architect', 'processing', 'Building groove based on energy curve...');
    const rhythm = this.generateRhythm(bars, spec, structure, producer.rhythm, settings.energyCurve);
    await this.delay(300);
    onUpdate('Rhythm Architect', 'complete', 'Rhythm section crafted.');

    onUpdate('Melody Composer', 'processing', 'Composing and mutating motifs...');
    const melody = this.generateMelody(scale, bars, harmony, structure, settings);
    await this.delay(300);
    onUpdate('Melody Composer', 'complete', 'Melody finished.');

    onUpdate('Audio Synthesizer', 'processing', 'Layering instrument patches...');
    await this.delay(200);
    onUpdate('Audio Synthesizer', 'complete', 'Synths are ready.');

    return {
      rhythm, harmony, melody,
      bass: this.generateBass(harmony, structure),
      tempo: settings.tempo,
      producer: settings.producer,
      mixParams: producer,
      patches: producer.patches,
      bars, duration: settings.duration, samples, structure,
      // --- NEW: Stems for Export ---
      stems: {
          melody: melody,
          harmony: harmony,
          bass: this.generateBass(harmony, structure),
          drums: { kick: rhythm.kick, snare: rhythm.snare, hihat: rhythm.hihat }
      }
    };
  }
  
  generateStructure(totalBars: number, template: any) { /* ... unchanged ... */ return []; }
  
  generateRhythm(bars: number, spec: any, structure: any, rhythmProfile: any, energyCurve: any) {
    const patterns: any = { kick: [], snare: [], hihat: [] };
    // ... main rhythm logic ...
    for (let b = 0; b < bars; b++) {
      const section = structure?.find((s: any) => b >= s.start && b < s.end);
      const sectionType = section?.type || 'verse';

      // --- NEW FEATURE: Energy Curve ---
      const energyMultiplier = energyCurve[sectionType] || 1.0;

      for (let i = 0; i < 16; i++) {
        if (this.random() > energyMultiplier) continue; // Skip notes based on energy

        // --- NEW FEATURE: Humanization Profiles ---
        const humanize = (this.random() - 0.5) * rhythmProfile.humanization.timing;
        const velocity = (1 - rhythmProfile.humanization.velocity) + (this.random() * rhythmProfile.humanization.velocity);
        
        // ... (rest of kick/snare/hihat logic using new humanize/velocity)
      }
    }
    return patterns;
  }
  
  generateHarmony(scale: string[], bars: number, structure: any, settings: GenerationSettings) { /* ... unchanged ... */ return []; }

  // --- NEW FEATURE: Phrase Memory (Motif Generation) ---
  mutateMotif(motif: any[], scale: string[]) {
      const mutated = JSON.parse(JSON.stringify(motif));
      const action = this.random();
      if (action < 0.3) { // Transpose
          const interval = Math.floor(this.random() * 3) - 1;
          mutated.forEach((n: any) => {
              const currentIdx = scale.findIndex(sn => sn === n.note);
              n.note = scale[(currentIdx + interval + scale.length) % scale.length];
          });
      } else if (action < 0.6) { // Invert rhythm
          mutated.reverse();
      } // else: keep as is
      return mutated;
  }

  generateMelody(scale: string[], bars: number, harmony: any[], structure: any, settings: GenerationSettings) {
    const notes = [];
    let motif: any[] | null = null;
    
    for (let b = 0; b < bars; b++) {
      const section = structure?.find((s: any) => b >= s.start && b < s.end);
      const sectionType = section?.type || 'verse';

      // --- USE OR CREATE MOTIF ---
      if (sectionType === 'verse') {
        if (motif && this.random() < 0.6) { // Reuse/mutate motif
            const currentMotif = this.mutateMotif(motif, scale);
            // ... add currentMotif notes to the `notes` array for this bar
            continue; // Skip to next bar
        }
      }
      
      // ... (Original melody generation logic)

      // --- STORE MOTIF ---
      if (sectionType === 'verse' && !motif) {
          // motif = ... store the notes generated for this bar
      }
    }
    return notes;
  }
  
  generateBass(harmony: any[], structure: any) { /* ... unchanged ... */ return []; }

  delay(ms: number) { return new Promise(resolve => setTimeout(resolve, ms)); }
}

// --- NEW FEATURE: Audio Service with Stem Rendering and Real-time Controls ---
class AudioService {
    // ... (Most of AudioService is the same, with key changes below)
    private reverb: Tone.Reverb | null = null;
    private distortion: Tone.Distortion | null = null;
    private vinylPlayer: Tone.Player | null = null;

    // --- Real-time control methods ---
    setReverbMix(wet: number) { if (this.reverb) this.reverb.wet.value = wet; }
    setSaturation(amount: number) { if (this.distortion) this.distortion.distortion = amount; }
    toggleVinyl(active: boolean, url: string = 'URL_TO_VINYL_CRACKLE_LOOP') {
        if (active && !this.vinylPlayer) {
            this.vinylPlayer = new Tone.Player(url).toDestination();
            this.vinylPlayer.loop = true;
            this.vinylPlayer.volume.value = -24;
            this.vinylPlayer.autostart = true;
        } else if (!active && this.vinylPlayer) {
            this.vinylPlayer.stop();
            this.vinylPlayer.dispose();
            this.vinylPlayer = null;
        }
    }

    // --- Updated `schedule` to handle layered patches ---
    async schedule(comp: any) {
        // ... (setup is the same)
        const createSynthLayer = (patchNames: string[], masterChain: any) => {
            const synths = patchNames.map(p => this.createSynth(p, masterChain)).filter(Boolean);
            return (notes: any, duration: any, time: any, velocity: number = 1) => {
                // Probabilistically trigger layers
                synths.forEach(synth => {
                    if (Math.random() > 0.3) { // 70% chance to play each layer
                        synth.triggerAttackRelease(notes, duration, time, velocity * (0.8 + Math.random() * 0.2));
                    }
                });
            };
        };

        const chordPlayer = createSynthLayer(comp.patches.pad, masterChain);
        this.parts.push(new Tone.Part((time, c) => {
            chordPlayer(c.notes, c.duration, time);
        }, comp.harmony).start(0));

        // ... (rest of scheduling)
    }

    // --- NEW: Offline Stem Export ---
    async exportStems(composition: any): Promise<Record<string, Blob>> {
        const stems: Record<string, Blob> = {};
        const duration = composition.duration;

        const renderStem = async (part: string) => {
            const buffer = await Tone.Offline(async (transport) => {
                // Create only the synths needed for this part
                const synth = this.createSynth(composition.patches[part], transport.destination);
                new Tone.Part((time, note) => {
                    synth.triggerAttackRelease(note.note, note.duration, time, note.velocity);
                }, composition.stems[part]).start(0);

                transport.Transport.bpm.value = composition.tempo;
                transport.Transport.start();
            }, duration);
            return new Blob([buffer.get().buffer], { type: 'audio/wav' });
        };

        stems.melody = await renderStem('melody');
        // ... Render other stems (harmony, bass, drums) similarly ...
        
        return stems;
    }
}


export default function App() {
  const [settings, setSettings] = useState<GenerationSettings>({
    genre: 'Lo-fi', producer: 'J Dilla', producerB: 'Timbaland', producerMix: 0,
    key: 'A minor', tempo: 85, duration: 120, complexity: 0.6, variation: 0.5,
    useStructure: true, melodicContour: 'arch', 
    energyCurve: { verse: 0.8, chorus: 1.0, bridge: 0.7 },
    useLoFiVinyl: true, seed: '1337',
    reverbMix: PRODUCER_SPECS['J Dilla'].effects.reverb.mix, 
    saturation: PRODUCER_SPECS['J Dilla'].effects.saturation
  });
  
  // ... (Other state variables: agents, isPlaying, etc.)
  const audioServiceRef = useRef<AudioService | null>(null);

  // --- NEW FEATURE: Real-time control effects ---
  useEffect(() => {
      audioServiceRef.current?.setReverbMix(settings.reverbMix);
  }, [settings.reverbMix]);
  
  useEffect(() => {
      audioServiceRef.current?.setSaturation(settings.saturation);
  }, [settings.saturation]);

  useEffect(() => {
      audioServiceRef.current?.toggleVinyl(settings.useLoFiVinyl);
  }, [settings.useLoFiVinyl]);

  // --- NEW FEATURE: Producer DNA calculation ---
  const getProducerDNA = (producer: Producer) => {
    const progs = PRODUCER_PROGRESSIONS[producer] || [];
    const chordCounts: Record<string, number> = {};
    progs.forEach(p => {
        p.roman.forEach(r => {
            const cleanR = r.replace(/[^IVivb]/g, ''); // Simplify numeral
            chordCounts[cleanR] = (chordCounts[cleanR] || 0) + 1;
        });
    });
    const spec = PRODUCER_SPECS[producer];
    return { chords: chordCounts, rhythm: spec.rhythm };
  }

  const handleGenerate = async () => {
    setIsGenerating(true);
    // ...
    const currentSeed = settings.seed || Date.now().toString();
    if (!settings.seed) setSettings(s => ({...s, seed: currentSeed }));
    
    // Pass seed to generator
    const generator = new MusicGenerator(currentSeed);
    const comp = await generator.generate(settings, onUpdate, uploadedSamples);
    // ...
  };

  const handleDownload = async () => {
    if (!composition) return;
    setIsExporting(true);
    const stems = await audioServiceRef.current?.exportStems(composition);

    if (stems) {
        const zip = new JSZip();
        zip.file("melody.wav", stems.melody);
        // zip.file("harmony.wav", stems.harmony);
        // zip.file("bass.wav", stems.bass);
        // zip.file("drums.wav", stems.drums);
        
        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, `stems_${settings.seed}.zip`);
    }
    setIsExporting(false);
  };

  // --- JSX with new controls ---
  return (
    <div /* main container */>
      {/* ... Header ... */}
      <div /* grid container */>
        <div /* settings panel */>
          {/* ... Genre, Producer A, Key, Tempo ... */}

          {/* --- NEW: Producer B & Mix Slider --- */}
          <div>
            <label>Producer B (for blending)</label>
            <select value={settings.producerB} onChange={e => setSettings(s => ({ ...s, producerB: e.target.value as Producer }))}>
                {Object.keys(PRODUCER_SPECS).map(p => (<option key={p} value={p}>{p}</option>))}
            </select>
          </div>
          <div>
            <label>Producer Mix: {Math.round(settings.producerMix * 100)}% B</label>
            <input type="range" min="0" max="1" step="0.01" value={settings.producerMix}
                   onChange={e => setSettings(s => ({ ...s, producerMix: parseFloat(e.target.value) }))}/>
          </div>
          
          {/* --- NEW: Energy Curve Sliders --- */}
          <div>
            <label>Energy - Verse: {settings.energyCurve.verse * 100}%</label>
            <input type="range" min="0.5" max="1.2" step="0.1" value={settings.energyCurve.verse}
                   onChange={e => setSettings(s => ({ ...s, energyCurve: { ...s.energyCurve, verse: parseFloat(e.target.value)} }))}/>
          </div>
          <div>
            <label>Energy - Chorus: {settings.energyCurve.chorus * 100}%</label>
            <input type="range" min="0.8" max="1.5" step="0.1" value={settings.energyCurve.chorus}
                   onChange={e => setSettings(s => ({ ...s, energyCurve: { ...s.energyCurve, chorus: parseFloat(e.target.value)} }))}/>
          </div>

          {/* --- NEW: Seed Input --- */}
          <div>
            <label>Generation Seed</label>
            <input type="text" value={settings.seed} onChange={e => setSettings(s => ({ ...s, seed: e.target.value }))}
                   placeholder="Leave empty for random" />
          </div>

          <button onClick={handleGenerate}>Generate</button>
          <button onClick={handleDownload} disabled={!composition || isExporting}>
            {isExporting ? 'Exporting Stems...' : 'Export Stems'}
          </button>
        </div>
        
        <div /* Center column for player & agents */>
            {/* ... Player, Canvas, Agents ... */}
            {/* --- NEW: Real-time Knobs --- */}
            <div>
                <label>Reverb: {Math.round(settings.reverbMix * 100)}%</label>
                <input type="range" min="0" max="1" step="0.01" value={settings.reverbMix}
                       onChange={e => setSettings(s => ({ ...s, reverbMix: parseFloat(e.target.value) }))} />
            </div>
            <div>
                <label>Saturation: {Math.round(settings.saturation * 100)}%</label>
                <input type="range" min="0" max="1" step="0.01" value={settings.saturation}
                       onChange={e => setSettings(s => ({ ...s, saturation: parseFloat(e.target.value) }))} />
            </div>
             <div>
                <input type="checkbox" id="lofi-vinyl" checked={settings.useLoFiVinyl}
                       onChange={e => setSettings(s => ({...s, useLoFiVinyl: e.target.checked}))} />
                <label htmlFor="lofi-vinyl">Lo-fi Mode</label>
            </div>
        </div>

        <div /* Right column for new panels */>
            {/* --- NEW: Piano Roll Placeholder --- */}
            <div className="piano-roll-container">
                <h3>Melody Piano Roll</h3>
                <div className="roll-content">
                    {/* Here you would map over composition.stems.melody and render divs */}
                    <p>Piano Roll visualization would appear here.</p>
                </div>
            </div>

            {/* --- NEW: Producer DNA Panel --- */}
            <div className="dna-panel">
                <h3>Producer DNA: {settings.producer}</h3>
                {(() => {
                    const dna = getProducerDNA(settings.producer);
                    return (
                        <div>
                            <p><strong>Rhythm Profile:</strong></p>
                            <span>Swing: {dna.rhythm.swing * 100}% | </span>
                            <span>Timing Humanization: {dna.rhythm.humanization.timing * 1000}ms</span>
                            <p><strong>Common Chords:</strong></p>
                            <ul>
                                {Object.entries(dna.chords).map(([chord, count]) => (
                                    <li key={chord}>{chord}: {count} uses</li>
                                ))}
                            </ul>
                        </div>
                    );
                })()}
            </div>
        </div>
      </div>
    </div>
  );
}