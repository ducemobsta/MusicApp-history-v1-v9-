// Generate Melody with improved melodic movement
generateMelody(scale, bars, harmony, structure, complexity, contour) {
  const notes = [];
  let currentIdx = Math.floor(scale.length / 2);
  for (let b = 0; b < bars; b++) {
    const section = structure?.find((s) => b >= s.start && b < s.end);
    const sectionType = section?.type || 'verse';
    const currentChord = harmony.find(c => c.time === `${b}:0:0`);
    if (!currentChord) continue;
    const chordRoot = currentChord.notes[0].slice(0, -1);
    currentIdx = Math.max(0, scale.findIndex(n => n.startsWith(chordRoot)));
    const playChance = sectionType === 'intro' ? 0.4 :
      sectionType === 'outro' ? 0.3 :
      sectionType === 'chorus' ? 0.8 : 0.65;
    const subdivision = (sectionType === 'chorus' || complexity > 0.7) ? 8 : 4;
    for (let i = 0; i < subdivision; i++) {
      if (this.random() < playChance) {
        let stepDirection = this.random() < 0.5 ? -1 : 1;
        if (contour === 'rising') stepDirection = 1;
        if (contour === 'falling') stepDirection = -1;
        if (contour === 'arch') stepDirection = (i < subdivision / 2) ? 1 : -1;
        const stepSize = this.random() < 0.6 ? 1 : 2;
        const step = stepDirection * stepSize;
        currentIdx = (currentIdx + step + scale.length) % scale.length;
        const note = scale[currentIdx];
        const duration = this.random() < 0.4 ? '8n' : '16n';
        const velocity = (0.5 + this.random() * 0.3) * (sectionType === 'chorus' ? 1.2 : 1.0);
        notes.push({
          time: `${b}:${Math.floor(i * 4 / subdivision)}:${Math.floor((i * 4 / subdivision % 1) * 4)}`,
          note, duration, velocity, section: sectionType
        });
      }
    }
  }
  return notes;
}