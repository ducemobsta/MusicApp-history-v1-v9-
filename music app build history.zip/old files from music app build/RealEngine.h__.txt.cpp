#pragma once

#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_midi/juce_midi.h>
#include <string>
#include <vector>
#include <map>

// Internal representation of a chord event for easier processing
struct ChordEvent {
    double timeInBars;
    std::vector<int> midiNotes;
    std::vector<std::string> noteNames;
};

class RealEngine
{
public:
    // The final MIDI file will be stored here
    juce::MidiFile midiFile;

    // Main generation function
    void generate(const std::string& key,
                  const std::vector<std::string>& progression,
                  int tempo,
                  int bars,
                  double complexity,
                  double swing,
                  const std::string& seed);

private:
    // --- Pseudo-Random Number Generator (PRNG) ---
    // This is a direct C++ port of the JavaScript PRNG to ensure identical output for a given seed.
    uint32_t prng_h;
    void seedPrng(const std::string& seed);
    double random();

    // --- Music Theory Data ---
    // Static maps to hold musical constants like scales and Roman numeral mappings.
    static const std::map<std::string, std::vector<std::string>> NOTE_MAP;
    static const std::map<std::string, int> ROMAN_TO_DEGREE;
    
    // --- Utility Functions ---
    // Converts a note name (e.g., "C#4") into its corresponding MIDI note number.
    int noteNameToMidi(const std::string& noteName);

    // --- Core Generation Logic ---
    // These private methods mirror the structure of the original JavaScript MusicGenerator class.
    std::vector<ChordEvent> generateHarmony(const std::vector<std::string>& scale, int bars, const std::vector<std::string>& progressionNumerals);
    void addHarmonyToMidi(juce::MidiMessageSequence& track, const std::vector<ChordEvent>& harmony, int ppqn);
    void generateLeadMelody(juce::MidiMessageSequence& track, const std::vector<std::string>& scale, int bars, const std::vector<ChordEvent>& harmony, double complexity, int ppqn);
    void generateBass(juce::MidiMessageSequence& track, const std::vector<ChordEvent>& harmony, int ppqn);
    void generateRhythm(juce::MidiMessageSequence& kickTrack, juce::MidiMessageSequence& snareTrack, juce::MidiMessageSequence& hihatTrack, int bars, int ppqn);
};