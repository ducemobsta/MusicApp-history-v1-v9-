import React, { useState, useCallback, useRef, useEffect } from 'react';
import * as Tone from 'tone';
import { PRODUCER_PROGRESSIONS, GENRE_PROGRESSIONS } from './data/chordProgressions'; // <-- NEW IMPORT

// Types
type Genre = 'Trap' | 'Trap-Soul' | 'R&B' | 'Soul' | '90s Rap' | 'Lo-fi' | 'Drill' | 'G-Funk' | 'Neo-Soul';
type Producer = 'Pharrell' | 'Timbaland' | 'Zaytoven' | 'Just Blaze' | 'Missy Elliott' | 'Dr. Dre' | 'J Dilla' | 'Kanye West' | 'DJ Quik' | 'No I.D.' | 'Default';
type AgentStatus = 'idle' | 'processing' | 'complete' | 'error';
type SongStructure = 'intro' | 'verse' | 'chorus' | 'bridge' | 'outro';
type MelodicContour = 'arch' | 'rising' | 'falling' | 'random';

interface GenerationSettings {
  genre: Genre;
  producer: Producer;
  key: string;
  tempo: number;
  duration: number;
  complexity: number;
  variation: number;
  useStructure: boolean;
  // NEW Advanced Settings
  melodicContour: MelodicContour;
  rhythmicDensity: number;
  useProducerProgressions: boolean;
}

interface Agent {
  name: string;
  status: AgentStatus;
  output: any;
  message: string; // <-- NEW: For agent's "thoughts"
}

interface UploadedSample {
  name: string;
  type: 'wav' | 'midi' | 'ogg';
  buffer: AudioBuffer | null;
  url: string;
}

// INSTRUMENT PATCHES
const INSTRUMENT_PATCHES: Record<string, any> = {
  'quik-pluck-lead': {
    type: 'MonoSynth',
    config: {
      oscillator: { type: 'sawtooth' },
      envelope: { attack: 0.006, decay: 0.09, sustain: 0.15, release: 0.08 },
      filter: { type: 'lowpass', frequency: 3200, Q: 0.8 },
      filterEnvelope: { attack: 0.01, decay: 0.08, sustain: 0.2, release: 0.1, baseFrequency: 300, octaves: 2.5 },
      volume: -6
    }
  },
  'quik-moog-bass': {
    type: 'MonoSynth',
    config: {
      portamento: 0.08, // <-- Added for bass slides
      oscillator: { type: 'sine' },
      envelope: { attack: 0.01, decay: 0.22, sustain: 0.85, release: 0.25 },
      filter: { type: 'lowpass', frequency: 220, Q: 1.2 },
      filterEnvelope: { attack: 0.02, decay: 0.1, sustain: 1, baseFrequency: 200, octaves: 1 },
      volume: -4
    }
  },
  'quik-wah-keys': {
    type: 'MonoSynth',
    config: {
      oscillator: { type: 'square' },
      envelope: { attack: 0.02, decay: 0.18, sustain: 0.6, release: 0.22 },
      filter: { type: 'bandpass', frequency: 800, Q: 6 },
      filterEnvelope: { attack: 0.1, decay: 0.2, sustain: 0.5, baseFrequency: 400, octaves: 3 },
      volume: -7
    }
  },
  'alicia-wurli': {
    type: 'PolySynth',
    config: {
      oscillator: { type: 'triangle' },
      envelope: { attack: 0.008, decay: 0.6, sustain: 0.7, release: 0.9 },
      filter: { type: 'lowpass', frequency: 6000, Q: 0.7 },
      volume: -2
    }
  },
  'alicia-breath-pad': {
    type: 'PolySynth',
    config: {
      oscillator: { type: 'sine' },
      envelope: { attack: 0.4, decay: 0.8, sustain: 0.7, release: 1.8 },
      filter: { type: 'lowpass', frequency: 2400, Q: 0.6 },
      filterEnvelope: { attack: 0.2, decay: 0.6, sustain: 0.5, baseFrequency: 500, octaves: 2 },
      volume: -9
    }
  },
  'alicia-bass': {
    type: 'MonoSynth',
    config: {
      oscillator: { type: 'triangle' },
      envelope: { attack: 0.02, decay: 0.6, sustain: 0.85, release: 0.5 },
      filter: { type: 'lowpass', frequency: 250, Q: 1 },
      volume: -4
    }
  },
  'analog-brass': {
    type: 'PolySynth',
    config: {
      oscillator: { type: 'sawtooth' },
      envelope: { attack: 0.05, decay: 0.3, sustain: 0.6, release: 0.4 },
      filter: { type: 'lowpass', frequency: 2800, Q: 1.5 },
      volume: -8
    }
  },
  'future-pluck': {
    type: 'MonoSynth',
    config: {
      oscillator: { type: 'triangle' },
      envelope: { attack: 0.002, decay: 0.08, sustain: 0.1, release: 0.06 },
      filter: { type: 'lowpass', frequency: 4000, Q: 2 },
      volume: -10
    }
  },
  '808-glide': {
    type: 'MonoSynth',
    config: {
      portamento: 0.05, // <-- Added for Drill 808 slides
      oscillator: { type: 'sine' },
      envelope: { attack: 0.001, decay: 0.4, sustain: 0, release: 0.2 },
      filter: { type: 'lowpass', frequency: 150, Q: 2 },
      volume: -2
    }
  }
};

// PRODUCER PROFILES
const PRODUCER_SPECS: Record<Producer, any> = {
  'Pharrell': {
    saturation: 0.2, reverb: { mix: 0.3, decay: 1.2 }, swing: 0.4,
    signature: '✨ Minimalist funk, metallic drums',
    patches: { lead: 'future-pluck', bass: 'quik-moog-bass', pad: 'alicia-breath-pad' }
  },
  'Timbaland': {
    saturation: 0.6, reverb: { mix: 0.25, decay: 0.8 }, swing: 0.7,
    signature: '⚡ Stuttering rhythms, vocal chops',
    patches: { lead: 'quik-pluck-lead', bass: '808-glide', pad: 'alicia-breath-pad' }
  },
  'Zaytoven': {
    saturation: 0.9, reverb: { mix: 0.4, decay: 1.5 }, swing: 0.2,
    signature: '🎹 Piano melodies, aggressive 808s',
    patches: { lead: 'alicia-wurli', bass: '808-glide', pad: 'analog-brass' }
  },
  'Just Blaze': {
    saturation: 0.3, reverb: { mix: 0.5, decay: 2.5 }, swing: 0.5,
    signature: '🎺 Soulful samples, orchestral hits',
    patches: { lead: 'analog-brass', bass: 'alicia-bass', pad: 'alicia-breath-pad' }
  },
  'Missy Elliott': {
    saturation: 0.8, reverb: { mix: 0.35, decay: 1.0 }, swing: 0.8,
    signature: '🚀 Experimental, layered',
    patches: { lead: 'future-pluck', bass: '808-glide', pad: 'alicia-breath-pad' }
  },
  'Dr. Dre': {
    saturation: 0.7, reverb: { mix: 0.4, decay: 2.0 }, swing: 0.5,
    signature: '🌴 G-Funk, deep bass, synth strings',
    patches: { lead: 'quik-pluck-lead', bass: 'quik-moog-bass', pad: 'analog-brass' }
  },
  'J Dilla': {
    saturation: 0.3, reverb: { mix: 0.3, decay: 0.8 }, swing: 0.6,
    signature: '📼 Off-kilter rhythms, jazz chords',
    patches: { lead: 'alicia-wurli', bass: 'alicia-bass', pad: 'alicia-breath-pad' }
  },
  'Kanye West': {
    saturation: 0.5, reverb: { mix: 0.6, decay: 3.0 }, swing: 0.4,
    signature: '🙏 Soul samples, orchestral swells',
    patches: { lead: 'analog-brass', bass: 'alicia-bass', pad: 'alicia-breath-pad' }
  },
  'DJ Quik': {
    saturation: 0.4, reverb: { mix: 0.35, decay: 1.5 }, swing: 0.6,
    signature: '🌊 West Coast G-Funk, smooth grooves',
    patches: { lead: 'quik-pluck-lead', bass: 'quik-moog-bass', pad: 'quik-wah-keys' }
  },
  'No I.D.': {
    saturation: 0.3, reverb: { mix: 0.4, decay: 1.8 }, swing: 0.5,
    signature: '💎 Soulful sampling, warm tones',
    patches: { lead: 'alicia-wurli', bass: 'alicia-bass', pad: 'alicia-breath-pad' }
  },
  'Default': {
    saturation: 0.4, reverb: { mix: 0.3, decay: 1.5 }, swing: 0.3,
    signature: '⚖️ Balanced, clean production',
    patches: { lead: 'future-pluck', bass: 'quik-moog-bass', pad: 'alicia-breath-pad' }
  }
};

const GENRE_SPECS: Record<Genre, any> = {
  'Trap': {
    bpm: { min: 130, max: 170, common: 140 },
    scales: ['A minor', 'C# minor', 'F minor'],
    description: '🔥 Hard-hitting 808s, rapid hi-hats',
    kickPattern: [1,0,0,0,1,0,1,0, 0,0,1,0,1,0,0,0],
    snarePattern: [0,0,0,0,1,0,0,0, 0,0,0,0,1,0,0,0],
    hihatDensity: 'high',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  },
  'Trap-Soul': {
    bpm: { min: 60, max: 100, common: 80 },
    scales: ['A minor', 'D minor'],
    description: '💔 Emotional melodies, smooth 808s',
    kickPattern: [1,0,0,0,1,0,0,0],
    snarePattern: [0,0,0,0,1,0,0,0],
    hihatDensity: 'medium',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  },
  'R&B': {
    bpm: { min: 90, max: 120, common: 95 },
    scales: ['C major', 'G major'],
    description: '✨ Smooth grooves, extended chords',
    kickPattern: [1,0,0,0,1,0,0,0],
    snarePattern: [0,0,1,0,0,0,1,0],
    hihatDensity: 'medium',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  },
  'Soul': {
    bpm: { min: 90, max: 120, common: 95 },
    scales: ['C major', 'F major'],
    description: '🙏 Gospel-inspired, warm',
    kickPattern: [1,0,0,0,1,0,0,0],
    snarePattern: [0,0,1,0,0,0,1,0],
    hihatDensity: 'low',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  },
  '90s Rap': {
    bpm: { min: 80, max: 110, common: 90 },
    scales: ['A minor', 'E minor'],
    description: '📻 Boom-bap drums, jazzy loops',
    kickPattern: [1,0,0,0,1,0,0,0],
    snarePattern: [0,0,1,0,0,0,1,0],
    hihatDensity: 'medium',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  },
  'Lo-fi': {
    bpm: { min: 80, max: 110, common: 85 },
    scales: ['C major', 'A minor'],
    description: '☕ Chill vibes, jazzy chords',
    kickPattern: [1,0,0,0,1,0,0,0],
    snarePattern: [0,0,1,0,0,0,1,0],
    hihatDensity: 'low',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  },
  'Drill': {
    bpm: { min: 135, max: 150, common: 142 },
    scales: ['C minor', 'F# minor'],
    description: '⚔️ Aggressive sliding hi-hats',
    kickPattern: [1,0,0,0,0,0,1,0, 0,1,0,0,0,0,0,0],
    snarePattern: [0,0,0,1,0,0,0,0, 0,0,0,1,0,0,0,0],
    hihatDensity: 'very-high',
    structure: { intro: 2, verse: 8, chorus: 8, bridge: 4, outro: 2 }
  },
  'G-Funk': {
    bpm: { min: 85, max: 100, common: 90 },
    scales: ['C minor', 'G minor'],
    description: '🌴 West Coast funk, synth leads',
    kickPattern: [1,0,0,0,1,0,0,0],
    snarePattern: [0,0,1,0,0,0,1,0],
    hihatDensity: 'medium',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  },
  'Neo-Soul': {
    bpm: { min: 70, max: 90, common: 80 },
    scales: ['D minor', 'Eb major'],
    description: '🎷 Jazz harmony, organic feel',
    kickPattern: [1,0,0,0,0,0,1,0, 0,1,0,0],
    snarePattern: [0,0,0,1,0,0,0,1, 0,0,0,0],
    hihatDensity: 'low',
    structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
  }
};

const NOTE_MAP: Record<string, string[]> = {
  'C major': ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5'],
  'A minor': ['A3', 'B3', 'C4', 'D4', 'E4', 'F4', 'G4', 'A4'],
  'G major': ['G3', 'A3', 'B3', 'C4', 'D4', 'E4', 'F#4', 'G4'],
  'E minor': ['E3', 'F#3', 'G3', 'A3', 'B3', 'C4', 'D4', 'E4'],
  'F major': ['F3', 'G3', 'A3', 'Bb3', 'C4', 'D4', 'E4', 'F4'],
  'D minor': ['D3', 'E3', 'F3', 'G3', 'A3', 'Bb3', 'C4', 'D4'],
  'C# minor': ['C#3', 'D#3', 'E3', 'F#3', 'G#3', 'A3', 'B3', 'C#4'],
  'F minor': ['F3', 'G3', 'Ab3', 'Bb3', 'C4', 'Db4', 'Eb4', 'F4'],
  'F# minor': ['F#3', 'G#3', 'A3', 'B3', 'C#4', 'D4', 'E4', 'F#4'],
  'C minor': ['C3', 'D3', 'Eb3', 'F3', 'G3', 'Ab3', 'Bb3', 'C4'],
  'Eb major': ['Eb3', 'F3', 'G3', 'Ab3', 'Bb3', 'C4', 'D4', 'Eb4'],
  'G minor': ['G3', 'A3', 'Bb3', 'C4', 'D4', 'Eb4', 'F4', 'G4']
};

const ROMAN_TO_DEGREE: Record<string, number> = {
  'i': 0, 'I': 0, 'ii': 1, 'II': 1, 'iii': 2, 'III': 2,
  'iv': 3, 'IV': 3, 'v': 4, 'V': 4, 'vi': 5, 'VI': 5,
  'vii': 6, 'VII': 6, 'bII': 1, 'bIII': 2, 'bVI': 5, 'bVII': 6
};

class MusicGenerator {
  async generate(settings: GenerationSettings, onUpdate: (name: string, status: AgentStatus, message?: string) => void, samples: UploadedSample[]) {
    const spec = GENRE_SPECS[settings.genre];
    const producer = PRODUCER_SPECS[settings.producer];
    const scale = NOTE_MAP[settings.key] || NOTE_MAP['A minor'];
    
    const beatsPerSecond = settings.tempo / 60;
    const totalBeats = beatsPerSecond * settings.duration;
    const bars = Math.ceil(totalBeats / 4);
    
    onUpdate('Theme Director', 'processing', 'Defining overall mood and sonic palette...');
    await this.delay(500);
    const theme = { mood: producer.signature, key: settings.key, samples: samples.length };
    onUpdate('Theme Director', 'complete', `Mood set to: ${producer.signature}`);
    
    onUpdate('Structure Architect', 'processing', 'Planning song sections (Intro, Verse, etc)...');
    await this.delay(400);
    const structure = settings.useStructure ? this.generateStructure(bars, spec.structure) : null;
    onUpdate('Structure Architect', 'complete', `Created a ${structure ? structure.length : 'linear'} part structure.`);
    
    onUpdate('Harmony Designer', 'processing', 'Selecting harmonically rich chord progressions...');
    await this.delay(600);
    const { harmony, progressionName } = this.generateHarmony(scale, bars, spec, structure, settings);
    onUpdate('Harmony Designer', 'complete', `Selected progression: "${progressionName}"`);
    
    onUpdate('Rhythm Architect', 'processing', `Building a groove with ${settings.rhythmicDensity * 100}% density...`);
    await this.delay(700);
    const rhythm = this.generateRhythm(bars, spec, structure, settings.variation, settings.rhythmicDensity);
    onUpdate('Rhythm Architect', 'complete', 'Rhythm section crafted.');
    
    onUpdate('Melody Composer', 'processing', `Composing a melody with a ${settings.melodicContour} contour...`);
    await this.delay(550);
    const melody = this.generateMelody(scale, bars, harmony, structure, settings.complexity, settings.melodicContour);
    onUpdate('Melody Composer', 'complete', 'Melody composed.');
    
    onUpdate('Audio Synthesizer', 'processing', 'Loading producer-specific instrument patches...');
    await this.delay(400);
    onUpdate('Audio Synthesizer', 'complete', `Patches for ${settings.producer} are ready.`);
    
    return {
      rhythm,
      harmony,
      melody,
      bass: this.generateBass(harmony, structure, settings),
      tempo: settings.tempo,
      producer: settings.producer,
      genre: settings.genre,
      mixParams: producer,
      patches: producer.patches,
      theme,
      bars,
      duration: settings.duration,
      samples,
      structure
    };
  }
  
  generateStructure(totalBars: number, template: any) {
    const sections: Array<{ type: SongStructure; start: number; end: number }> = [];
    let currentBar = 0;
    
    const order: SongStructure[] = ['intro', 'verse', 'chorus', 'verse', 'chorus', 'bridge', 'chorus', 'outro'];
    
    for (const sectionType of order) {
      if (currentBar >= totalBars) break;
      const length = template[sectionType] || 4;
      const end = Math.min(currentBar + length, totalBars);
      sections.push({ type: sectionType, start: currentBar, end });
      currentBar = end;
    }
    
    return sections;
  }
  
  generateRhythm(bars: number, spec: any, structure: any, variation: number, density: number) {
    const patterns: any = { kick: [], snare: [], hihat: [], sample: [] };
    const beatsPerBar = 16;
    
    for (let b = 0; b < bars; b++) {
      const section = structure?.find((s: any) => b >= s.start && b < s.end);
      const sectionType = section?.type || 'verse';
      
      const sectionDensity = sectionType === 'intro' ? 0.6 : 
                      sectionType === 'outro' ? 0.5 :
                      sectionType === 'chorus' ? 1.2 : 1.0;
      
      for (let i = 0; i < beatsPerBar; i++) {
        const time = `${b}:${Math.floor(i / 4)}:${i % 4}`;
        
        // Use overall rhythmic density control
        if (Math.random() > density) continue;

        const kickIdx = i % spec.kickPattern.length;
        const kickChance = sectionType === 'intro' ? 0.7 : 0.9;
        if (spec.kickPattern[kickIdx] && Math.random() > (1 - kickChance)) {
          const humanize = (Math.random() - 0.5) * 0.05 * variation;
          patterns.kick.push({ 
            time, 
            velocity: (0.85 + Math.random() * 0.15) * sectionDensity,
            humanize 
          });
        }
        
        const snareIdx = i % spec.snarePattern.length;
        const snareChance = sectionType === 'intro' ? 0.85 : 0.95;
        if (spec.snarePattern[snareIdx] && Math.random() > (1 - snareChance)) {
          const humanize = (Math.random() - 0.5) * 0.05 * variation;
          patterns.snare.push({ 
            time, 
            velocity: (0.75 + Math.random() * 0.2) * sectionDensity,
            humanize 
          });
        }
        
        const hhChance = spec.hihatDensity === 'very-high' ? 0.9 :
                        spec.hihatDensity === 'high' ? 0.7 :
                        spec.hihatDensity === 'medium' ? 0.5 : 0.3;
        
        const hihatMult = sectionType === 'chorus' ? 1.3 : 1.0;
        
        if (i % 2 === 0 || Math.random() < hhChance * 0.6 * hihatMult) {
          const humanize = (Math.random() - 0.5) * 0.03 * variation;
          patterns.hihat.push({ 
            time, 
            velocity: (0.25 + Math.random() * 0.25) * sectionDensity,
            roll: spec.hihatDensity.includes('high') && i % 4 === 3 && Math.random() < 0.2,
            humanize
          });
        }
        
        if (b % 4 === 0 && i === 0) {
          patterns.sample.push({ time, velocity: 0.7 });
        }
      }
    }
    
    return patterns;
  }
  
  generateHarmony(scale: string[], bars: number, spec: any, structure: any, settings: GenerationSettings) {
    const chords = [];
    
    const getProgression = (isBridge = false) => {
        const producerProgs = (settings.useProducerProgressions && PRODUCER_PROGRESSIONS[settings.producer as keyof typeof PRODUCER_PROGRESSIONS]) || [];
        const genreProgs = GENRE_PROGRESSIONS[settings.genre as keyof typeof GENRE_PROGRESSIONS] || GENRE_PROGRESSIONS['R&B']; // Fallback

        // Prioritize producer progressions, fallback to genre
        const availableProgs = producerProgs.length > 0 ? producerProgs : genreProgs;
        if (availableProgs.length === 0) {
            return { roman: ['i', 'iv', 'v', 'i'], name: 'Default Fallback' };
        }
        return availableProgs[Math.floor(Math.random() * availableProgs.length)];
    }

    const mainProgression = getProgression();
    let bridgeProgression = getProgression(true);
    // Ensure bridge progression is different
    while (bridgeProgression.id === mainProgression.id) {
        bridgeProgression = getProgression(true);
    }
    
    let activeProgressionName = mainProgression.name;

    for (let bar = 0; bar < bars; bar++) {
        const section = structure?.find((s: any) => bar >= s.start && b < s.end);
        const sectionType = section?.type || 'verse';

        const currentProg = sectionType === 'bridge' ? bridgeProgression : mainProgression;
        if(sectionType === 'bridge') activeProgressionName = bridgeProgression.name;

        const progression = currentProg.roman;

        const progIndex = bar % progression.length;
        const numeral = progression[progIndex];
        const degree = ROMAN_TO_DEGREE[numeral] || 0;
        
        // Basic triad
        const notes = [
            scale[degree % scale.length],
            scale[(degree + 2) % scale.length],
            scale[(degree + 4) % scale.length]
        ];
        
        // Add 7th
        if (settings.complexity > 0.4 || sectionType === 'chorus') {
            notes.push(scale[(degree + 6) % scale.length]);
        }
        // Add 9th for more complexity
        if (settings.complexity > 0.8 && (settings.genre === 'Neo-Soul' || settings.genre === 'R&B')) {
            const ninth = scale[(degree + 8) % scale.length];
            if(ninth) notes.push(ninth);
        }
        
        const duration = sectionType === 'bridge' && Math.random() < 0.3 ? '2m' : '1m';
        
        chords.push({ time: `${bar}:0:0`, notes, duration, section: sectionType });
    }
    
    return { harmony: chords, progressionName: activeProgressionName };
  }
  
  generateMelody(scale: string[], bars: number, harmony: any[], structure: any, complexity: number, contour: MelodicContour) {
    const notes = [];
    let currentIdx = Math.floor(scale.length / 2);
    
    for (let b = 0; b < bars; b++) {
      const section = structure?.find((s: any) => b >= s.start && b < s.end);
      const sectionType = section?.type || 'verse';

      const currentChord = harmony.find(c => c.time === `${b}:0:0`);
      if (!currentChord) continue;

      const chordRoot = currentChord.notes[0].slice(0, -1);
      currentIdx = Math.max(0, scale.findIndex(n => n.startsWith(chordRoot)));
      
      const playChance = sectionType === 'intro' ? 0.4 :
                        sectionType === 'outro' ? 0.3 :
                        sectionType === 'chorus' ? 0.8 : 0.65;
      
      const subdivision = (sectionType === 'chorus' || complexity > 0.7) ? 8 : 4;
      
      for (let i = 0; i < subdivision; i++) {
        if (Math.random() < playChance) {
          // --- CONTOUR LOGIC ---
          let stepDirection = Math.random() < 0.5 ? -1 : 1;
          if (contour === 'rising') stepDirection = 1;
          if (contour === 'falling') stepDirection = -1;
          if (contour === 'arch') stepDirection = (i < subdivision / 2) ? 1 : -1;

          const stepSize = Math.random() < 0.6 ? 1 : 2;
          const step = stepDirection * stepSize;
          currentIdx = (currentIdx + step + scale.length) % scale.length;
          
          const note = scale[currentIdx];
          const duration = Math.random() < 0.4 ? '8n' : '16n';
          const velocity = (0.5 + Math.random() * 0.3) * (sectionType === 'chorus' ? 1.2 : 1.0);
          
          notes.push({ 
            time: `${b}:${Math.floor(i * 4 / subdivision)}:${Math.floor((i * 4 / subdivision % 1) * 4)}`, 
            note, duration, velocity, section: sectionType
          });
        }
      }
    }
    return notes;
  }
  
  generateBass(harmony: any[], structure: any, settings: GenerationSettings) {
    const bassline = [];
    for(let i = 0; i < harmony.length; i++){
      const c = harmony[i];
      const rootNote = c.notes[0].slice(0, -1);
      const octave = c.section === 'bridge' ? '1' : '2';
      const velocity = c.section === 'chorus' ? 0.95 : 
                      c.section === 'intro' ? 0.6 : 0.85;

      // Add inversion for smoother bass movement
      let finalNote = `${rootNote}${octave}`;
      if (i > 0 && settings.complexity > 0.5) {
        const prevRoot = harmony[i-1].notes[0].slice(0,-1);
        const fifth = c.notes.length > 2 ? c.notes[2].slice(0,-1) : null;
        if(fifth && Math.abs(Tone.Frequency(prevRoot + "2").toMidi() - Tone.Frequency(fifth + "1").toMidi()) < 
                   Math.abs(Tone.Frequency(prevRoot + "2").toMidi() - Tone.Frequency(rootNote + "2").toMidi())) {
          finalNote = `${fifth}${octave-1}`;
        }
      }
      
      bassline.push({ 
        time: c.time, 
        note: finalNote, 
        duration: c.duration, 
        velocity,
        section: c.section
      });
      
      // Add Drill-style slides
      if(settings.genre === 'Drill' && Math.random() < 0.4){
        const nextNote = harmony[i+1]?.notes[0].slice(0,-1);
        if(nextNote){
            const slideStartTime = Tone.Time(c.time).toSeconds() + Tone.Time('8n').toSeconds();
            bassline.push({
                time: slideStartTime,
                note: `${nextNote}${octave}`,
                duration: '16n',
                velocity: velocity * 0.8
            });
        }
      }
    }
    return bassline;
  }
  
  delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ... the rest of the file (AudioService and App component) remains unchanged ...

class AudioService {
  private synths: any = {};
  private parts: any[] = [];
  private players: Tone.Player[] = [];
  private analyser: Tone.Analyser | null = null;
  private reverb: Tone.Reverb | null = null;
  private distortion: Tone.Distortion | null = null;
  private recorder: Tone.Recorder | null = null;
  private isInit = false;
  
  async init() {
    if (!this.isInit) {
      await Tone.start();
      this.isInit = true;
    }
  }
  
  createSynth(patchName: string, masterChain: any) {
    const patch = INSTRUMENT_PATCHES[patchName];
    if (!patch) return null;
    
    if (patch.type === 'MonoSynth') {
      return new Tone.MonoSynth(patch.config).connect(masterChain);
    } else if (patch.type === 'PolySynth') {
      return new Tone.PolySynth(Tone.Synth, patch.config).connect(masterChain);
    }
    return null;
  }
  
  async schedule(comp: any) {
    await this.init();
    this.stop();
    this.cleanup();
    
    const producer = comp.mixParams;
    
    this.reverb = new Tone.Reverb({
      decay: producer.reverb.decay,
      wet: producer.reverb.mix
    });
    await this.reverb.generate();
    
    this.distortion = new Tone.Distortion(producer.saturation);
    this.recorder = new Tone.Recorder();
    
    const masterChain = new Tone.Gain(0.7)
      .connect(this.distortion)
      .connect(this.reverb)
      .connect(this.recorder)
      .toDestination();
    
    this.synths.kick = new Tone.MembraneSynth({
      volume: -6,
      envelope: { attack: 0.001, decay: 0.4, sustain: 0, release: 0.1 }
    }).connect(masterChain);
    
    this.synths.snare = new Tone.NoiseSynth({
      volume: -10,
      noise: { type: 'white' },
      envelope: { attack: 0.001, decay: 0.15, sustain: 0, release: 0.05 }
    }).connect(masterChain);
    
    this.synths.hihat = new Tone.MetalSynth({
      volume: -18,
      envelope: { attack: 0.001, decay: 0.05, release: 0.03 }
    }).connect(masterChain);
    
    this.synths.melody = this.createSynth(comp.patches.lead, masterChain) || 
      new Tone.PolySynth(Tone.Synth, {
        volume: -14,
        oscillator: { type: 'triangle' },
        envelope: { attack: 0.01, decay: 0.3, sustain: 0.3, release: 0.4 }
      }).connect(masterChain);
    
    this.synths.chords = this.createSynth(comp.patches.pad, masterChain) ||
      new Tone.PolySynth(Tone.Synth, {
        volume: -18,
        oscillator: { type: 'sine' },
        envelope: { attack: 0.05, decay: 0.4, sustain: 0.5, release: 0.8 }
      }).connect(masterChain);
    
    this.synths.bass = this.createSynth(comp.patches.bass, masterChain) ||
      new Tone.MonoSynth({
        volume: -10,
        oscillator: { type: 'sawtooth' },
        envelope: { attack: 0.01, decay: 0.3, sustain: 0.7, release: 0.4 },
        filter: { type: 'lowpass', frequency: 200, Q: 2 }
      }).connect(masterChain);
    
    if (comp.samples && comp.samples.length > 0) {
      for (const sample of comp.samples) {
        if (sample.buffer && (sample.type === 'wav' || sample.type === 'ogg')) {
          const player = new Tone.Player(sample.buffer).connect(masterChain);
          player.volume.value = -12;
          this.players.push(player);
        }
      }
    }
    
    if (!this.analyser) {
      this.analyser = new Tone.Analyser('waveform', 1024);
      Tone.getDestination().connect(this.analyser);
    }
    
    this.parts.push(new Tone.Part((time, e) => {
      const adjustedTime = e.humanize ? time + e.humanize : time;
      this.synths.kick.triggerAttackRelease('C1', '8n', adjustedTime, e.velocity);
    }, comp.rhythm.kick).start(0));
    
    this.parts.push(new Tone.Part((time, e) => {
      const adjustedTime = e.humanize ? time + e.humanize : time;
      this.synths.snare.triggerAttackRelease('8n', adjustedTime, e.velocity);
    }, comp.rhythm.snare).start(0));
    
    this.parts.push(new Tone.Part((time, e) => {
      const adjustedTime = e.humanize ? time + e.humanize : time;
      if (e.roll) {
        for (let i = 0; i < 4; i++) {
          this.synths.hihat.triggerAttackRelease('32n', adjustedTime + (i * 0.03), e.velocity * 0.7);
        }
      } else {
        this.synths.hihat.triggerAttackRelease('32n', adjustedTime, e.velocity);
      }
    }, comp.rhythm.hihat).start(0));
    
    this.parts.push(new Tone.Part((time, c) => {
      this.synths.chords.triggerAttackRelease(c.notes, c.duration, time);
    }, comp.harmony).start(0));
    
    this.parts.push(new Tone.Part((time, n) => {
      // For slides, ramp to the new note's frequency
      if (this.synths.bass.portamento > 0 && comp.genre === 'Drill'){
         this.synths.bass.setNote(n.note, time);
      } else {
         this.synths.bass.triggerAttackRelease(n.note, n.duration, time, n.velocity);
      }
    }, comp.bass).start(0));
    
    this.parts.push(new Tone.Part((time, n) => {
      this.synths.melody.triggerAttackRelease(n.note, n.duration, time, n.velocity);
    }, comp.melody).start(0));
    
    if (this.players.length > 0 && comp.rhythm.sample) {
      this.parts.push(new Tone.Part((time, e) => {
        const player = this.players[Math.floor(Math.random() * this.players.length)];
        if (player) player.start(time);
      }, comp.rhythm.sample).start(0));
    }
    
    Tone.Transport.bpm.value = comp.tempo;
    Tone.Transport.swing = producer.swing;
    Tone.Transport.swingSubdivision = '8n';
    Tone.Transport.loop = true;
    Tone.Transport.loopEnd = `${comp.bars}m`;
  }
  
  async startRecording() {
    if (this.recorder) {
      this.recorder.start();
    }
  }
  
  async stopRecording(): Promise<Blob | null> {
    if (this.recorder) {
      const recording = await this.recorder.stop();
      return recording;
    }
    return null;
  }
  
  play() { 
    Tone.Transport.start();
    this.startRecording();
  }
  
  stop() { 
    Tone.Transport.stop(); 
    Tone.Transport.position = 0; 
  }
  
  getAnalyser() { return this.analyser; }
  
  cleanup() {
    this.parts.forEach(p => p.dispose && p.dispose());
    this.parts = [];
    this.players.forEach(p => p.dispose());
    this.players = [];
    Object.values(this.synths).forEach((s: any) => s?.dispose && s.dispose());
    this.synths = {};
    Tone.Transport.cancel();
    this.reverb?.dispose();
    this.distortion?.dispose();
  }
  
  dispose() {
    this.stop();
    this.cleanup();
    this.analyser?.dispose();
    this.recorder?.dispose();
  }
}

export default function App() {
  const [settings, setSettings] = useState<GenerationSettings>({
    genre: 'Trap',
    producer: 'Default',
    key: 'A minor',
    tempo: 140,
    duration: 120,
    complexity: 0.7,
    variation: 0.5,
    useStructure: true,
    melodicContour: 'arch',
    rhythmicDensity: 1.0,
    useProducerProgressions: true,
  });
  
  const [agents, setAgents] = useState<Agent[]>([
    { name: 'Theme Director', status: 'idle', output: null, message: '' },
    { name: 'Structure Architect', status: 'idle', output: null, message: '' },
    { name: 'Harmony Designer', status: 'idle', output: null, message: '' },
    { name: 'Rhythm Architect', status: 'idle', output: null, message: '' },
    { name: 'Melody Composer', status: 'idle', output: null, message: '' },
    { name: 'Audio Synthesizer', status: 'idle', output: null, message: '' }
  ]);
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [composition, setComposition] = useState<any>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false); // <-- NEW STATE for advanced panel
  const [uploadedSamples, setUploadedSamples] = useState<UploadedSample[]>([]);
  const [isExporting, setIsExporting] = useState(false);
  
  const audioServiceRef = useRef<AudioService | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    audioServiceRef.current = new AudioService();
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      audioServiceRef.current?.dispose();
    };
  }, []);
  
  const drawVisualizer = useCallback(() => {
    if (!canvasRef.current || !audioServiceRef.current) return;
    
    const analyser = audioServiceRef.current.getAnalyser();
    if (!analyser) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const values = analyser.getValue() as Float32Array;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
    gradient.addColorStop(0, '#8b5cf6');
    gradient.addColorStop(0.5, '#ec4899');
    gradient.addColorStop(1, '#f59e0b');
    
    ctx.strokeStyle = gradient;
    ctx.lineWidth = 3;
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#ec4899';
    
    ctx.beginPath();
    const sliceWidth = canvas.width / values.length;
    
    for (let i = 0; i < values.length; i++) {
      const v = (values[i] + 1) / 2;
      const y = v * canvas.height;
      const x = i * sliceWidth;
      
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    
    ctx.stroke();
    animationFrameRef.current = requestAnimationFrame(drawVisualizer);
  }, []);
  
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    const audioContext = Tone.context.rawContext as AudioContext;
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileType = file.name.split('.').pop()?.toLowerCase();
      
      if (fileType === 'wav' || fileType === 'ogg') {
        const arrayBuffer = await file.arrayBuffer();
        try {
          const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
          const url = URL.createObjectURL(file);
          
          setUploadedSamples(prev => [...prev, {
            name: file.name,
            type: fileType as 'wav' | 'ogg',
            buffer: audioBuffer,
            url
          }]);
        } catch (error) {
          console.error('Error decoding audio:', error);
        }
      } else if (fileType === 'midi' || fileType === 'mid') {
        const url = URL.createObjectURL(file);
        setUploadedSamples(prev => [...prev, {
          name: file.name,
          type: 'midi',
          buffer: null,
          url
        }]);
      }
    }
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const removeSample = (index: number) => {
    setUploadedSamples(prev => {
      const newSamples = [...prev];
      URL.revokeObjectURL(newSamples[index].url);
      newSamples.splice(index, 1);
      return newSamples;
    });
  };
  
  const handleGenerate = async () => {
    setIsGenerating(true);
    setIsPlaying(false);
    audioServiceRef.current?.stop();
    
    setAgents(prev => prev.map(a => ({ ...a, status: 'idle' as AgentStatus, output: null, message: '' })));
    
    const onUpdate = (name: string, status: AgentStatus, message: string = '') => {
      setAgents(prev => prev.map(a => a.name === name ? { ...a, status, message } : a));
    };
    
    try {
      const generator = new MusicGenerator();
      const comp = await generator.generate(settings, onUpdate, uploadedSamples);
      setComposition(comp);
      await audioServiceRef.current?.schedule(comp);
    } catch (error) {
      console.error('Error:', error);
      setAgents(prev => prev.map(a => 
        a.status === 'processing' ? { ...a, status: 'error' as AgentStatus, message: 'An error occurred.' } : a
      ));
    } finally {
      setIsGenerating(false);
    }
  };
  
  const handlePlay = () => {
    if (!composition) return;
    audioServiceRef.current?.play();
    setIsPlaying(true);
    drawVisualizer();
  };
  
  const handleStop = () => {
    audioServiceRef.current?.stop();
    setIsPlaying(false);
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
  };
  
  const handleDownload = async () => {
    if (!audioServiceRef.current || !composition) return;
    
    setIsExporting(true);
    
    try {
      const wasPlaying = isPlaying;
      if (wasPlaying) {
        handleStop();
      }
      
      await audioServiceRef.current.schedule(composition);
      audioServiceRef.current.play();
      
      await new Promise(resolve => setTimeout(resolve, composition.duration * 1000));
      
      audioServiceRef.current.stop();
      const blob = await audioServiceRef.current.stopRecording();
      
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${settings.producer}_${settings.genre}_${Date.now()}.webm`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
      
      await audioServiceRef.current.schedule(composition);
      
    } catch (error) {
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  };
  
  const handleGenreChange = (genre: Genre) => {
    const spec = GENRE_SPECS[genre];
    setSettings(prev => ({
      ...prev,
      genre,
      tempo: spec.bpm.common,
      key: spec.scales[0]
    }));
  };
  
  const getProducerColor = (producer: Producer) => {
    const colors: Record<Producer, string> = {
      'Pharrell': 'from-yellow-500 to-orange-500',
      'Timbaland': 'from-blue-500 to-cyan-500',
      'Zaytoven': 'from-purple-500 to-pink-500',
      'Just Blaze': 'from-red-500 to-orange-500',
      'Missy Elliott': 'from-pink-500 to-purple-500',
      'Dr. Dre': 'from-green-500 to-emerald-500',
      'J Dilla': 'from-amber-500 to-yellow-500',
      'Kanye West': 'from-indigo-500 to-purple-500',
      'DJ Quik': 'from-teal-500 to-cyan-500',
      'No I.D.': 'from-slate-500 to-gray-500',
      'Default': 'from-gray-500 to-slate-500'
    };
    return colors[producer];
  };
  
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-black text-white p-4 md:p-6">
      <header className="text-center mb-8">
        <h1 className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-orange-500 mb-2">
          🎵 AI Music Studio Pro V2
        </h1>
        <p className="text-gray-400 text-sm md:text-base">Advanced 120-second beat generation with structure, humanization & signature producer patches</p>
      </header>
      
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <div className="space-y-4">
          <div className="bg-gray-800/50 backdrop-blur border border-gray-700 rounded-xl p-4 md:p-6 shadow-2xl">
            <h2 className="text-xl font-bold mb-4 text-purple-400 flex items-center justify-between">
              <span>⚙️ Generation Settings</span>
              <button 
                onClick={() => setShowAdvanced(!showAdvanced)} 
                className="text-xs bg-purple-800/50 px-2 py-1 rounded-md hover:bg-purple-700/50"
              >
                {showAdvanced ? 'Hide' : 'Show'} Advanced
              </button>
            </h2>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs md:text-sm mb-2 font-medium text-gray-300">Genre</label>
                  <select
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg p-2 text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
                    value={settings.genre}
                    onChange={e => handleGenreChange(e.target.value as Genre)}
                  >
                    {Object.keys(GENRE_SPECS).map(g => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1 h-8">{GENRE_SPECS[settings.genre].description}</p>
                </div>
                
                <div>
                  <label className="block text-xs md:text-sm mb-2 font-medium text-gray-300">Producer</label>
                  <select
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg p-2 text-sm focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    value={settings.producer}
                    onChange={e => setSettings(prev => ({ ...prev, producer: e.target.value as Producer }))}
                  >
                    {Object.keys(PRODUCER_SPECS).map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                  <p className="text-xs text-gray-500 mt-1 h-8">{PRODUCER_SPECS[settings.producer].signature}</p>
                </div>
              </div>
              
              <div>
                <label className="block text-xs md:text-sm mb-2 font-medium text-gray-300">Musical Key</label>
                <select
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  value={settings.key}
                  onChange={e => setSettings(prev => ({ ...prev, key: e.target.value }))}
                >
                  {Object.keys(NOTE_MAP).map(k => (
                    <option key={k} value={k}>{k}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-xs md:text-sm mb-2 flex justify-between font-medium">
                  <span className="text-gray-300">Tempo (BPM)</span>
                  <span className="text-purple-400 font-bold">{settings.tempo}</span>
                </label>
                <input
                  type="range"
                  min={GENRE_SPECS[settings.genre].bpm.min}
                  max={GENRE_SPECS[settings.genre].bpm.max}
                  value={settings.tempo}
                  onChange={e => setSettings(prev => ({ ...prev, tempo: parseInt(e.target.value) }))}
                  className="w-full accent-purple-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>{GENRE_SPECS[settings.genre].bpm.min}</span>
                  <span>{GENRE_SPECS[settings.genre].bpm.max}</span>
                </div>
              </div>

              {/* ----- ADVANCED SETTINGS PANEL ----- */}
              {showAdvanced && (
                <div className="bg-gray-900/50 p-4 rounded-lg space-y-4 border border-gray-700">
                    <h3 className="text-md font-semibold text-pink-400">Advanced Controls</h3>
                    <div>
                        <label className="block text-xs md:text-sm mb-2 font-medium text-gray-300">Melodic Contour</label>
                        <select
                            className="w-full bg-gray-700 border border-gray-600 rounded-lg p-2 text-sm focus:ring-2 focus:ring-pink-500 focus:outline-none"
                            value={settings.melodicContour}
                            onChange={e => setSettings(prev => ({ ...prev, melodicContour: e.target.value as MelodicContour }))}
                        >
                            <option value="arch">Arch</option>
                            <option value="rising">Rising</option>
                            <option value="falling">Falling</option>
                            <option value="random">Random</option>
                        </select>
                        <p className="text-xs text-gray-500 mt-1">Overall shape of the melody</p>
                    </div>

                    <div>
                        <label className="block text-xs md:text-sm mb-2 flex justify-between font-medium">
                          <span className="text-gray-300">Rhythmic Density</span>
                          <span className="text-pink-400 font-bold">{Math.round(settings.rhythmicDensity * 100)}%</span>
                        </label>
                        <input
                          type="range" min="0.5" max="1" step="0.05"
                          value={settings.rhythmicDensity}
                          onChange={e => setSettings(prev => ({ ...prev, rhythmicDensity: parseFloat(e.target.value) }))}
                          className="w-full accent-pink-500"
                        />
                        <p className="text-xs text-gray-500 mt-1">How busy the rhythm section is</p>
                    </div>

                    <div className="flex items-center gap-3 bg-gray-700/50 p-3 rounded-lg">
                        <input
                          type="checkbox" id="useProducerProgressions"
                          checked={settings.useProducerProgressions}
                          onChange={e => setSettings(prev => ({ ...prev, useProducerProgressions: e.target.checked }))}
                          className="w-4 h-4 accent-pink-500"
                        />
                        <label htmlFor="useProducerProgressions" className="text-sm text-gray-300 cursor-pointer">
                          Use Producer-Specific Chord Progressions
                        </label>
                    </div>
                </div>
              )}
              
              <div>
                <label className="block text-xs md:text-sm mb-2 flex justify-between font-medium">
                  <span className="text-gray-300">Complexity</span>
                  <span className="text-purple-400 font-bold">{Math.round(settings.complexity * 100)}%</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={settings.complexity}
                  onChange={e => setSettings(prev => ({ ...prev, complexity: parseFloat(e.target.value) }))}
                  className="w-full accent-purple-500"
                />
                <p className="text-xs text-gray-500 mt-1">Note density & chord extensions</p>
              </div>
              
              <div>
                <label className="block text-xs md:text-sm mb-2 flex justify-between font-medium">
                  <span className="text-gray-300">Humanization</span>
                  <span className="text-purple-400 font-bold">{Math.round(settings.variation * 100)}%</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={settings.variation}
                  onChange={e => setSettings(prev => ({ ...prev, variation: parseFloat(e.target.value) }))}
                  className="w-full accent-purple-500"
                />
                <p className="text-xs text-gray-500 mt-1">Timing & velocity randomization</p>
              </div>
              
              <div className="flex items-center gap-3 bg-gray-700/50 p-3 rounded-lg">
                <input
                  type="checkbox"
                  id="useStructure"
                  checked={settings.useStructure}
                  onChange={e => setSettings(prev => ({ ...prev, useStructure: e.target.checked }))}
                  className="w-4 h-4 accent-purple-500"
                />
                <label htmlFor="useStructure" className="text-sm text-gray-300 cursor-pointer">
                  Use Song Structure (Intro/Verse/Chorus/Bridge/Outro)
                </label>
              </div>
              
              <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-blue-300">⏱️ Duration</span>
                  <span className="text-lg font-bold text-blue-400">{formatDuration(settings.duration)}</span>
                </div>
                <div className="text-xs text-gray-400">Fixed at 120 seconds for optimal quality</div>
              </div>
              
              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className={`w-full bg-gradient-to-r ${getProducerColor(settings.producer)} text-white font-bold py-3 rounded-lg hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100 shadow-lg`}
              >
                {isGenerating ? '🎵 Generating...' : '✨ Generate Track'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}