/*
genreSampler.js
Tone.js unified keyboard sampler with genre-based FX buses and performance modes.

Version: 2.0
Features:
- 'lite' mode for low-power devices (shared FX, fewer samples).
- 'full' mode for high-power devices (dedicated FX, all samples).
- Mode can be set in the CONFIG object before loading.
*/

import * as Tone from "tone";

// -----------------------------
// Configuration
// -----------------------------
// Runtime config: switch between 'full' and 'lite' for performance scaling
const CONFIG = {
  mode: 'lite', // SET YOUR DEFAULT MODE HERE: 'lite' or 'full'
  samplePath: '/samples/',
};

// All sample files are listed here. The script will load them based on the selected mode.
const SAMPLE_FILES = {
  // ... (sample file list remains the same as your original)
};

// ... (rest of the file list)
const SAMPLE_FILES = {
  keys: {
    rhodes: "rhodes.wav",
    wurlitzer: "wurlitzer.wav",
    detuned_piano: "detuned_piano.wav",
    grand_piano: "grand_piano.wav",
    jazz_piano: "jazz_piano.wav",
  },
  guitars: {
    funk: "funk_guitar.wav",
    soul: "soul_guitar.wav",
    plucky: "plucky_guitar.wav",
    clean: "clean_guitar.wav",
  },
  orchestral: {
    string_stab: "string_stab.wav",
    brass_hit: "brass_hit.wav",
    trumpet_stab: "trumpet_stab.wav",
    string_hit: "string_hit.wav",
    string_section: "string_section.wav",
    trumpet_section: "trumpet_section.wav",
    sax_stab: "sax_stab.wav",
    epic_strings: "epic_string_section.wav",
    orchestral_hit: "orchestral_hit.wav",
  },
  vocals: {
    hey: "vocal_hey.wav",
    uh: "vocal_uh.wav",
    yo: "yo.wav",
    go: "go.wav",
    soul: "soul_vocal.wav",
  },
  fx: {
    vinyl_crackle: "vinyl_crackle.wav",
    laser: "laser.wav",
    vinyl_stop: "vinyl_stop.wav",
    siren: "siren.wav",
    vocoder: "robot_vocoder.wav",
  },
  percussion: {
    bongo: "bongo.wav",
  }
};


// -----------------------------
// Globals
// -----------------------------
let players = {};
let samplers = {};
let fxBuses = {};
const master = new Tone.Gain(0.9).toDestination();

// -----------------------------
// Create genre-based FX buses (Mode-Aware)
// -----------------------------
function createFXBuses() {
  // Your mode-aware function is perfect. No changes needed.
  if (CONFIG.mode === 'lite') {
    console.log("Running in LITE mode: Shared FX chain, low CPU usage");
    const sharedReverb = new Tone.JCReverb(0.8).toDestination();
    const sharedDelay = new Tone.FeedbackDelay("8n", 0.25).connect(sharedReverb);
    const lightComp = new Tone.Compressor({ threshold: -18, ratio: 2 }).toDestination();
    const soulChorus = new Tone.Chorus(1.2, 2.2, 0.25).start().connect(sharedReverb);
    const percBit = new Tone.BitCrusher(6).connect(lightComp);

    fxBuses.ambient = { reverb: sharedReverb, delay: sharedDelay, send: 0.6 };
    fxBuses.afropop = { delay: sharedDelay, comp: lightComp, send: 0.45 };
    fxBuses.soul = { chorus: soulChorus, reverb: sharedReverb, send: 0.5 };
    fxBuses.orchestral = { reverb: sharedReverb, send: 0.7 };
    fxBuses.perc = { comp: lightComp, bit: percBit, send: 0.4 };
  } else {
    console.log("Running in FULL mode: All dedicated FX chains active");
    const ambientReverb = new Tone.Reverb({ decay: 6, preDelay: 0.03, wet: 0.6 }).toDestination();
    const ambientDelay = new Tone.FeedbackDelay("8n", 0.25).toDestination();
    const afroDelay = new Tone.FeedbackDelay("16n", 0.35).toDestination();
    const afroComp = new Tone.Compressor({ threshold: -18, ratio: 3 }).toDestination();
    const soulChorus = new Tone.Chorus(1.5, 2.5, 0.25).start();
    const soulVerb = new Tone.Reverb({ decay: 3.0, wet: 0.45 }).toDestination();
    soulChorus.connect(soulVerb);
    const orchestralVerb = new Tone.Reverb({ decay: 7, wet: 0.7 }).toDestination();
    const percComp = new Tone.Compressor({ threshold: -10, ratio: 2 });
    const percBit = new Tone.BitCrusher(8);
    percComp.chain(percBit, master);

    fxBuses.ambient = { reverb: ambientReverb, delay: ambientDelay, send: 0.6 };
    fxBuses.afropop = { delay: afroDelay, comp: afroComp, send: 0.45 };
    fxBuses.soul = { chorus: soulChorus, reverb: soulVerb, send: 0.5 };
    fxBuses.orchestral = { reverb: orchestralVerb, send: 0.7 };
    fxBuses.perc = { comp: percComp, bit: percBit, send: 0.35 };
  }
}

// -----------------------------
// Load samples (Mode-Aware)
// -----------------------------
async function loadAllSamples(onProgress = () => {}) {
  const mode = CONFIG.mode;
  const buffersToLoad = [];

  // Keys (lite mode: fewer notes)
  const keysToLoad = mode === 'lite'
    ? { C4: SAMPLE_FILES.keys.rhodes, E4: SAMPLE_FILES.keys.grand_piano }
    : { C4: SAMPLE_FILES.keys.rhodes, D4: SAMPLE_FILES.keys.wurlitzer, E4: SAMPLE_FILES.keys.detuned_piano, F4: SAMPLE_FILES.keys.grand_piano, G4: SAMPLE_FILES.keys.jazz_piano };
  
  samplers.keys = new Tone.Sampler({ urls: keysToLoad, baseUrl: CONFIG.samplePath, attack: 0.02, release: 1.2 }).connect(master);
  buffersToLoad.push(samplers.keys.loaded);

  // Guitars (lite mode: just soul)
  const guitarsToLoad = mode === 'lite' ? { soul: SAMPLE_FILES.guitars.soul } : SAMPLE_FILES.guitars;
  players.guitars = new Tone.Players(guitarsToLoad, () => onProgress("guitars_loaded")).connect(master);
  buffersToLoad.push(players.guitars.loaded);

  // Lite mode skips orchestral + fx for memory savings
  if (mode === 'full') {
    players.orchestral = new Tone.Players(SAMPLE_FILES.orchestral, () => onProgress("orchestral_loaded")).connect(master);
    players.fx = new Tone.Players(SAMPLE_FILES.fx, () => onProgress("fx_loaded")).connect(master);
    buffersToLoad.push(players.orchestral.loaded, players.fx.loaded);
  }

  // Vocals and Percussion are always loaded (essential sounds)
  players.vocals = new Tone.Players(SAMPLE_FILES.vocals, () => onProgress("vocals_loaded")).connect(master);
  players.perc = new Tone.Players(SAMPLE_FILES.percussion, () => onProgress("perc_loaded")).connect(master);
  buffersToLoad.push(players.vocals.loaded, players.perc.loaded);
  
  // ✅ FIX: This now correctly waits for all buffers that were actually initialized.
  await Promise.all(buffersToLoad);
}

// -----------------------------
// Routing helper (No changes needed)
// -----------------------------
function routeToFX(playerOrSampler, genreKey, sendLevel = null) {
  // ... (this function is fine as is)
}

// -----------------------------
// Key mapping (No changes needed)
// -----------------------------
const KEY_MAP = {
  // ... (the full key map remains)
};

// -----------------------------
// Play function (Mode-Aware and Error-Proof)
// -----------------------------
function triggerFromMap(entry, time = Tone.now()) {
  if (!entry) return;
  const { type, note, sample, duration = "1n", genre } = entry;

  // ✅ IMPROVEMENT: Add checks to ensure the player group exists before trying to use it.
  // This prevents crashes in 'lite' mode when pressing a key for a sample that wasn't loaded.

  if (type === "keys" && samplers.keys) {
    routeToFX(samplers.keys, genre);
    samplers.keys.triggerAttackRelease(note, duration, time);
  }

  if (type === "guitars" && players.guitars && players.guitars.has(sample)) {
    const player = players.guitars.player(sample);
    player.start(time);
    routeToFX(player, genre);
  }

  if (type === "orchestral" && players.orchestral && players.orchestral.has(sample)) {
    const player = players.orchestral.player(sample);
    player.start(time);
    routeToFX(player, genre);
  }

  if (type === "vocals" && players.vocals && players.vocals.has(sample)) {
    const player = players.vocals.player(sample);
    player.start(time);
    routeToFX(player, genre);
  }

  if (type === "fx" && players.fx && players.fx.has(sample)) {
    const player = players.fx.player(sample);
    player.start(time);
    routeToFX(player, genre);
  }
  
  if (type === "perc" && players.perc && players.perc.has(sample)) {
    const player = players.perc.player(sample);
    player.start(time);
    routeToFX(player, genre);
  }
}

// ... (Rest of the file: onKeyDown, startUI, updateStatus, init are the same)
// ...

// -----------------------------
// Initialize everything
// -----------------------------
async function init() {
  createFXBuses();
  startUI();
  updateStatus("Loading samples...");

  let progressCount = 0;
  const totalStages = CONFIG.mode === 'lite' ? 4 : 6; // Adjust total for progress bar
  await loadAllSamples((stage) => {
    progressCount++;
    updateStatus(`Loaded ${progressCount}/${totalStages} groups (${stage})`);
  });

  routeToFX(samplers.keys, "ambient", fxBuses.ambient.send);
  updateStatus(`Loaded in ${CONFIG.mode.toUpperCase()} mode. Ready to play.`);
  window.addEventListener("keydown", onKeyDown);
}

// Auto init
init().catch((err) => {
  console.error("Error initializing sampler:", err);
  updateStatus("Error loading samples — check console.");
});

// -----------------------------
// Export API
// -----------------------------
export const GenreSamplerAPI = {
  triggerKey(code) {
    const e = KEY_MAP[code];
    if (e) triggerFromMap(e);
  },
  triggerCustom(group, name) {
    if (group === "keys") samplers.keys.triggerAttackRelease(name, "2n");
    else if (players[group] && players[group].has(name)) players[group].player(name).start();
  },
  setMasterVolume(v) {
    master.gain.value = v;
  },
  // ✅ IMPROVEMENT: Clarified that a reload is needed.
  setMode(mode) {
    if (mode !== 'lite' && mode !== 'full') return;
    CONFIG.mode = mode;
    console.log(`Sampler mode set to: ${mode}. Please reload the page to apply changes.`);
    updateStatus(`Mode set to ${mode}. Reload page.`);
  },
};