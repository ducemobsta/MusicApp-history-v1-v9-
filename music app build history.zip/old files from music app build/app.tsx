// src/App.tsx

import React, { useState, useCallback, useRef, useEffect } from 'react';
import * as Tone from 'tone';
import { Player } from 'soundfont-player';
import { saveAs } from 'file-saver';
import { getInstrument, listAvailable, preloadInstruments, downloadInstrumentPack, INSTRUMENT_MAP } from './lib/instruments';


// --- DATA: Consolidated from provided files (Types, Constants, Specs) ---
// Note Map, Roman Numerals, Progressions, and Specs remain the same as v5.
// (For brevity, these large data structures from v5 are omitted here, but should be included)
// ... (Paste all the CONSTANTS from v5 app.txt here: NOTE_MAP, ROMAN_TO_DEGREE, etc.)

// --- TYPES (from v5) ---
// ... (Paste all the TYPES from v5 app.txt here: Genre, Producer, etc.)

// --- PROCEDURAL MUSIC ENGINE (from v5) ---
// The MusicGenerator class remains the same.
// ... (Paste the entire MusicGenerator class from v5 app.txt here)

// --- AUDIO RENDERING & PLAYBACK (UPDATED FOR V6) ---
class AudioService {
    private parts: any[] = [];
    private analyser: Tone.Analyser | null = null;
    private reverb: Tone.Reverb | null = null;
    private distortion: Tone.Distortion | null = null;
    private masterChannel: Tone.Channel | null = null;

    // V6 Change: Store SoundFont players instead of synths
    private instruments = {
        kick: new Tone.MembraneSynth({ volume: -2 }),
        snare: new Tone.NoiseSynth({ volume: -8, noise: { type: 'pink' }, envelope: { attack: 0.001, decay: 0.1, sustain: 0 } }),
        hihat: new Tone.MetalSynth({ volume: -16, envelope: { attack: 0.001, decay: 0.05, release: 0.02 }, harmonicity: 3.1, modulationIndex: 32, resonance: 4000 }),
        melody: null as Player | null,
        chords: null as Player | null,
        bass: null as Player | null,
    };

    async init() { await Tone.start(); }
    setReverbMix(wet: number) { if (this.reverb) this.reverb.wet.value = wet; }
    setSaturation(amount: number) { if (this.distortion) this.distortion.distortion = amount; }

    cleanup() {
        this.parts.forEach(p => p.dispose());
        this.parts = [];
        // V6 Change: Stop SoundFont players
        Object.values(this.instruments).forEach((inst: any) => inst?.stop?.());
        Tone.Transport.cancel();
        this.reverb?.dispose();
        this.distortion?.dispose();
        this.masterChannel?.dispose();
    }
    
    // V6 Change: `schedule` now loads instruments before scheduling notes
    async schedule(comp: any, instrumentSelection: { melody: string, chords: string, bass: string }) {
        this.cleanup();
        const producer = PRODUCER_SPECS[comp.producer];
        this.reverb = new Tone.Reverb({ decay: producer.effects.reverb.decay, wet: comp.reverbMix }).toDestination();
        this.distortion = new Tone.Distortion(comp.saturation);
        this.masterChannel = new Tone.Channel().chain(this.distortion, this.reverb);

        // Connect drum synths
        this.instruments.kick.connect(this.masterChannel);
        this.instruments.snare.connect(this.masterChannel);
        this.instruments.hihat.connect(this.masterChannel);
        
        // V6 Change: Load SoundFont instruments
        [this.instruments.melody, this.instruments.chords, this.instruments.bass] = await Promise.all([
            getInstrument(instrumentSelection.melody),
            getInstrument(instrumentSelection.chords),
            getInstrument(instrumentSelection.bass)
        ]);

        if (!this.analyser) {
            this.analyser = new Tone.Analyser('waveform', 1024);
            this.masterChannel.connect(this.analyser);
        }

        // Schedule drum parts with Tone.js synths
        this.parts.push(new Tone.Part((time, e) => { this.instruments.kick.triggerAttackRelease('C1', '8n', time, e.velocity); }, comp.rhythm.kick).start(0));
        this.parts.push(new Tone.Part((time, e) => { this.instruments.snare.triggerAttackRelease('8n', time, e.velocity); }, comp.rhythm.snare).start(0));
        this.parts.push(new Tone.Part((time, e) => { this.instruments.hihat.triggerAttackRelease('16n', time, e.velocity); }, comp.rhythm.hihat).start(0));
        
        // V6 Change: Schedule melodic parts with SoundFont players
        this.parts.push(new Tone.Part((time, c) => { this.instruments.chords?.play(c.notes[0], time, { duration: Tone.Time(c.duration).toSeconds(), gain: c.velocity }); }, comp.harmony).start(0));
        this.parts.push(new Tone.Part((time, n) => { this.instruments.bass?.play(n.note, time, { duration: Tone.Time(n.duration).toSeconds(), gain: n.velocity }); }, comp.bass).start(0));
        this.parts.push(new Tone.Part((time, n) => { this.instruments.melody?.play(n.note, time, { duration: Tone.Time(n.duration).toSeconds(), gain: n.velocity }); }, comp.melody).start(0));

        Tone.Transport.bpm.value = comp.tempo;
        Tone.Transport.swing = producer.rhythm.swing;
        Tone.Transport.loop = true;
        Tone.Transport.loopEnd = `${comp.bars}m`;
    }

    // Export remains the same as v5. It uses Tone.Offline which will correctly render the scheduled audio.
    // ... (Paste the exportFullMix function from v5 app.txt here)

    play() { Tone.Transport.start(); }
    stop() { Tone.Transport.stop(); Tone.Transport.position = 0; }
    getAnalyser() { return this.analyser; }
    dispose() { this.stop(); this.cleanup(); this.analyser?.dispose(); }
}


// --- CORE LOGIC WRAPPERS (Unchanged from v5) ---
// ... (Paste ThemeDirectorCore, HarmonyCore, RhythmCore, MelodyCore here)
// V6 Change: AudioSynthCore now passes instrument selections
const AudioSynthCore = {
    run: async (plan: any, audioService: AudioService, fullData: any, instrumentSelection: any) => {
        const composition = { ...plan.settings, ...fullData.harmony, ...fullData.rhythm, ...fullData.melody, bars: plan.bars, duration: plan.settings.duration };
        await audioService.schedule(composition, instrumentSelection);
        return { composition };
    }
};

// --- UI COMPONENTS (Unchanged from v5) ---
// ... (Paste LogEntry and ChainNode components here)


// --- MAIN APP COMPONENT (UPDATED FOR V6) ---
export default function App() {
    const [settings, setSettings] = useState<GenerationSettings>({
        genre: 'Lo-fi', producer: 'J Dilla', producerB: 'Default', producerMix: 0, key: 'A minor',
        tempo: 85, duration: 120, complexity: 0.6, rhythmicDensity: 0.9, useProducerProgressions: true,
        energyCurve: { verse: 0.8, chorus: 1.0, bridge: 0.7, intro: 0.6, outro: 0.5 },
        useLoFiVinyl: true, seed: 'gemini-v6', reverbMix: 0.3, saturation: 0.3, melodicContour: 'arch'
    });
    
    // V6 Change: State for instrument selection
    const [instrumentSelection, setInstrumentSelection] = useState({
        melody: 'violin',
        chords: 'piano',
        bass: 'bass-guitar'
    });
    const [availableInstruments, setAvailableInstruments] = useState<string[]>([]);

    const [logs, setLogs] = useState<any[]>([]);
    const [activeChain, setActiveChain] = useState<Core[]>([]);
    const [availableCores] = useState<Core[]>([
        { id: 'theme', name: 'Theme Director', description: 'Establishes mood and structure', icon: 'fas fa-layer-group', generationMode: 'Procedural' },
        { id: 'harmony', name: 'Harmony Core', description: 'Builds chord progressions', icon: 'fas fa-wave-square', generationMode: 'Procedural' },
        { id: 'rhythm', name: 'Rhythm Architect', description: 'Designs drum patterns', icon: 'fas fa-drum', generationMode: 'Procedural' },
        { id: 'melody', name: 'Melody & Bass', description: 'Composes melodic lines', icon: 'fas fa-music', generationMode: 'Procedural' },
        { id: 'synthesis', name: 'Audio Synthesizer', description: 'Renders audio', icon: 'fas fa-sliders-h', generationMode: 'Procedural' },
    ]);
    const [generationStatus, setGenerationStatus] = useState<any>({});
    const [isGenerating, setIsGenerating] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [composition, setComposition] = useState<any>(null);
    const [isExporting, setIsExporting] = useState(false);
    const [isPreloading, setIsPreloading] = useState(false);

    const audioServiceRef = useRef<AudioService | null>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const animationFrameRef = useRef<number | null>(null);

    useEffect(() => {
        audioServiceRef.current = new AudioService();
        audioServiceRef.current.init();
        setAvailableInstruments(listAvailable());
        addLog('info', 'AI Music Studio v6 Initialized.');
        return () => {
            if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
            audioServiceRef.current?.dispose();
        };
    }, []);

    const addLog = (type: string, message: string) => setLogs(prev => [{ type, message, timestamp: new Date().toLocaleTimeString() }, ...prev]);
    
    // drawVisualizer remains the same as v5
    // ... (Paste drawVisualizer function here)

    const handleGenerate = async () => {
        const chain = availableCores;
        setActiveChain(chain);
        setIsGenerating(true);
        setIsPlaying(false);
        audioServiceRef.current?.stop();
        addLog('info', `Generation started with seed: ${settings.seed}`);
        setGenerationStatus(chain.reduce((acc, core) => ({ ...acc, [core.id]: 'idle' }), {}));
        
        const generator = new MusicGenerator(settings.seed);
        let fullData: any = {};
        let hasError = false;

        for (const core of chain) {
            setGenerationStatus(prev => ({ ...prev, [core.id]: 'processing' }));
            try {
                let result: any;
                switch (core.id) {
                    case 'theme': result = ThemeDirectorCore.run(settings, generator); break;
                    case 'harmony': result = HarmonyCore.run(fullData.theme, generator); break;
                    case 'rhythm': result = RhythmCore.run(fullData.theme, generator); break;
                    case 'melody': result = MelodyCore.run(fullData.theme, generator, fullData.harmony); break;
                    // V6 Change: Pass instrument selections to the synth core
                    case 'synthesis': result = await AudioSynthCore.run(fullData.theme, audioServiceRef.current!, fullData, instrumentSelection); setComposition(result.composition); break;
                    default: throw new Error(`Unknown core: ${core.id}`);
                }
                fullData[core.id] = result;
                setGenerationStatus(prev => ({ ...prev, [core.id]: 'complete' }));
                addLog('success', `✓ ${core.name} completed.`);
            } catch (error: any) {
                addLog('error', `✗ ${core.name} failed: ${error.message}`);
                setGenerationStatus(prev => ({ ...prev, [core.id]: 'error' }));
                hasError = true;
                break;
            }
        }
        setIsGenerating(false);
        addLog(hasError ? 'error' : 'success', `Generation ${hasError ? 'failed' : 'complete'}.`);
    };

    const handlePlayToggle = () => {
       // ... (Paste handlePlayToggle from v5)
    };
    
    const handleSave = async () => {
        // ... (Paste handleSave from v5)
    };

    // V6 Change: Handler for preloading a default pack of instruments
    const handlePreloadPack = async () => {
        const pack = ['piano', 'violin', 'cello', 'flute', 'bass-guitar'];
        setIsPreloading(true);
        addLog('info', `Preloading instrument pack: ${pack.join(', ')}`);
        const results = await preloadInstruments(pack);
        if(results.success.length > 0) addLog('success', `Successfully preloaded: ${results.success.join(', ')}`);
        if(results.failed.length > 0) addLog('error', `Failed to preload: ${results.failed.join(', ')}`);
        setIsPreloading(false);
    };
    
    // V6 Change: Handler for downloading the instrument pack
    const handleDownloadPack = async () => {
        const pack = ['piano', 'violin', 'cello', 'flute', 'bass-guitar', 'trumpet'];
        addLog('info', `Packaging instruments for download...`);
        await downloadInstrumentPack(pack);
        addLog('success', 'Download started.');
    };

    const handleSettingChange = (field: keyof GenerationSettings, value: any) => setSettings(prev => ({ ...prev, [field]: value }));
    const handleInstrumentChange = (part: keyof typeof instrumentSelection, value: string) => setInstrumentSelection(prev => ({...prev, [part]: value}));

    return (
        // --- JSX Layout remains largely the same, with new additions for instrument selection ---
        <div className="min-h-screen bg-slate-900 text-slate-100 font-sans p-4">
            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Left Panel: Settings */}
                <div className="lg:col-span-1 bg-slate-800/50 rounded-lg p-6 space-y-4 border border-slate-700">
                    <h1 className="text-2xl font-bold text-purple-400">AI Music Studio v6</h1>
                    {/* ... (Genre, Producer, Key, Tempo, Seed settings from v5) ... */}
                    
                    {/* V6 Change: Instrument Selection UI */}
                    <hr className="border-slate-600"/>
                    <h2 className="text-lg font-bold text-slate-300 pt-2">Sampled Instruments</h2>
                     <div>
                        <label className="text-sm">Melody</label>
                        <select value={instrumentSelection.melody} onChange={e => handleInstrumentChange('melody', e.target.value)} className="w-full bg-slate-700 p-2 rounded">
                            {availableInstruments.map(i => (<option key={i} value={i}>{i}</option>))}
                        </select>
                    </div>
                     <div>
                        <label className="text-sm">Chords</label>
                        <select value={instrumentSelection.chords} onChange={e => handleInstrumentChange('chords', e.target.value)} className="w-full bg-slate-700 p-2 rounded">
                            {availableInstruments.map(i => (<option key={i} value={i}>{i}</option>))}
                        </select>
                    </div>
                     <div>
                        <label className="text-sm">Bass</label>
                        <select value={instrumentSelection.bass} onChange={e => handleInstrumentChange('bass', e.target.value)} className="w-full bg-slate-700 p-2 rounded">
                            {availableInstruments.map(i => (<option key={i} value={i}>{i}</option>))}
                        </select>
                    </div>
                    <div className="flex gap-2 pt-2">
                        <button onClick={handlePreloadPack} disabled={isPreloading} className="bg-sky-600 text-sm w-full px-4 py-2 rounded hover:bg-sky-700 disabled:bg-slate-600">
                            {isPreloading ? 'Preloading...' : 'Preload Pack'}
                        </button>
                        <button onClick={handleDownloadPack} className="bg-gray-600 text-sm w-full px-4 py-2 rounded hover:bg-gray-700">
                            Download Pack
                        </button>
                    </div>
                </div>

                {/* Right Panel: Controls & Output (same as v5) */}
                <div className="lg:col-span-2 bg-slate-800/50 rounded-lg p-6 space-y-4 border border-slate-700">
                     {/* ... (Paste the entire "Right Panel" div from v5 here) ... */}
                </div>
            </div>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
        </div>
    );
}