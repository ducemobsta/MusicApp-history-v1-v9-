#!/usr/bin/env python3
"""
PocketPal.ai Music Generation Bridge
Watches for prompts, returns music concepts via file system
"""

import os
import json
import time
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# Configuration
BRIDGE_DIR = Path(os.path.expanduser("~/MusicAI"))
PROMPT_FILE = BRIDGE_DIR / "prompt.txt"
RESPONSE_FILE = BRIDGE_DIR / "response.json"
STATUS_FILE = BRIDGE_DIR / "status.txt"

# Ensure directories exist
BRIDGE_DIR.mkdir(parents=True, exist_ok=True)
PROMPT_FILE.touch()
RESPONSE_FILE.touch()
STATUS_FILE.touch()


class MusicPromptHandler(FileSystemEventHandler):
    """Handles incoming music generation prompts"""
    
    def __init__(self):
        self.last_prompt = ""
        self.processing = False
        
    def on_modified(self, event):
        if event.src_path == str(PROMPT_FILE) and not self.processing:
            self.process_prompt()
    
    def process_prompt(self):
        """Process the prompt and wait for user to input AI response"""
        try:
            # Read the prompt
            with open(PROMPT_FILE, 'r', encoding='utf-8') as f:
                prompt = f.read().strip()
            
            # Skip if empty or duplicate
            if not prompt or prompt == self.last_prompt:
                return
            
            self.last_prompt = prompt
            self.processing = True
            
            # Update status
            self.write_status("waiting_for_ai")
            
            print("\n" + "="*70)
            print("📝 NEW MUSIC PROMPT RECEIVED")
            print("="*70)
            print(f"\n{prompt}\n")
            print("-"*70)
            print("INSTRUCTIONS:")
            print("1. Copy the prompt above")
            print("2. Open PocketPal.ai")
            print("3. Paste and send the prompt")
            print("4. Copy ONLY the JSON response (the part between { and })")
            print("5. Paste it below and press Enter")
            print("6. Type 'done' on a new line and press Enter")
            print("-"*70)
            
            # Collect multi-line input
            print("\nPaste AI response (then type 'done'):")
            lines = []
            while True:
                line = input()
                if line.strip().lower() == 'done':
                    break
                lines.append(line)
            
            response_text = '\n'.join(lines).strip()
            
            # Try to parse as JSON
            try:
                response_json = json.loads(response_text)
                
                # Write response
                with open(RESPONSE_FILE, 'w', encoding='utf-8') as f:
                    json.dump(response_json, f, indent=2)
                
                self.write_status("ready")
                print("\n✅ Response saved! Web app can now read it.\n")
                
            except json.JSONDecodeError as e:
                print(f"\n❌ Invalid JSON: {e}")
                print("Please try again with valid JSON format.\n")
                self.write_status("error")
            
        except Exception as e:
            print(f"\n❌ Error: {e}\n")
            self.write_status("error")
        finally:
            self.processing = False
    
    def write_status(self, status):
        """Write current status"""
        with open(STATUS_FILE, 'w', encoding='utf-8') as f:
            f.write(status)


def generate_example_prompt(genre, producer, user_input):
    """Generate a well-formatted prompt for PocketPal.ai"""
    return f"""You are HarmonyMind, a music theory AI assistant.

Task: Generate a chord progression for the following music concept.

Genre: {genre}
Producer Style: {producer}
User Request: {user_input}

Respond with ONLY a JSON object in this exact format (no markdown, no explanations):

{{
  "key": "A minor",
  "roman": ["i", "iv", "bVII", "bIII"],
  "tempo": 85,
  "mood": "dark and introspective",
  "description": "Brief description of the progression and its emotional character"
}}

Available keys: C major, A minor, G major, E minor, F major, D minor, C# minor, F minor, F# minor, C minor, Eb major, G minor

Available roman numerals: I, ii, iii, IV, V, vi, vii°, i, ii°, III, iv, v, VI, VII, bII, bIII, bVI, bVII

Generate the JSON now:"""


def main():
    """Main bridge service"""
    print("\n" + "="*70)
    print("🎵 POCKETPAL.AI MUSIC BRIDGE")
    print("="*70)
    print(f"\nBridge directory: {BRIDGE_DIR}")
    print(f"Watching: {PROMPT_FILE}")
    print(f"Output: {RESPONSE_FILE}")
    print("\n✅ Bridge is active and waiting for prompts...")
    print("\nTo test manually, you can also:")
    print(f"  1. Edit {PROMPT_FILE} with a music request")
    print(f"  2. This script will show you the formatted prompt")
    print(f"  3. Copy to PocketPal.ai and paste response back here")
    print("\nPress Ctrl+C to stop.\n")
    print("="*70 + "\n")
    
    # Set up file watcher
    handler = MusicPromptHandler()
    observer = Observer()
    observer.schedule(handler, path=str(BRIDGE_DIR), recursive=False)
    observer.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n\n🛑 Bridge stopped.\n")
        observer.stop()
    
    observer.join()


if __name__ == "__main__":
    # Check dependencies
    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError:
        print("❌ Missing dependency: watchdog")
        print("\nInstall with: pip install watchdog")
        exit(1)
    
    main()
