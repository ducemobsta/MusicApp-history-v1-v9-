/**
 * @name AI Music Generation Engine & Producer Library (Consolidated & Enhanced)
 * @description An enhanced, legally compliant framework for generating original music.
 * This version adds melodic generation, advanced harmony, and producer-specific FX.
 * @version 3.5 (Enhanced)
 * @date November 2, 2025
 * @author AI Music Generation Logic Framework
 * @designedFor Ethical, Legal, and Non-Infringing AI Training in Music Generation
 *
 * @notice All producer profile information is derived from publicly available analysis.
 * This framework generates new works in the *style* of an artist, not to replicate them.
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import * as Tone from 'tone';
import Soundfont from 'soundfont-player';

// ###################################################################################
// SECTION 1: MUSIC THEORY CONSTANTS (EXPANDED)
// ###################################################################################

const NOTE_MAP = {
  'C major': ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4'], 'C minor': ['C4', 'D4', 'Eb4', 'F4', 'G4', 'Ab4', 'Bb4'],
  'C# minor': ['C#4', 'D#4', 'E4', 'F#4', 'G#4', 'A4', 'B4'], 'D minor': ['D4', 'E4', 'F4', 'G4', 'A4', 'Bb4', 'C5'],
  'Eb Major': ['Eb3', 'F3', 'G3', 'Ab3', 'Bb3', 'C4', 'D4'], 'E minor': ['E4', 'F#4', 'G4', 'A4', 'B4', 'C5', 'D5'],
  'F Major': ['F3', 'G3', 'A3', 'Bb3', 'C4', 'D4', 'E4'], 'F Minor': ['F4', 'G4', 'Ab4', 'Bb4', 'C5', 'Db5', 'Eb5'],
  'F# Minor': ['F#4', 'G#4', 'A4', 'B4', 'C#5', 'D5', 'E5'], 'G Major': ['G3', 'A3', 'B3', 'C4', 'D4', 'E4', 'F#4'],
  'G Minor': ['G4', 'A4', 'Bb4', 'C5', 'D5', 'Eb5', 'F5'], 'G# Minor': ['G#4', 'A#4', 'B4', 'C#5', 'D#5', 'E5', 'F#5'],
  'A Minor': ['A4', 'B4', 'C5', 'D5', 'E5', 'F5', 'G5'], 'Bbm': ['Bb3', 'C4', 'Db4', 'Eb4', 'F4', 'Gb4', 'Ab4'],
};

const ROMAN_TO_DEGREE = {
  'I': 0, 'i': 0, 'bII': 1, 'II': 1, 'ii': 1, 'bIII': 2, 'III': 2, 'iii': 2,
  'IV': 3, 'iv': 3, 'V': 4, 'v': 4, 'bVI': 5, 'VI': 5, 'vi': 5, 'bVII': 6, 'VII': 6, 'vii': 6,
};

// Added chord formulas for more complex harmonies
const CHORD_FORMULAS = {
    // Basic Triads
    major: [0, 4, 7], minor: [0, 3, 7],
    // Seventh Chords
    maj7: [0, 4, 7, 11], m7: [0, 3, 7, 10], dom7: [0, 4, 7, 10],
    // Ninth Chords
    maj9: [0, 4, 7, 11, 14], m9: [0, 3, 7, 10, 14]
};

// ###################################################################################
// SECTION 2: INSTRUMENT ENGINE & DATA
// ###################################################################################

const SOUNDFONT_FAMILY = 'FluidR3_GM';
const SOUNDFONT_FORMAT = 'mp3';

export const INSTRUMENT_MAP = {
    'piano': 'acoustic_grand_piano', 'grand_piano': 'acoustic_grand_piano', 'electric-piano': 'electric_piano_1',
    'wurlitzer': 'electric_piano_2', 'rhodes': 'electric_piano_1', 'violin': 'violin', 'cello': 'cello',
    'string_section': 'string_ensemble_1', 'bass': 'acoustic_bass', 'bass-guitar': 'electric_bass_finger',
    'pizzicato': 'pizzicato_strings', 'flute': 'flute', 'oboe': 'oboe', 'saxophone': 'alto_sax',
    'sax_stab': 'alto_sax', 'brass': 'french_horn', 'brass_hit': 'brass_section', 'trumpet': 'trumpet',
    'trumpet_stab': 'trumpet', 'trumpet_section': 'trumpet', 'bells': 'tubular_bells', 'xylophone': 'xylophone',
    'organ': 'rock_organ', 'synth_strings': 'string_ensemble_2', 'choir_pad': 'choir_aahs',
};

export const TONE_PATCHES = {
    '808-glide': { oscillator: { type: 'sine' }, envelope: { attack: 0.005, decay: 0.4, sustain: 0.8, release: 1 }, volume: -2, portamento: 0.08 },
    'quik-plucky-g-funk-lead': { oscillator: { "type": "sawtooth" }, envelope: { "attack": 0.006, "decay": 0.09, "sustain": 0.15, "release": 0.08 }, filter: { "type": "lowpass", "frequency": 3200, "Q": 0.8 }, filterEnvelope: { "attack": 0.01, "decay": 0.08, "sustain": 0.2, "release": 0.1, "baseFrequency": 300, "octaves": 2.5 }, volume: -9 },
    'quik-pulsing-moog-bass': { oscillator: { "type": "sine" }, envelope: { "attack": 0.01, "decay": 0.22, "sustain": 0.85, "release": 0.25 }, filter: { "type": "lowpass", "frequency": 220, "Q": 1.2 }, filterEnvelope: { "attack": 0.02, "decay": 0.1, "sustain": 1, "baseFrequency": 200, "octaves": 1 }, volume: -4 },
    'zaytoven-piano-bass': { oscillator: { type: "triangle" }, envelope: { attack: 0.01, decay: 0.4, sustain: 0.7, release: 0.5 }, filter: { type: 'lowpass', frequency: 300, Q: 1.2 }, volume: -5 },
    'dilla-warm-bass': { oscillator: { type: 'triangle' }, envelope: { attack: 0.02, decay: 0.5, sustain: 0.8, release: 0.4 }, filter: { type: 'lowpass', frequency: 400, Q: 0.8}, volume: -4},
};

const loadedPlayers = new Map();
const loadingPromises = new Map();
const synthFallbacks = new Map();

function createSynthFallback(name) {
    if (synthFallbacks.has(name)) return synthFallbacks.get(name);
    const patch = TONE_PATCHES[name] || {};
    const inst = new Tone.PolySynth(Tone.Synth, patch).toDestination();
    synthFallbacks.set(name, inst);
    return inst;
}

export async function getInstrument(keyName) {
    const canonicalName = INSTRUMENT_MAP[keyName] || keyName;
    if (loadedPlayers.has(canonicalName)) return loadedPlayers.get(canonicalName);
    if (loadingPromises.has(canonicalName)) return loadingPromises.get(canonicalName);

    const promise = (async () => {
        try {
            await Tone.start();
            const player = await Soundfont.instrument(Tone.context.rawContext, canonicalName, { format: SOUNDFONT_FORMAT, soundfont: SOUNDFONT_FAMILY, gain: 2.0 });
            loadedPlayers.set(canonicalName, player);
            return player;
        } catch (error) {
            console.warn(`SoundFont for '${keyName}' failed, using synth fallback.`, error);
            const fallbackSynth = createSynthFallback(keyName);
            return {
                play: (note, time, options) => {
                    const duration = options?.duration || 1;
                    fallbackSynth.triggerAttackRelease(note.toString(), duration, time);
                    return { stop: () => {} };
                },
                stop: () => fallbackSynth.releaseAll(),
                connect: (node) => { // Make fallback connectable
                    fallbackSynth.connect(node);
                    return this;
                }
            };
        }
    })();

    loadingPromises.set(canonicalName, promise);
    const player = await promise;
    loadingPromises.delete(canonicalName);
    return player;
}

// ###################################################################################
// SECTION 3: PRODUCER & STYLE PROFILES (ENHANCED & COMPLETE)
// ###################################################################################

export const PRODUCER_PROFILES = {
    "J Dilla": {
        metadata: { genre: ["Neo-Soul", "Hip-Hop"], producer: "J Dilla", bpm_range: [70, 90], default_bpm: 80, key_preference: ["D Minor", "Eb Major"], swing: 0.6 },
        drums: {
            kick: { sample: "dusty_kick.wav", pattern: [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0], effects: ["saturation:0.3"] },
            snare: { sample: "lofi_snare.wav", pattern: [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:room:0.8s"] },
            hi_hats: { sample: "swung_hats.wav", pattern: [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["highpass:800hz"] }
        },
        harmony: {
            chord_progressions: [ ["ii", "V", "I", "IV"], ["i", "VII", "VI", "V"] ],
            options: { useExtendedChords: true, chordVoicing: "spread" }
        },
        bassline: { type: "dilla-warm-bass" },
        instrumentation: { samples: ["jazz_piano.wav", "vinyl_crackle.wav"], synths: ["rhodes.wav"] },
        effects_chain: { master: [{ type: "saturation", amount: 0.2 }] }
    },
    "Timbaland": {
        metadata: { genre: ["R&B", "Hip-Hop"], producer: "Timbaland", bpm_range: [95, 115], default_bpm: 105, key_preference: ["A Minor", "C# Minor"], swing: 0.7, syncopation: "high" },
        drums: {
            kick: { sample: "deep_808_kick.wav", pattern: [1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0], effects: ["saturation:0.6"] },
            snare: { sample: "snappy_snare.wav", pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], rolls: [["16n", "32n", "16n"]], effects: ["reverb:nonlinear:0.8s"] },
            hi_hats: { sample: "glitchy_hats.wav", pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["reverse:50%"] },
            percussion: { vocal_chops: { sample: ["vocal_hey.wav", "vocal_uh.wav"], pattern: [0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1], effects: ["pitch_shift:+2st"] } }
        },
        harmony: { chord_progressions: [ ["i", "bIII", "bVI", "bVII"], ["i", "bII", "bVI", "bVII"] ] },
        bassline: { type: "808-glide" },
        instrumentation: { synths: ["fm_bell.wav", "dark_pad.wav"], vocal_chops: ["hey.wav", "uh.wav"] },
        effects_chain: { master: [{ type: "distortion", amount: 0.1 }] }
    },
    "Kanye West": {
        metadata: { genre: ["Hip-Hop", "Soul"], producer: "Kanye West", bpm_range: [80, 95], default_bpm: 88, key_preference: ["Eb Major", "C Minor"], swing: 0.4 },
        drums: {
            kick: { sample: "orchestral_kick.wav", pattern: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0], effects: ["saturation:0.5"] },
            snare: { sample: "orchestral_snare.wav", pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:hall:1.5s"] },
            hi_hats: { sample: "tight_hats.wav", pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["highpass:700hz"] }
        },
        harmony: {
            chord_progressions: [["I", "V", "vi", "IV"], ["i", "VI", "III", "VII"]],
            options: { useExtendedChords: true, modalInterchangeChance: 0.15 }
        },
        bassline: { type: "orchestral", waveform: "sine" },
        instrumentation: { samples: ["soul_vocal.wav", "orchestral_hit.wav"], synths: ["string_section.wav"] },
        effects_chain: { master: [{ type: "reverb", decay: 1.5, mix: 0.15 }] }
    },
    "Pharrell Williams": {
        metadata: { genre: ["R&B", "Pop", "Hip-Hop"], producer: "Pharrell Williams", bpm_range: [90, 110], default_bpm: 100, key_preference: ["F Minor", "A Minor", "C Major"], swing: 0.4 },
        drums: {
            kick: { sample: "short_punchy_kick.wav", layer: ["sine_sub_60hz.wav"], pattern: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0], effects: ["saturation:0.3"] },
            snare: { sample: "metallic_snare.wav", pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:plate:1.2s"] },
            hi_hats: { sample: "closed_hats_shimmer.wav", pattern: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], effects: ["highpass:500hz"] },
            percussion: { finger_snaps: { sample: "finger_snap.wav", pattern: [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1], effects: ["delay:1/16"] } }
        },
        harmony: { chord_progressions: [ ["i", "iv", "V"], ["vi", "IV", "I", "V"] ], bassline: { type: "plucky_funk", waveform: "saw" } },
        instrumentation: { synths: ["rhodes.wav", "wurlitzer.wav", "funk_guitar.wav"], layers: { pads: ["atmospheric_pad.wav"] } }
    },
    "Zaytoven": {
        metadata: { genre: ["Trap", "Drill"], producer: "Zaytoven", bpm_range: [120, 150], default_bpm: 140, key_preference: ["C Minor", "F Minor"], swing: 0.2, half_time_feel: true },
        drums: {
            kick: { sample: "aggressive_808.wav", pattern: [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["saturation:0.8"] },
            snare: { sample: "crisp_snare.wav", pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:room:0.5s"] },
            hi_hats: { sample: "rolling_hats.wav", pattern: [1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0], flams: true, effects: ["delay:1/32"] },
        },
        harmony: { chord_progressions: [ ["i", "III", "vi", "V"], ["i", "v", "IV", "i"] ]},
        bassline: { type: "808-glide"},
        instrumentation: { piano: { sample: "detuned_piano.wav" }, brass: ["trumpet_stab.wav"] },
        effects_chain: { master: [{ type: "saturation", amount: 0.6 }] }
    },
    "Dr. Dre": {
        metadata: { genre: ["Hip-Hop", "G-Funk"], producer: "Dr. Dre", bpm_range: [85, 95], default_bpm: 90, key_preference: ["C Minor", "F Minor"], swing: 0.5 },
        drums: {
            kick: { sample: "deep_808_kick.wav", pattern: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0], effects: ["saturation:0.7"] },
            snare: { sample: "crisp_snare.wav", pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], effects: ["reverb:plate:1.0s"] },
            hi_hats: { sample: "swung_hats.wav", pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], effects: ["highpass:600hz"] }
        },
        harmony: { chord_progressions: [ ["i", "VI", "VII", "i"], ["i", "iv", "VII", "III"] ] },
        bassline: { type: "deep_synth", waveform: "sine", effects: ["distortion:0.5"] },
        instrumentation: { synths: ["funky_synth.wav", "piano_loop.wav"], guitars: ["funk_guitar.wav"] }
    },
    "DJ Quik": {
        metadata: { genre: ["Hip-Hop", "G-Funk"], producer: "DJ Quik", bpm_range: [85, 100], default_bpm: 92, key_preference: ["G Minor", "C Minor"], swing: 0.55 },
        drums: {
             kick: { sample: "punchy_kick.wav", pattern: [1,0,0,0,1,0,0,0,1,0,0,0,1,0,1,0] },
             snare: { sample: "crisp_snare.wav", pattern: [0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0] },
             hi_hats: { sample: "swung_hats.wav", pattern: [1,0,1,0,1,1,1,0,1,0,1,0,1,1,1,0] },
        },
        harmony: { chord_progressions: [ ["i", "bVII", "bVI", "V7"], ["I", "V", "vi", "IV"] ] },
        bassline: { type: "quik-pulsing-moog-bass" },
        instrumentation: { synths: ["quik-plucky-g-funk-lead", "quik-funk-keyboard-wah"] }
    },
};

// ###################################################################################
// SECTION 4 & 5: GENERATION ENGINES (REFACTORED & EXPANDED)
// ###################################################################################

function patternToNotes(patternArray, barIndex, velocity = 1.0) {
  const notes = [];
  if (!Array.isArray(patternArray)) return notes;
  for (let i = 0; i < patternArray.length; i++) {
    if (patternArray[i] === 1) {
      const beat = Math.floor(i / 4);
      const sixteenth = i % 4;
      notes.push({ time: `${barIndex}:${beat}:${sixteenth}`, velocity });
    }
  }
  return notes;
}

export function generateDrumSequence(profile, bars) {
  const sequence = { kick: [], snare: [], hi_hats: [], percussion: [] };
  const drumParts = profile.drums;

  for (let bar = 0; bar < bars; bar++) {
    if (drumParts.kick) sequence.kick.push(...patternToNotes(drumParts.kick.pattern, bar, 0.95));
    if (drumParts.snare) sequence.snare.push(...patternToNotes(drumParts.snare.pattern, bar, 0.9));
    if (drumParts.hi_hats) sequence.hi_hats.push(...patternToNotes(drumParts.hi_hats.pattern, bar, 0.7));
    if (drumParts.percussion) {
        for(const percPart of Object.values(drumParts.percussion)){
            sequence.percussion.push(...patternToNotes(percPart.pattern, bar, 0.65));
        }
    }
  }
  return sequence;
}

export function generateChordProgression(profile, bars) {
    const scaleName = profile.metadata.key_preference[0] || 'C Minor';
    const scaleNotes = NOTE_MAP[scaleName];
    if (!scaleNotes) { console.error(`Scale not found: ${scaleName}`); return []; }

    const progressions = profile.harmony.chord_progressions;
    const selectedProgression = progressions[Math.floor(Math.random() * progressions.length)];
    const useExtended = profile.harmony.options?.useExtendedChords || false;
    const modalChance = profile.harmony.options?.modalInterchangeChance || 0;

    const chordSequence = [];
    for (let bar = 0; bar < bars; bar++) {
        let numeral = selectedProgression[bar % selectedProgression.length];
        
        if (Math.random() < modalChance) {
            if (scaleName.includes('Major')) numeral = ['bIII', 'bVI', 'bVII'][Math.floor(Math.random() * 3)];
        }
        
        const degree = ROMAN_TO_DEGREE[numeral.replace(/[^ivb#]+/i, '')] ?? 0;
        const rootNote = scaleNotes[degree % scaleNotes.length];
        
        let quality = (numeral === numeral.toUpperCase()) ? 'major' : 'minor';
        let chordType = useExtended ? (quality === 'major' ? 'maj7' : 'm7') : (quality === 'major' ? 'major' : 'minor');
        
        if (useExtended && Math.random() < 0.4) {
             chordType = quality === 'major' ? 'maj9' : 'm9';
        }

        const formula = CHORD_FORMULAS[chordType];
        const rootMidi = Tone.Frequency(rootNote).toMidi();
        const chordNotes = formula.map(interval => Tone.Frequency(rootMidi + interval, "midi").toNote());

        chordSequence.push({ time: `${bar}:0:0`, notes: chordNotes, duration: '1m' });
    }
    return chordSequence;
}

export function generateBassline(chordSequence, profile) {
    const bassline = [];
    chordSequence.forEach(chord => {
        const rootMidi = Tone.Frequency(chord.notes[0]).toMidi();
        const bassNote = Tone.Frequency(rootMidi - 24, 'midi').toNote();
        bassline.push({ time: chord.time, note: bassNote, duration: '4n' });
        bassline.push({ time: `${chord.time.split(':')[0]}:2:2`, note: bassNote, duration: '8n' });
    });
    return bassline;
}

export function generateMelody(chordSequence, profile) {
    const melody = [];
    const scaleName = profile.metadata.key_preference[0] || 'C Minor';
    const scaleNotes = NOTE_MAP[scaleName].map(n => Tone.Frequency(n).toMidi());

    chordSequence.forEach(chord => {
        const bar = chord.time.split(':')[0];
        const chordNotesMidi = chord.notes.map(n => Tone.Frequency(n).toMidi() % 12);
        
        for (let beat = 0; beat < 4; beat++) {
            if (Math.random() < 0.6) {
                let notePool = Math.random() < 0.7 ? chordNotesMidi : scaleNotes.map(n => n % 12);
                let selectedNoteMidi = notePool[Math.floor(Math.random() * notePool.length)];
                
                const finalNote = Tone.Frequency(selectedNoteMidi + 60, 'midi').toNote();
                melody.push({ time: `${bar}:${beat}:0`, note: finalNote, duration: '16n' });
            }
        }
    });
    return melody;
}

// ###################################################################################
// SECTION 6: EXAMPLE REACT COMPONENT (UPDATED & COMPLETE)
// ###################################################################################

export default function AiMusicEngineDemo() {
    const [selectedProducer, setSelectedProducer] = useState("J Dilla");
    const [isPlaying, setIsPlaying] = useState(false);
    const [status, setStatus] = useState("Ready. Select a producer and click Generate & Play.");
    const partsRef = useRef([]);
    const synthsRef = useRef({});
    const effectsRef = useRef({});

    const cleanup = useCallback(() => {
        partsRef.current.forEach(part => part.dispose());
        Object.values(synthsRef.current).forEach(synth => synth.dispose());
        Object.values(effectsRef.current).forEach(fx => fx.dispose());
        partsRef.current = [];
        synthsRef.current = {};
        effectsRef.current = {};
        Tone.Transport.stop();
        Tone.Transport.cancel();
    }, []);
    
    useEffect(() => {
        return () => cleanup();
    }, [cleanup]);

    const handlePlay = useCallback(async () => {
        if (isPlaying) {
            Tone.Transport.stop();
            setIsPlaying(false);
            setStatus("Playback stopped.");
            return;
        }

        await Tone.start();
        setIsPlaying(true);
        setStatus(`Generating a 4-bar loop in the style of ${selectedProducer}...`);
        
        cleanup();

        const profile = PRODUCER_PROFILES[selectedProducer];
        if (!profile) {
            setStatus(`Error: Profile for ${selectedProducer} not found.`);
            setIsPlaying(false);
            return;
        }

        Tone.Transport.bpm.value = profile.metadata.default_bpm;
        Tone.Transport.swing = profile.metadata.swing;
        Tone.Transport.loop = true;
        Tone.Transport.loopEnd = '4m';

        const masterChannel = new Tone.Channel().toDestination();
        let lastNode = masterChannel;
        if (profile.effects_chain?.master) {
            profile.effects_chain.master.forEach(fxConfig => {
                let effect;
                if (fxConfig.type === 'saturation') {
                    effect = new Tone.Saturation(fxConfig.amount).connect(lastNode);
                    effectsRef.current.saturation = effect;
                } else if (fxConfig.type === 'reverb') {
                    effect = new Tone.Reverb({ decay: fxConfig.decay, wet: fxConfig.mix }).connect(lastNode);
                    effectsRef.current.reverb = effect;
                } else if (fxConfig.type === 'distortion') {
                     effect = new Tone.Distortion(fxConfig.amount).connect(lastNode);
                    effectsRef.current.distortion = effect;
                }
                if (effect) lastNode = effect;
            });
        }
        
        setStatus("Generating drum, harmony, bass, and melody parts...");
        const drumSequence = generateDrumSequence(profile, 4);
        const chordSequence = generateChordProgression(profile, 4);
        const bassSequence = generateBassline(chordSequence, profile);
        const melodySequence = generateMelody(chordSequence, profile);

        synthsRef.current.kick = new Tone.MembraneSynth().connect(lastNode);
        synthsRef.current.snare = new Tone.NoiseSynth({noise: {type: 'pink'}, envelope: {attack: 0.001, decay: 0.2, sustain: 0}}).connect(lastNode);
        synthsRef.current.hihat = new Tone.MetalSynth({frequency: 250, envelope: {attack:0.001, decay: 0.05}, harmonicity: 5.1, resonance: 4000}).connect(lastNode);
        synthsRef.current.piano = (await getInstrument('piano'));
        synthsRef.current.piano.connect(lastNode);
        
        const bassPatch = TONE_PATCHES[profile.bassline.type] || TONE_PATCHES['quik-pulsing-moog-bass'];
        synthsRef.current.bass = new Tone.MonoSynth(bassPatch).connect(lastNode);
        
        synthsRef.current.melody = new Tone.PolySynth(Tone.Synth, { oscillator: { type: 'triangle' }, envelope: { attack: 0.005, decay: 0.1, sustain: 0.3, release: 1 }, volume: -10 }).connect(lastNode);

        const newParts = [
            new Tone.Part((time) => synthsRef.current.kick.triggerAttackRelease("C1", "8n", time), drumSequence.kick).start(0),
            new Tone.Part((time) => synthsRef.current.snare.triggerAttackRelease("16n", time), drumSequence.snare).start(0),
            new Tone.Part((time) => synthsRef.current.hihat.triggerAttackRelease("C6", "32n", time), drumSequence.hi_hats).start(0),
            new Tone.Part((time, value) => synthsRef.current.piano.play(value.notes, time, { duration: Tone.Time(value.duration).toSeconds() }), chordSequence).start(0),
            new Tone.Part((time, value) => synthsRef.current.bass.triggerAttackRelease(value.note, value.duration, time), bassSequence).start(0),
            new Tone.Part((time, value) => synthsRef.current.melody.triggerAttackRelease(value.note, value.duration, time), melodySequence).start(0),
        ];
        partsRef.current = newParts;

        Tone.Transport.start();
        setStatus(`Playing in the style of ${selectedProducer}. Tempo: ${profile.metadata.default_bpm} BPM.`);

    }, [isPlaying, selectedProducer, cleanup]);
    
    return (
        <div style={{ fontFamily: 'sans-serif', padding: '20px', backgroundColor: '#f0f0f0', borderRadius: '8px', maxWidth: '800px', margin: 'auto' }}>
            <h1>AI Music Generation Engine Demo (v3.5)</h1>
            <p><strong>Status:</strong> {status}</p>
            <div style={{ margin: '20px 0' }}>
                <label htmlFor="producer-select" style={{ marginRight: '10px' }}>Select Producer Style:</label>
                <select 
                    id="producer-select"
                    value={selectedProducer}
                    onChange={(e) => setSelectedProducer(e.target.value)}
                    style={{ padding: '8px', fontSize: '16px' }}
                >
                    {Object.keys(PRODUCER_PROFILES).map(name => <option key={name} value={name}>{name}</option>)}
                </select>
            </div>
            <button 
                onClick={handlePlay} 
                style={{ padding: '10px 20px', fontSize: '16px', cursor: 'pointer', backgroundColor: isPlaying ? '#ff6666' : '#66cc66', color: 'white', border: 'none', borderRadius: '5px' }}
            >
                {isPlaying ? 'Stop' : 'Generate & Play'}
            </button>
        </div>
    );
}