// Inside your App component

const playNoteFromAI = (event) => {
    const { instrument, note, genre } = event; // AI provides this info

    const mapping = INSTRUMENT_MAP[instrument];
    if (!mapping) {
        console.warn(`No mapping found for instrument: ${instrument}`);
        return;
    }

    // For one-shot samples (drums, guitars, fx)
    if (mapping.group !== 'keys') {
        // We'll need to slightly modify the API to accept a genre override
        // Let's assume we add that.
        GenreSamplerAPI.triggerCustom(mapping.group, mapping.sample, genre);
    } 
    // For pitched samples
    else {
        // Here, the AI's 'note' (e.g., 'C#4') is what we want to play
        GenreSamplerAPI.triggerKeyNote(note, '4n', genre); // We'll add this new API function
    }
};