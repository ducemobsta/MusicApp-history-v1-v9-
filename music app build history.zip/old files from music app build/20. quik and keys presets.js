export const TONE_PATCHES_QUIK_ALICIA = {
  quikPluckLead: {
    oscillator: { type: "sawtooth" },
    envelope: { attack: 0.006, decay: 0.09, sustain: 0.15, release: 0.08 },
    filter: { type: "lowpass", frequency: 3200, Q: 0.8 },
    volume: -6
  },
  aliciaWurli: {
    oscillator: { type: "triangle" },
    envelope: { attack: 0.008, decay: 0.6, sustain: 0.7, release: 0.9 },
    filter: { type: "lowpass", frequency: 6000, Q: 0.7 },
    volume: -2
  },
  // ... all other Tone.js-ready patches
};