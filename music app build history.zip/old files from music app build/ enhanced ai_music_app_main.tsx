import React, { useState, useEffect, useCallback, useRef, memo } from 'react';
import * as Tone from 'tone';

// #############################################################################
// --- SECTION 1: DATA & PRESETS (Verified & Finalized) ---
// #############################################################################

const NOTE_MAP = {
    'C major': ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5'], 'A minor': ['A3', 'B3', 'C4', 'D4', 'E4', 'F4', 'G4', 'A4'],
    'G major': ['G3', 'A3', 'B3', 'C4', 'D4', 'E4', 'F#4', 'G4'], 'E minor': ['E3', 'F#3', 'G3', 'A3', 'B3', 'C4', 'D4', 'E4'],
    'F major': ['F3', 'G3', 'A3', 'Bb3', 'C4', 'D4', 'E4', 'F4'], 'D minor': ['D3', 'E3', 'F3', 'G3', 'A3', 'Bb3', 'C4', 'D4'],
    'C# minor': ['C#3', 'D#3', 'E3', 'F#3', 'G#3', 'A3', 'B3', 'C#4'], 'F minor': ['F3', 'G3', 'Ab3', 'Bb3', 'C4', 'Db4', 'Eb4', 'F4'],
    'F# minor': ['F#3', 'G#3', 'A3', 'B3', 'C#4', 'D4', 'E4', 'F#4'], 'C minor': ['C3', 'D3', 'Eb3', 'F3', 'G3', 'Ab3', 'Bb3', 'C4'],
    'Eb major': ['Eb3', 'F3', 'G3', 'Ab3', 'Bb3', 'C4', 'D4', 'Eb4'], 'G minor': ['G3', 'A3', 'Bb3', 'C4', 'D4', 'Eb4', 'F4', 'G4']
};

const ROMAN_TO_DEGREE = {
    'I': 0, 'i': 0, 'II': 1, 'ii': 1, 'III': 2, 'iii': 2,
    'IV': 3, 'iv': 3, 'V': 4, 'v': 4, 'VI': 5, 'vi': 5,
    'VII': 6, 'vii': 6,
};

const PRODUCER_SPECS = {
    'Pharrell': { effects: { saturation: 0.2, reverb: { mix: 0.3, decay: 1.2 } }, rhythm: { swing: 0.4 } }, 'Timbaland': { effects: { saturation: 0.6, reverb: { mix: 0.25, decay: 0.8 } }, rhythm: { swing: 0.7 } },
    'Zaytoven': { effects: { saturation: 0.9, reverb: { mix: 0.4, decay: 1.5 } }, rhythm: { swing: 0.2 } }, 'Just Blaze': { effects: { saturation: 0.3, reverb: { mix: 0.5, decay: 2.5 } }, rhythm: { swing: 0.5 } },
    'Missy Elliott': { effects: { saturation: 0.8, reverb: { mix: 0.35, decay: 1.0 } }, rhythm: { swing: 0.8 } }, 'Dr. Dre': { effects: { saturation: 0.7, reverb: { mix: 0.4, decay: 2.0 } }, rhythm: { swing: 0.5 } },
    'J Dilla': { effects: { saturation: 0.3, reverb: { mix: 0.3, decay: 0.8 } }, rhythm: { swing: 0.6 } }, 'Kanye West': { effects: { saturation: 0.5, reverb: { mix: 0.6, decay: 3.0 } }, rhythm: { swing: 0.4 } },
    'DJ Quik': { effects: { saturation: 0.4, reverb: { mix: 0.35, decay: 1.5 } }, rhythm: { swing: 0.6 } }, 'No I.D.': { effects: { saturation: 0.3, reverb: { mix: 0.4, decay: 1.8 } }, rhythm: { swing: 0.5 } },
    'Default': { effects: { saturation: 0.4, reverb: { mix: 0.3, decay: 1.5 } }, rhythm: { swing: 0.3 } }
};

const GENRE_SPECS = {
    'Trap': { bpm: { min: 130, max: 170, common: 140 }, structure: { intro: 8, verse: 16, chorus: 16, bridge: 8, outro: 8 } },
    'Trap-Soul': { bpm: { min: 60, max: 100, common: 80 }, structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 } },
    'R&B': { bpm: { min: 90, max: 120, common: 95 }, structure: { intro: 4, verse: 8, chorus: 8, bridge: 8, outro: 4 } },
    'Soul': { bpm: { min: 90, max: 120, common: 95 }, structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 } },
    '90s Rap': { bpm: { min: 80, max: 110, common: 90 }, structure: { intro: 4, verse: 16, chorus: 8, outro: 4 } },
    'Lo-fi': { bpm: { min: 80, max: 110, common: 85 }, structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 } },
    'Drill': { bpm: { min: 135, max: 150, common: 142 }, structure: { intro: 4, verse: 16, chorus: 8, outro: 4 } },
    'G-Funk': { bpm: { min: 85, max: 100, common: 90 }, structure: { intro: 4, verse: 8, chorus: 8, outro: 4 } },
    'Neo-Soul': { bpm: { min: 70, max: 90, common: 80 }, structure: { intro: 4, verse: 8, chorus: 8, bridge: 8, outro: 4 } }
};


// #############################################################################
// --- SECTION 2: CORE MUSIC GENERATION LOGIC (UPGRADED) ---
// #############################################################################

class MusicGenerator {
    constructor(seed) {
        let h = 1779033703;
        for (let i = 0; i < seed.length; i++) {
            h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
            h = h << 13 | h >>> 19;
        }
        this.random = () => { h = Math.imul(h ^ h >>> 16, 2246822507); h = Math.imul(h ^ h >>> 13, 3266489909); return ((h ^= h >>> 16) >>> 0) / 4294967296; };
    }
    
    generateStructure(totalBars, template) {
        const sections = []; let currentBar = 0;
        const order = ['intro', 'verse', 'chorus', 'verse', 'chorus', 'bridge', 'chorus', 'outro'];
        for (const sectionType of order) {
            if (currentBar >= totalBars) break;
            const length = template[sectionType] || 4;
            const end = Math.min(currentBar + length, totalBars);
            sections.push({ type: sectionType, start: currentBar, end });
            currentBar = end;
        }
        return sections;
    }

    generateHarmony(scale, bars, progressionNumerals) {
        const chords = [];
        for (let bar = 0; bar < bars; bar++) {
            const numeral = progressionNumerals[bar % progressionNumerals.length];
            const match = numeral.match(/[iv]+/i);
            const rootNumeral = match ? match[0] : 'i';
            const degree = ROMAN_TO_DEGREE[rootNumeral] || 0;
            
            const notes = [scale[degree % scale.length], scale[(degree + 2) % scale.length], scale[(degree + 4) % scale.length]];
            if (numeral.includes('7') || this.random() > 0.4) {
                notes.push(scale[(degree + 6) % scale.length]);
            }
            chords.push({ time: `${bar}:0:0`, notes, duration: '1m', velocity: 0.7, instrument: 'chords' });
        }
        return chords;
    }

    generateLeadMelody(scale, bars, harmony, complexity) {
        const melody = [];
        const rhythmicMotif = this.random() > 0.5 ? ['8n', '16n', '16n'] : ['4n', '8n'];
        let motifIndex = 0;

        for (let b = 0; b < bars; b++) {
            const currentChord = harmony.find(c => c.time === `${b}:0:0`);
            if (!currentChord) continue;

            const chordTones = currentChord.notes.map(n => n.slice(0, -1)); // e.g., ['C', 'E', 'G']
            
            for (let i = 0; i < 4; i++) { // 4 beats per bar
                if (this.random() < 0.85 * complexity) { // Chance to play a note
                    const isStrongBeat = i === 0 || i === 2;
                    let noteToPlay;

                    // On strong beats, prefer a chord tone
                    if (isStrongBeat && this.random() > 0.2) {
                        noteToPlay = chordTones[Math.floor(this.random() * chordTones.length)] + '5'; // Play in a higher octave
                    } else {
                        // On weak beats or by chance, play a scale note (passing tone)
                        const scaleNoteIndex = Math.floor(this.random() * scale.length);
                        noteToPlay = scale[scaleNoteIndex].replace('4', '5'); // Transpose to 5th octave
                    }
                    
                    const duration = rhythmicMotif[motifIndex % rhythmicMotif.length];
                    motifIndex++;
                    
                    melody.push({
                        time: `${b}:${i}:0`,
                        note: noteToPlay,
                        duration: duration,
                        velocity: 0.6 + this.random() * 0.4,
                        instrument: 'melody'
                    });
                }
            }
        }
        return melody;
    }

    generateBass(harmony) {
        return harmony.map(c => ({ 
            time: c.time, 
            note: `${c.notes[0].slice(0, -1)}2`, // Root note in octave 2
            duration: '2n', 
            velocity: 0.9 + this.random() * 0.1,
            instrument: 'bass' 
        }));
    }
     
    generateRhythm(bars) {
        const rhythm = { kick: [], snare: [], hihat: [] };
        const kickPattern = [1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0];
        const snarePattern = [0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0];
        
        for (let b = 0; b < bars; b++) {
            for (let i = 0; i < 16; i++) {
                const time = `${b}:${Math.floor(i / 4)}:${i % 4}`;
                if (kickPattern[i] === 1 && this.random() < 0.95) {
                    rhythm.kick.push({ time, velocity: 0.9, instrument: 'kick' });
                }
                if (snarePattern[i] === 1 && this.random() < 0.98) {
                    rhythm.snare.push({ time, velocity: 0.85, instrument: 'snare' });
                }
                if (i % 2 === 0 || this.random() < 0.4) { // Add some 16th note fills
                    rhythm.hihat.push({ time, velocity: 0.4 + this.random() * 0.2, instrument: 'hihat' });
                }
            }
        }
        return rhythm;
    }
}


// #############################################################################
// --- SECTION 3: AUDIO SERVICE (with Virtual Mixer) ---
// #############################################################################

class AudioService {
    constructor(updateStatusCallback) {
        this.updateStatus = updateStatusCallback;
        this.isReady = false;
        this.parts = [];

        // Core mixer components
        this.masterChannel = null;
        this.limiter = null;
        this.reverbBus = null;
        this.delayBus = null;

        // Instrument tracks and sources
        this.instrumentChannels = new Map();
        this.instrumentEQs = new Map();
        this.synths = {};
    }

    async init() {
        if (this.isReady) return;
        this.updateStatus("Initializing virtual mixer...");
        await Tone.start();

        // 1. Master Channel and Limiter (to prevent clipping)
        this.masterChannel = new Tone.Channel().toDestination();
        this.limiter = new Tone.Limiter(-3).connect(this.masterChannel);

        // 2. FX Buses (Sends)
        this.reverbBus = new Tone.Reverb({ decay: 2.5, predelay: 0.01, wet: 1 }).connect(this.limiter);
        this.delayBus = new Tone.FeedbackDelay("8n", 0.4).connect(this.reverbBus); // Delay feeds into reverb

        // 3. Create Synth Sources
        this.synths = {
            melody: new Tone.PolySynth(Tone.Synth, { oscillator: { type: 'sawtooth' }, envelope: { attack: 0.01, decay: 0.4, sustain: 0.6, release: 0.5 } }),
            chords: new Tone.PolySynth(Tone.FMSynth, { harmonicity: 1.5, modulationIndex: 10, envelope: { attack: 0.02, decay: 0.8, sustain: 0.3, release: 1.2 } }),
            bass: new Tone.MonoSynth({ oscillator: { type: 'sine' }, envelope: { attack: 0.01, decay: 0.3, sustain: 0.9, release: 0.8 } }),
            kick: new Tone.MembraneSynth({ pitchDecay: 0.05, octaves: 10, oscillator: { type: 'sine' }, envelope: { attack: 0.001, decay: 0.4, sustain: 0.01, release: 1.4 } }),
            snare: new Tone.NoiseSynth({ noise: { type: 'white' }, envelope: { attack: 0.001, decay: 0.2, sustain: 0 } }),
            hihat: new Tone.MetalSynth({ frequency: 300, envelope: { attack: 0.001, decay: 0.1, release: 0.02 }, harmonicity: 5.1, modulationIndex: 32, resonance: 4000, octaves: 1.5 })
        };

        this.isReady = true;
        this.updateStatus("Audio engine is ready.");
    }

    createInstrumentTrack(instrumentName) {
        if (this.instrumentChannels.has(instrumentName)) {
            return;
        }

        const channel = new Tone.Channel({ volume: -9, pan: 0, mute: false }).connect(this.limiter);
        channel.send(this.reverbBus, -Infinity); // -Infinity dB = no send
        channel.send(this.delayBus, -Infinity);

        const eq = new Tone.EQ3({ low: 0, mid: 0, high: 0 }).connect(channel);
        
        this.instrumentChannels.set(instrumentName, channel);
        this.instrumentEQs.set(instrumentName, eq);
        
        // Connect the actual synth/sampler to the EQ
        if (this.synths[instrumentName]) {
            this.synths[instrumentName].connect(eq);
        }
    }

    cleanup() {
        this.parts.forEach(p => p.dispose());
        this.parts = [];
        if (Tone.Transport.state === 'started') Tone.Transport.stop();
        Tone.Transport.cancel();
    }

    schedule(comp) {
        this.cleanup();

        // 1. Identify all unique instruments and create their mixer tracks
        const allInstruments = ['melody', 'chords', 'bass', 'kick', 'snare', 'hihat'];
        allInstruments.forEach(inst => this.createInstrumentTrack(inst));

        // 2. Apply Procedural Mixing based on instrument role
        this.instrumentChannels.get('kick')?.set({ volume: -2, pan: 0 });
        this.instrumentEQs.get('kick')?.set({ low: 2, mid: -2, high: -6 });

        this.instrumentChannels.get('snare')?.set({ volume: -5, pan: 0.05 });
        this.instrumentEQs.get('snare')?.set({ low: -4, mid: 2, high: 1 });
        this.instrumentChannels.get('snare')?.send(this.reverbBus, -20); // A little reverb on the snare

        this.instrumentChannels.get('hihat')?.set({ volume: -18, pan: -0.1 });
        this.instrumentEQs.get('hihat')?.set({ low: -12, mid: 0, high: 4 });

        this.instrumentChannels.get('bass')?.set({ volume: -4, pan: 0 });
        this.instrumentEQs.get('bass')?.set({ low: 3, mid: -3, high: -10 }); // Boost lows, cut highs to avoid mud

        this.instrumentChannels.get('chords')?.set({ volume: -15, pan: 0 });
        this.instrumentEQs.get('chords')?.set({ low: -8, mid: 0, high: -4 }); // Cut lows to make space for bass
        this.instrumentChannels.get('chords')?.send(this.reverbBus, -15);
        this.instrumentChannels.get('chords')?.send(this.delayBus, -22);

        this.instrumentChannels.get('melody')?.set({ volume: -9, pan: 0 });
        this.instrumentEQs.get('melody')?.set({ low: -10, mid: 3, high: 2 }); // Carve out space in the mids for the lead
        this.instrumentChannels.get('melody')?.send(this.reverbBus, -12);
        this.instrumentChannels.get('melody')?.send(this.delayBus, -18);

        // 3. Schedule all events in a single Tone.Part
        const allEvents = [
            ...comp.harmony, ...comp.melody, ...comp.bass,
            ...comp.rhythm.kick, ...comp.rhythm.snare, ...comp.rhythm.hihat
        ];

        const part = new Tone.Part((time, event) => {
            const { instrument, note, notes, duration, velocity } = event;
            const synth = this.synths[instrument];
            if (!synth) return;

            // Trigger the correct synth based on the event
            if (instrument === 'melody' || instrument === 'chords') {
                synth.triggerAttackRelease(notes || note, duration, time, velocity);
            } else if (instrument === 'bass') {
                synth.triggerAttackRelease(note, duration, time, velocity);
            } else if (instrument === 'kick') {
                synth.triggerAttackRelease('C1', '8n', time, velocity);
            } else if (instrument === 'snare') {
                synth.triggerAttackRelease('16n', time, velocity);
            } else if (instrument === 'hihat') {
                synth.triggerAttackRelease('C6', '32n', time, velocity);
            }
        }, allEvents).start(0);

        this.parts.push(part);
        Tone.Transport.bpm.value = comp.tempo;
        Tone.Transport.swing = comp.swing;
        Tone.Transport.loop = true;
        Tone.Transport.loopEnd = `${comp.bars}m`;
    }

    play() {
        if (Tone.Transport.state !== 'started') {
            Tone.Transport.start();
        }
    }

    stop() {
        if (Tone.Transport.state === 'started') {
            Tone.Transport.stop();
        }
    }
}


// #############################################################################
// --- SECTION 4: UI COMPONENTS (Memoized) ---
// #############################################################################

const LogEntry = memo(({ log }) => (
    <div className={`p-2 mb-2 rounded border-l-4 font-mono text-sm bg-gray-800/50 border-${log.type === 'success' ? 'green-500' : log.type === 'error' ? 'red-500' : 'blue-500'} text-gray-300`}>
        <span className="mr-3 text-gray-500">[{log.timestamp}]</span><span>{log.message}</span>
    </div>
));

const ChainNode = memo(({ core, status }) => {
    const statusClasses = { idle: 'bg-gray-700 border-gray-500', processing: 'bg-blue-500/50 border-blue-400 animate-pulse', complete: 'bg-green-500/50 border-green-400', error: 'bg-red-500/50 border-red-400' };
    return (
        <div className="text-center">
            <div className={`w-16 h-16 rounded-full mx-auto mb-2 flex items-center justify-center text-2xl border-2 ${statusClasses[status]}`}><i className={core.icon}></i></div>
            <div className="text-sm font-medium">{core.name}</div>
        </div>
    );
});


// #############################################################################
// --- SECTION 5: MAIN APP COMPONENT ---
// #############################################################################

export default function App() {
    const [settings, setSettings] = useState({
        genre: 'Lo-fi', producer: 'J Dilla', key: 'A minor', tempo: 85, duration: 20, complexity: 0.65,
        progression: ['i', 'v', 'bVI', 'bVII'], // Default progression
        seed: 'gemini-v11-final',
    });
    
    const [logs, setLogs] = useState([]);
    const [generationStatus, setGenerationStatus] = useState({});
    const [isGenerating, setIsGenerating] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [composition, setComposition] = useState(null);
    const [audioStatus, setAudioStatus] = useState('uninitialized');

    const audioServiceRef = useRef(null);

    const availableCores = [
      { id: 'theme', name: 'Theme', icon: 'fas fa-layer-group' }, { id: 'harmony', name: 'Harmony', icon: 'fas fa-wave-square' },
      { id: 'rhythm', name: 'Rhythm', icon: 'fas fa-drum' }, { id: 'melody', name: 'Melody', icon: 'fas fa-music' },
      { id: 'synthesis', name: 'Synth', icon: 'fas fa-sliders-h' },
    ];

    const addLog = useCallback((type, message) => { setLogs(prev => [{ type, message, timestamp: new Date().toLocaleTimeString() }, ...prev.slice(0, 99)]); }, []);

    useEffect(() => {
        const initAudio = async () => {
            if (audioStatus !== 'uninitialized' || audioServiceRef.current) return;
            try {
                setAudioStatus('initializing');
                audioServiceRef.current = new AudioService((status) => addLog('info', status));
                await audioServiceRef.current.init();
                setAudioStatus('ready');
            } catch (e) {
                console.error("Failed to start AudioService:", e);
                setAudioStatus('error');
                addLog('error', 'Could not initialize audio. Please allow audio in your browser.');
            }
        };
        initAudio();
        return () => { audioServiceRef.current?.cleanup(); };
    }, [audioStatus, addLog]);

    const handleGenerate = useCallback(async () => {
        if (audioStatus !== 'ready') { addLog('error', 'Audio engine not ready.'); return; }
        setIsGenerating(true);
        if (isPlaying) {
            audioServiceRef.current?.stop();
            setIsPlaying(false);
        }
        addLog('info', `Generation started with seed: ${settings.seed}`);
        setGenerationStatus(availableCores.reduce((acc, core) => ({ ...acc, [core.id]: 'idle' }), {}));
        
        try {
            await new Promise(res => setTimeout(res, 10));
            const generator = new MusicGenerator(settings.seed);
            const producerSpec = PRODUCER_SPECS[settings.producer] || PRODUCER_SPECS['Default'];

            setGenerationStatus(s => ({ ...s, theme: 'processing' }));
            const bars = Math.ceil((settings.tempo / 60) * settings.duration / 4);
            const scale = NOTE_MAP[settings.key];
            setGenerationStatus(s => ({ ...s, theme: 'complete' }));

            setGenerationStatus(s => ({ ...s, harmony: 'processing' }));
            const harmony = generator.generateHarmony(scale, bars, settings.progression);
            const bass = generator.generateBass(harmony);
            setGenerationStatus(s => ({ ...s, harmony: 'complete' }));
            
            setGenerationStatus(s => ({ ...s, rhythm: 'processing' }));
            const rhythm = generator.generateRhythm(bars);
            setGenerationStatus(s => ({ ...s, rhythm: 'complete' }));

            setGenerationStatus(s => ({ ...s, melody: 'processing' }));
            const melody = generator.generateLeadMelody(scale, bars, harmony, settings.complexity);
            setGenerationStatus(s => ({ ...s, melody: 'complete' }));

            setGenerationStatus(s => ({ ...s, synthesis: 'processing' }));
            const finalComposition = {
                ...settings, bars, scale, harmony, bass, rhythm, melody,
                swing: producerSpec.rhythm.swing,
            };
            await audioServiceRef.current.schedule(finalComposition);
            setComposition(finalComposition);
            setGenerationStatus(s => ({ ...s, synthesis: 'complete' }));
            addLog('success', 'Generation complete.');
        } catch (e) {
            console.error("Generation failed:", e);
            addLog('error', `Generation failed: ${e.message}`);
            setGenerationStatus(prev => ({ ...prev, [Object.keys(prev).find(k => prev[k] === 'processing') || 'synthesis']: 'error' }));
        }
        setIsGenerating(false);
    }, [settings, audioStatus, isPlaying, addLog, availableCores]);

    const handlePlayToggle = () => {
        if (!composition || audioStatus !== 'ready') return;
        if (Tone.context.state !== 'running') {
            Tone.context.resume().then(handlePlayToggle);
            return;
        }
        if (isPlaying) {
            audioServiceRef.current?.stop();
            setIsPlaying(false);
        } else {
            audioServiceRef.current?.play();
            setIsPlaying(true);
        }
    };

    return (
        <div className="min-h-screen bg-slate-900 text-slate-100 font-sans p-4">
            <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1 bg-slate-800/50 rounded-lg p-6 space-y-4 border border-slate-700">
                    <h1 className="text-2xl font-bold text-purple-400">AI Music Studio v11</h1>
                    
                    {audioStatus === 'error' && (<div className="p-4 bg-red-800/50 border border-red-600 rounded text-red-200"><strong>Audio Error:</strong> Could not initialize. Please check permissions.</div>)}
                    {audioStatus === 'initializing' && (<div className="p-4 bg-blue-800/50 border border-blue-600 rounded text-blue-200"><strong>Audio Engine Loading...</strong> Please wait.</div>)}

                    <div><label className="text-sm">Genre</label><select value={settings.genre} onChange={e => setSettings(s => ({...s, genre: e.target.value}))} className="w-full bg-slate-700 p-2 rounded">{Object.keys(GENRE_SPECS).map(g => (<option key={g} value={g}>{g}</option>))}</select></div>
                    <div><label className="text-sm">Producer Style</label><select value={settings.producer} onChange={e => setSettings(s=>({...s, producer: e.target.value}))} className="w-full bg-slate-700 p-2 rounded">{Object.keys(PRODUCER_SPECS).map(p => (<option key={p} value={p}>{p}</option>))}</select></div>
                    <div><label className="text-sm">Key</label><select value={settings.key} onChange={e => setSettings(s => ({...s, key: e.target.value}))} className="w-full bg-slate-700 p-2 rounded">{Object.keys(NOTE_MAP).map(k => (<option key={k} value={k}>{k}</option>))}</select></div>
                    <div><label className="text-sm">Tempo: {settings.tempo} BPM</label><input type="range" min={GENRE_SPECS[settings.genre]?.bpm.min || 60} max={GENRE_SPECS[settings.genre]?.bpm.max || 180} value={settings.tempo} onChange={e => setSettings(s => ({...s, tempo: parseInt(e.target.value)}))} className="w-full" /></div>
                    <div><label className="text-sm">Seed</label><input type="text" value={settings.seed} onChange={e => setSettings(s => ({...s, seed: e.target.value}))} className="w-full bg-slate-700 p-2 rounded" /></div>
                </div>

                <div className="lg:col-span-2 bg-slate-800/50 rounded-lg p-6 space-y-4 border border-slate-700">
                     <div className="flex justify-between items-center"><h2 className="text-xl font-bold">Orchestrator</h2>
                        <div className="flex gap-2">
                             <button onClick={handleGenerate} disabled={isGenerating || audioStatus !== 'ready'} className="bg-purple-600 px-4 py-2 rounded hover:bg-purple-700 disabled:bg-slate-600">{isGenerating ? 'Generating...' : 'Generate'}</button>
                             <button onClick={handlePlayToggle} disabled={!composition || isGenerating} className="bg-green-600 px-4 py-2 rounded hover:bg-green-700 disabled:bg-slate-600">{isPlaying ? 'Stop' : 'Play'}</button>
                        </div>
                    </div>
                    <div className="flex items-center justify-center gap-4 p-4 bg-slate-900/50 rounded">
                        {availableCores.map((core) => <ChainNode key={core.id} core={core} status={generationStatus[core.id] || 'idle'} />)}
                    </div>
                    <div><h3 className="font-bold mb-2">Logs</h3><div className="h-48 overflow-y-auto bg-slate-900/50 rounded p-2" role="log">{logs.length > 0 ? logs.map((log, i) => <LogEntry key={i} log={log} />) : <div className="text-slate-500 text-sm p-2">Logs will appear here...</div>}</div></div>
                </div>
            </div>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
        </div>
    );
}