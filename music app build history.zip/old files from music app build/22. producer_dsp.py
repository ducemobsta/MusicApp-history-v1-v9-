import numpy as np
SR = 44100

def sine(freq: float, length: float, sr: int = SR) -> np.ndarray:
  t = np.linspace(0, length, int(sr * length), False)
  return np.sin(2 * np.pi * freq * t)

def env_adsr(length: float, attack: float, decay: float, sustain_level: float, release: float, sr: int = SR) -> np.ndarray:
  # ... (full ADSR envelope implementation)
  pass

def one_pole_lowpass(signal: np.ndarray, cutoff: float, sr: int = SR) -> np.ndarray:
  # ... (simple filter implementation)
  pass