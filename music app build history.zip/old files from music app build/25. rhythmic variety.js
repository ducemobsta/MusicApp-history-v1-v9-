// Add rhythmic variety
generateRhythm(bars, spec, structure, rhythmProfile, settings) {
  const patterns: any = { kick: [], snare: [], hihat: [], sample: [] };
  const beatsPerBar = 16;
  for (let b = 0; b < bars; b++) {
    const section = structure?.find((s: any) => b >= s.start && b < s.end);
    const sectionType = section?.type || 'verse';
    const energyMultiplier = settings.energyCurve[sectionType as keyof typeof settings.energyCurve] || 1.0;
    for (let i = 0; i < beatsPerBar; i++) {
      const time = `${b}:${Math.floor(i / 4)}:${i % 4}`;
      if (this.random() > settings.rhythmicDensity) continue;
      if (this.random() > energyMultiplier) continue;
      const humanize = (this.random() - 0.5) * rhythmProfile.humanization.timing;
      const velocity = (1 - rhythmProfile.humanization.velocity) + (this.random() * rhythmProfile.humanization.velocity);
      const kickIdx = i % spec.kickPattern.length;
      if (spec.kickPattern[kickIdx] && this.random() > 0.1) {
        patterns.kick.push({
          time,
          velocity: velocity * 0.9,
          humanize
        });
      }
      const snareIdx = i % spec.snarePattern.length;
      if (spec.snarePattern[snareIdx] && this.random() > 0.05) {
        patterns.snare.push({
          time,
          velocity: velocity * 0.8,
          humanize
        });
      }
      const hhChance = spec.hihatDensity === 'very-high' ? 0.9 :
        spec.hihatDensity === 'high' ? 0.7 :
        spec.hihatDensity === 'medium' ? 0.5 : 0.3;
      if (i % 2 === 0 || this.random() < hhChance * 0.6) {
        patterns.hihat.push({
          time,
          velocity: velocity * 0.4,
          roll: spec.hihatDensity.includes('high') && i % 4 === 3 && this.random() < 0.2,
          humanize: humanize * 0.5
        });
      }
      if (b % 4 === 0 && i === 0) {
        patterns.sample.push({ time, velocity: 0.7 });
      }
    }
  }
  return patterns;
}