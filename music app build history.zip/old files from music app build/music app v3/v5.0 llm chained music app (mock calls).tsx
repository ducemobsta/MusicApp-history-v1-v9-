import React, { useState, useCallback, useRef, useEffect } from 'react';
import * as Tone from 'tone';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
// Note: JSZip and saveAs would need to be installed in a real project
// import MidiWriter from 'midi-writer-js'; // Placeholder for MIDI export

// --- V5: CONSTANTS ---
// Data files (e.g., chordProgressions.js) are mocked here for a single-file example
// In a real app, these would be in separate files and imported.

const PRODUCER_PROGRESSIONS = {
    'J Dilla': [
        { id: 'jd1', name: 'Dilla Minor 9', roman: ['i', 'v', 'bVII', 'IV'] },
        { id: 'jd2', name: 'Dilla Soul', roman: ['vi', 'v', 'I', 'IV'] },
    ],
    'Pharrell': [
        { id: 'ph1', name: 'Pharrell Funk', roman: ['I', 'vi', 'IV', 'V'] },
    ],
    'Zaytoven': [
        { id: 'zay1', name: 'Zay Piano', roman: ['i', 'bVII', 'v', 'i'] },
    ],
    'Default': [
        { id: 'def1', name: 'Standard', roman: ['i', 'iv', 'v', 'i'] },
    ]
};

const GENRE_PROGRESSIONS = {
    'Lo-fi': [
        { id: 'lo1', name: 'Lo-fi Jazz', roman: ['I', 'IV', 'ii', 'v'] },
        { id: 'lo2', name: 'Lo-fi Chill', roman: ['i', 'bVII', 'bVI', 'v'] },
    ],
    'Trap': [
        { id: 'tr1', name: 'Dark Trap', roman: ['i', 'bII', 'v', 'i'] },
    ],
    'R&B': [
        { id: 'rb1', name: 'Modern R&B', roman: ['vi', 'IV', 'I', 'V'] },
    ],
    'Neo-Soul': [
        { id: 'ns1', name: 'Neo-Soul Vibe', roman: ['i7', 'IV9', 'v7', 'I7'] },
    ]
};


// INSTRUMENT PATCHES (from v4)
const INSTRUMENT_PATCHES = {
    'quik-pluck-lead': {
        type: 'MonoSynth',
        config: { oscillator: { type: 'sawtooth' }, envelope: { attack: 0.006, decay: 0.09, sustain: 0.15, release: 0.08 }, filter: { type: 'lowpass', frequency: 3200, Q: 0.8 }, filterEnvelope: { attack: 0.01, decay: 0.08, sustain: 0.2, release: 0.1, baseFrequency: 300, octaves: 2.5 }, volume: -6 }
    },
    'quik-moog-bass': {
        type: 'MonoSynth',
        config: { portamento: 0.08, oscillator: { type: 'sine' }, envelope: { attack: 0.01, decay: 0.22, sustain: 0.85, release: 0.25 }, filter: { type: 'lowpass', frequency: 220, Q: 1.2 }, filterEnvelope: { attack: 0.02, decay: 0.1, sustain: 1, baseFrequency: 200, octaves: 1 }, volume: -4 }
    },
    'quik-wah-keys': {
        type: 'MonoSynth',
        config: { oscillator: { type: 'square' }, envelope: { attack: 0.02, decay: 0.18, sustain: 0.6, release: 0.22 }, filter: { type: 'bandpass', frequency: 800, Q: 6 }, filterEnvelope: { attack: 0.1, decay: 0.2, sustain: 0.5, baseFrequency: 400, octaves: 3 }, volume: -7 }
    },
    'alicia-wurli': {
        type: 'PolySynth',
        config: { oscillator: { type: 'triangle' }, envelope: { attack: 0.008, decay: 0.6, sustain: 0.7, release: 0.9 }, filter: { type: 'lowpass', frequency: 6000, Q: 0.7 }, volume: -2 }
    },
    'alicia-breath-pad': {
        type: 'PolySynth',
        config: { oscillator: { type: 'sine' }, envelope: { attack: 0.4, decay: 0.8, sustain: 0.7, release: 1.8 }, filter: { type: 'lowpass', frequency: 2400, Q: 0.6 }, filterEnvelope: { attack: 0.2, decay: 0.6, sustain: 0.5, baseFrequency: 500, octaves: 2 }, volume: -9 }
    },
    'alicia-bass': {
        type: 'MonoSynth',
        config: { oscillator: { type: 'triangle' }, envelope: { attack: 0.02, decay: 0.6, sustain: 0.85, release: 0.5 }, filter: { type: 'lowpass', frequency: 250, Q: 1 }, volume: -4 }
    },
    'analog-brass': {
        type: 'PolySynth',
        config: { oscillator: { type: 'sawtooth' }, envelope: { attack: 0.05, decay: 0.3, sustain: 0.6, release: 0.4 }, filter: { type: 'lowpass', frequency: 2800, Q: 1.5 }, volume: -8 }
    },
    'future-pluck': {
        type: 'MonoSynth',
        config: { oscillator: { type: 'triangle' }, envelope: { attack: 0.002, decay: 0.08, sustain: 0.1, release: 0.06 }, filter: { type: 'lowpass', frequency: 4000, Q: 2 }, volume: -10 },
    },
    '808-glide': {
        type: 'MonoSynth',
        config: { portamento: 0.05, oscillator: { type: 'sine' }, envelope: { attack: 0.001, decay: 0.4, sustain: 0, release: 0.2 }, filter: { type: 'lowpass', frequency: 150, Q: 2 }, volume: -2 }
    }
};

// PRODUCER SPECS (from v4)
const PRODUCER_SPECS = {
    'Pharrell': {
        effects: { saturation: 0.2, reverb: { mix: 0.3, decay: 1.2 } },
        rhythm: { swing: 0.4, humanization: { timing: 0.02, velocity: 0.1 } },
        signature: 'Minimalist funk, metallic drums',
        patches: { lead: ['future-pluck'], bass: ['quik-moog-bass'], pad: ['alicia-breath-pad'] }
    },
    'Timbaland': {
        effects: { saturation: 0.6, reverb: { mix: 0.25, decay: 0.8 } },
        rhythm: { swing: 0.7, humanization: { timing: 0.06, velocity: 0.3 } },
        signature: 'Stuttering rhythms, vocal chops',
        patches: { lead: ['quik-pluck-lead'], bass: ['808-glide'], pad: ['alicia-breath-pad'] }
    },
    'Zaytoven': {
        effects: { saturation: 0.9, reverb: { mix: 0.4, decay: 1.5 } },
        rhythm: { swing: 0.2, humanization: { timing: 0.04, velocity: 0.2 } },
        signature: 'Piano melodies, aggressive 808s',
        patches: { lead: ['alicia-wurli'], bass: ['808-glide'], pad: ['analog-brass'] }
    },
    'Just Blaze': {
        effects: { saturation: 0.3, reverb: { mix: 0.5, decay: 2.5 } },
        rhythm: { swing: 0.5, humanization: { timing: 0.03, velocity: 0.15 } },
        signature: 'Soulful samples, orchestral hits',
        patches: { lead: ['analog-brass'], bass: ['alicia-bass'], pad: ['alicia-breath-pad', 'analog-brass'] }
    },
    'Missy Elliott': {
        effects: { saturation: 0.8, reverb: { mix: 0.35, decay: 1.0 } },
        rhythm: { swing: 0.8, humanization: { timing: 0.07, velocity: 0.35 } },
        signature: 'Experimental, layered',
        patches: { lead: ['future-pluck'], bass: ['808-glide'], pad: ['alicia-breath-pad'] }
    },
    'Dr. Dre': {
        effects: { saturation: 0.7, reverb: { mix: 0.4, decay: 2.0 } },
        rhythm: { swing: 0.5, humanization: { timing: 0.01, velocity: 0.05 } },
        signature: 'G-Funk, deep bass, synth strings',
        patches: { lead: ['quik-pluck-lead'], bass: ['quik-moog-bass'], pad: ['analog-brass'] }
    },
    'J Dilla': {
        effects: { saturation: 0.3, reverb: { mix: 0.3, decay: 0.8 } },
        rhythm: { swing: 0.6, humanization: { timing: 0.08, velocity: 0.25 } },
        signature: 'Off-kilter rhythms, jazz chords',
        patches: { lead: ['alicia-wurli'], bass: ['alicia-bass'], pad: ['alicia-breath-pad', 'analog-brass'] }
    },
    'Kanye West': {
        effects: { saturation: 0.5, reverb: { mix: 0.6, decay: 3.0 } },
        rhythm: { swing: 0.4, humanization: { timing: 0.02, velocity: 0.1 } },
        signature: 'Soul samples, orchestral swells',
        patches: { lead: ['analog-brass'], bass: ['alicia-bass'], pad: ['alicia-breath-pad'] }
    },
    'DJ Quik': {
        effects: { saturation: 0.4, reverb: { mix: 0.35, decay: 1.5 } },
        rhythm: { swing: 0.6, humanization: { timing: 0.05, velocity: 0.15 } },
        signature: 'West Coast G-Funk, smooth grooves',
        patches: { lead: ['quik-pluck-lead'], bass: ['quik-moog-bass'], pad: ['quik-wah-keys'] }
    },
    'No I.D.': {
        effects: { saturation: 0.3, reverb: { mix: 0.4, decay: 1.8 } },
        rhythm: { swing: 0.5, humanization: { timing: 0.04, velocity: 0.2 } },
        signature: 'Soulful sampling, warm tones',
        patches: { lead: ['alicia-wurli'], bass: ['alicia-bass'], pad: ['alicia-breath-pad'] }
    },
    'Default': {
        effects: { saturation: 0.4, reverb: { mix: 0.3, decay: 1.5 } },
        rhythm: { swing: 0.3, humanization: { timing: 0.01, velocity: 0.1 } },
        signature: 'Balanced, clean production',
        patches: { lead: ['future-pluck'], bass: ['quik-moog-bass'], pad: ['alicia-breath-pad'] }
    }
};

// GENRE SPECS (from v4)
const GENRE_SPECS = {
    'Trap': {
        bpm: { min: 130, max: 170, common: 140 },
        scales: ['A minor', 'C# minor', 'F minor'],
        description: 'Hard-hitting 808s, rapid hi-hats',
        kickPattern: [1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0],
        snarePattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
        hihatDensity: 'high',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    },
    'Trap-Soul': {
        bpm: { min: 60, max: 100, common: 80 },
        scales: ['A minor', 'D minor'],
        description: 'Emotional melodies, smooth 808s',
        kickPattern: [1, 0, 0, 0, 1, 0, 0, 0],
        snarePattern: [0, 0, 0, 0, 1, 0, 0, 0],
        hihatDensity: 'medium',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    },
    'R&B': {
        bpm: { min: 90, max: 120, common: 95 },
        scales: ['C major', 'G major'],
        description: 'Smooth grooves, extended chords',
        kickPattern: [1, 0, 0, 0, 1, 0, 0, 0],
        snarePattern: [0, 0, 1, 0, 0, 0, 1, 0],
        hihatDensity: 'medium',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    },
    'Soul': {
        bpm: { min: 90, max: 120, common: 95 },
        scales: ['C major', 'F major'],
        description: 'Gospel-inspired, warm',
        kickPattern: [1, 0, 0, 0, 1, 0, 0, 0],
        snarePattern: [0, 0, 1, 0, 0, 0, 1, 0],
        hihatDensity: 'low',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    },
    '90s Rap': {
        bpm: { min: 80, max: 110, common: 90 },
        scales: ['A minor', 'E minor'],
        description: 'Boom-bap drums, jazzy loops',
        kickPattern: [1, 0, 0, 0, 1, 0, 0, 0],
        snarePattern: [0, 0, 1, 0, 0, 0, 1, 0],
        hihatDensity: 'medium',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    },
    'Lo-fi': {
        bpm: { min: 80, max: 110, common: 85 },
        scales: ['C major', 'A minor'],
        description: 'Chill vibes, jazzy chords',
        kickPattern: [1, 0, 0, 0, 1, 0, 0, 0],
        snarePattern: [0, 0, 1, 0, 0, 0, 1, 0],
        hihatDensity: 'low',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    },
    'Drill': {
        bpm: { min: 135, max: 150, common: 142 },
        scales: ['C minor', 'F# minor'],
        description: 'Aggressive sliding hi-hats',
        kickPattern: [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0],
        snarePattern: [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
        hihatDensity: 'very-high',
        structure: { intro: 2, verse: 8, chorus: 8, bridge: 4, outro: 2 }
    },
    'G-Funk': {
        bpm: { min: 85, max: 100, common: 90 },
        scales: ['C minor', 'G minor'],
        description: 'West Coast funk, synth leads',
        kickPattern: [1, 0, 0, 0, 1, 0, 0, 0],
        snarePattern: [0, 0, 1, 0, 0, 0, 1, 0],
        hihatDensity: 'medium',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    },
    'Neo-Soul': {
        bpm: { min: 70, max: 90, common: 80 },
        scales: ['D minor', 'Eb major'],
        description: 'Jazz harmony, organic feel',
        kickPattern: [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0],
        snarePattern: [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
        hihatDensity: 'low',
        structure: { intro: 4, verse: 8, chorus: 8, bridge: 4, outro: 4 }
    }
};

// NOTE MAP (from v4)
const NOTE_MAP = {
    'C major': ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5'],
    'A minor': ['A3', 'B3', 'C4', 'D4', 'E4', 'F4', 'G4', 'A4'],
    'G major': ['G3', 'A3', 'B3', 'C4', 'D4', 'E4', 'F#4', 'G4'],
    'E minor': ['E3', 'F#3', 'G3', 'A3', 'B3', 'C4', 'D4', 'E4'],
    'F major': ['F3', 'G3', 'A3', 'Bb3', 'C4', 'D4', 'E4', 'F4'],
    'D minor': ['D3', 'E3', 'F3', 'G3', 'A3', 'Bb3', 'C4', 'D4'],
    'C# minor': ['C#3', 'D#3', 'E3', 'F#3', 'G#3', 'A3', 'B3', 'C#4'],
    'F minor': ['F3', 'G3', 'Ab3', 'Bb3', 'C4', 'Db4', 'Eb4', 'F4'],
    'F# minor': ['F#3', 'G#3', 'A3', 'B3', 'C#4', 'D4', 'E4', 'F#4'],
    'C minor': ['C3', 'D3', 'Eb3', 'F3', 'G3', 'Ab3', 'Bb3', 'C4'],
    'Eb major': ['Eb3', 'F3', 'G3', 'Ab3', 'Bb3', 'C4', 'D4', 'Eb4'],
    'G minor': ['G3', 'A3', 'Bb3', 'C4', 'D4', 'Eb4', 'F4', 'G4']
};

// ROMAN TO DEGREE (from v4)
const ROMAN_TO_DEGREE = {
    'i': 0, 'I': 0, 'ii': 1, 'II': 1, 'iii': 2, 'III': 2,
    'iv': 3, 'IV': 3, 'v': 4, 'V': 4, 'vi': 5, 'VI': 5,
    'vii': 6, 'VII': 6, 'bII': 1, 'bIII': 2, 'bVI': 5, 'bVII': 6 // Simplified for this context
};

// --- V5: TYPES ---
// Merged types from v4
type Genre = 'Trap' | 'Trap-Soul' | 'R&B' | 'Soul' | '90s Rap' | 'Lo-fi' | 'Drill' | 'G-Funk' | 'Neo-Soul';
type Producer = 'Pharrell' | 'Timbaland' | 'Zaytoven' | 'Just Blaze' | 'Missy Elliott' | 'Dr. Dre' | 'J Dilla' | 'Kanye West' | 'DJ Quik' | 'No I.D.' | 'Default';
type AgentStatus = 'idle' | 'processing' | 'complete' | 'error';
type SongStructure = 'intro' | 'verse' | 'chorus' | 'bridge' | 'outro';
type MelodicContour = 'arch' | 'rising' | 'falling' | 'random';
type GenerationMode = 'Procedural' | 'LLM';

interface GenerationSettings {
    genre: Genre;
    producer: Producer;
    producerB: Producer;
    producerMix: number;
    key: string;
    tempo: number;
    duration: number; // in seconds
    complexity: number;
    variation: number;
    useStructure: boolean;
    melodicContour: MelodicContour;
    rhythmicDensity: number;
    useProducerProgressions: boolean;
    energyCurve: { verse: number; chorus: number; bridge: number; };
    useLoFiVinyl: boolean;
    seed: string;
    reverbMix: number;
    saturation: number;
}

interface UploadedSample {
    name: string;
    type: 'wav' | 'midi' | 'ogg';
    buffer: AudioBuffer | null;
    url: string;
}

// V5: Core definition from multi_llm_music_studio
interface Core {
    id: string;
    name: string;
    description: string;
    icon: string;
    color: string;
    model: string;
    generationMode: GenerationMode;
}

// --- V5: PROCEDURAL ENGINE (from v4 MusicGenerator) ---

class MusicGenerator {
    private random: () => number;

    constructor(seed: string) {
        let h = 1779033703;
        for (let i = 0; i < seed.length; i++) {
            h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
            h = h << 13 | h >>> 19;
        }
        this.random = () => {
            h = Math.imul(h ^ h >>> 16, 2246822507);
            h = Math.imul(h ^ h >>> 13, 3266489909);
            return ((h ^= h >>> 16) >>> 0) / 4294967296;
        };
    }

    // Producer Blending
    blendProducers(pA: any, pB: any, mix: number) {
        if (!pB || mix === 0) return pA;
        if (mix === 1) return pB;
        const blend = (valA: number, valB: number) => valA * (1 - mix) + valB * mix;
        return {
            effects: {
                saturation: blend(pA.effects.saturation, pB.effects.saturation),
                reverb: {
                    mix: blend(pA.effects.reverb.mix, pB.effects.reverb.mix),
                    decay: blend(pA.effects.reverb.decay, pB.effects.reverb.decay)
                }
            },
            rhythm: {
                swing: blend(pA.rhythm.swing, pB.rhythm.swing),
                humanization: {
                    timing: blend(pA.rhythm.humanization.timing, pB.rhythm.humanization.timing),
                    velocity: blend(pA.rhythm.humanization.velocity, pB.rhythm.humanization.velocity),
                }
            },
            patches: mix < 0.5 ? pA.patches : pB.patches,
            signature: `${Math.round((1 - mix) * 100)}% ${pA.signature} + ${Math.round(mix * 100)}% ${pB.signature}`
        }
    }

    // Key Modulation
    modulateKey(originalKey: string, modulation: 'upPerfectFourth'): string {
        const scale = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
        const [note, quality] = originalKey.split(' ');
        const currentIdx = scale.indexOf(note.replace('b', '#')); // Normalize flats
        if (currentIdx === -1) return originalKey;
        let interval = 0;
        if (modulation === 'upPerfectFourth') interval = 5; // 5 semitones
        const newNote = scale[(currentIdx + interval) % 12];
        return `${newNote} ${quality}`;
    }

    // Structure Generation
    generateStructure(totalBars: number, template: any) {
        const sections: Array<{ type: SongStructure; start: number; end: number }> = [];
        let currentBar = 0;
        const order: SongStructure[] = ['intro', 'verse', 'chorus', 'verse', 'chorus', 'bridge', 'chorus', 'outro'];
        for (const sectionType of order) {
            if (currentBar >= totalBars) break;
            const length = template[sectionType] || 4;
            const end = Math.min(currentBar + length, totalBars);
            sections.push({ type: sectionType, start: currentBar, end });
            currentBar = end;
        }
        return sections;
    }

    // Rhythm Generation
    generateRhythm(bars: number, spec: any, structure: any, rhythmProfile: any, settings: GenerationSettings) {
        const patterns: any = { kick: [], snare: [], hihat: [], sample: [] };
        const beatsPerBar = 16;
        for (let b = 0; b < bars; b++) {
            const section = structure?.find((s: any) => b >= s.start && b < s.end);
            const sectionType = section?.type || 'verse';
            const energyMultiplier = settings.energyCurve[sectionType as keyof typeof settings.energyCurve] || 1.0;

            for (let i = 0; i < beatsPerBar; i++) {
                const time = `${b}:${Math.floor(i / 4)}:${i % 4}`;
                if (this.random() > settings.rhythmicDensity) continue;
                if (this.random() > energyMultiplier) continue;
                
                const humanize = (this.random() - 0.5) * rhythmProfile.humanization.timing;
                const velocity = (1 - rhythmProfile.humanization.velocity) + (this.random() * rhythmProfile.humanization.velocity);
                
                const kickIdx = i % spec.kickPattern.length;
                if (spec.kickPattern[kickIdx] && this.random() > 0.1) {
                    patterns.kick.push({ time, velocity: velocity * 0.9, humanize });
                }
                
                const snareIdx = i % spec.snarePattern.length;
                if (spec.snarePattern[snareIdx] && this.random() > 0.05) {
                    patterns.snare.push({ time, velocity: velocity * 0.8, humanize });
                }
                
                const hhChance = spec.hihatDensity === 'very-high' ? 0.9 :
                    spec.hihatDensity === 'high' ? 0.7 :
                    spec.hihatDensity === 'medium' ? 0.5 : 0.3;
                if (i % 2 === 0 || this.random() < hhChance * 0.6) {
                    patterns.hihat.push({
                        time,
                        velocity: velocity * 0.4,
                        roll: spec.hihatDensity.includes('high') && i % 4 === 3 && this.random() < 0.2,
                        humanize: humanize * 0.5
                    });
                }
                if (b % 4 === 0 && i === 0) {
                    patterns.sample.push({ time, velocity: 0.7 });
                }
            }
        }
        return patterns;
    }

    // Harmony Generation
    generateHarmony(scale: string[], bars: number, spec: any, structure: any, settings: GenerationSettings) {
        const chords = [];
        const getProgression = (isBridge = false) => {
            const producerProgs = (settings.useProducerProgressions && PRODUCER_PROGRESSIONS[settings.producer as keyof typeof PRODUCER_PROGRESSIONS]) || [];
            const genreProgs = GENRE_PROGRESSIONS[settings.genre as keyof typeof GENRE_PROGRESSIONS] || GENRE_PROGRESSIONS['R&B']; // Fallback
            const availableProgs = producerProgs.length > 0 ? producerProgs : genreProgs;
            if (availableProgs.length === 0) {
                return { id: 'default', roman: ['i', 'iv', 'v', 'i'], name: 'Default Fallback' };
            }
            return availableProgs[Math.floor(this.random() * availableProgs.length)];
        }

        const mainProgression = getProgression();
        let bridgeProgression = getProgression(true);
        while (bridgeProgression.id === mainProgression.id && (PRODUCER_PROGRESSIONS[settings.producer as keyof typeof PRODUCER_PROGRESSIONS] || []).length > 1) {
            bridgeProgression = getProgression(true);
        }

        let activeProgressionName = mainProgression.name;
        for (let bar = 0; bar < bars; bar++) {
            const section = structure?.find((s: any) => bar >= s.start && bar < s.end);
            const sectionType = section?.type || 'verse';
            const currentProg = sectionType === 'bridge' ? bridgeProgression : mainProgression;
            
            if (sectionType === 'bridge') activeProgressionName = bridgeProgression.name;
            else activeProgressionName = mainProgression.name;

            const progression = currentProg.roman;
            const progIndex = bar % progression.length;
            const numeral = progression[progIndex];
            const degree = ROMAN_TO_DEGREE[numeral.replace(/[^IVivb]/g, '')] || 0;
            
            const notes = [
                scale[degree % scale.length],
                scale[(degree + 2) % scale.length],
                scale[(degree + 4) % scale.length]
            ];
            if (settings.complexity > 0.4 || sectionType === 'chorus' || numeral.includes('7') || numeral.includes('9')) {
                notes.push(scale[(degree + 6) % scale.length]);
            }
            if (settings.complexity > 0.8 && (settings.genre === 'Neo-Soul' || settings.genre === 'R&B') || numeral.includes('9')) {
                const ninth = scale[(degree + 8) % scale.length];
                if (ninth) notes.push(ninth);
            }
            
            const duration = (sectionType === 'bridge' && this.random() < 0.3) ? '2m' : '1m';
            chords.push({ time: `${bar}:0:0`, notes, duration, section: sectionType, velocity: 0.7 });
        }
        return { harmony: chords, progressionName: activeProgressionName };
    }

    // Melody Generation
    generateMelody(scale: string[], bars: number, harmony: any[], structure: any, complexity: number, contour: MelodicContour) {
        const notes = [];
        let currentIdx = Math.floor(scale.length / 2);
        for (let b = 0; b < bars; b++) {
            const section = structure?.find((s: any) => b >= s.start && b < s.end);
            const sectionType = section?.type || 'verse';
            const currentChord = harmony.find(c => c.time === `${b}:0:0`);
            if (!currentChord) continue;
            
            const chordRoot = currentChord.notes[0].slice(0, -1);
            currentIdx = Math.max(0, scale.findIndex(n => n.startsWith(chordRoot)));
            
            const playChance = sectionType === 'intro' ? 0.4 :
                sectionType === 'outro' ? 0.3 :
                sectionType === 'chorus' ? 0.8 : 0.65;
            const subdivision = (sectionType === 'chorus' || complexity > 0.7) ? 8 : 4;

            for (let i = 0; i < subdivision; i++) {
                if (this.random() < playChance) {
                    let stepDirection = this.random() < 0.5 ? -1 : 1;
                    if (contour === 'rising') stepDirection = 1;
                    if (contour === 'falling') stepDirection = -1;
                    if (contour === 'arch') stepDirection = (i < subdivision / 2) ? 1 : -1;
                    
                    const stepSize = this.random() < 0.6 ? 1 : 2;
                    const step = stepDirection * stepSize;
                    currentIdx = (currentIdx + step + scale.length) % scale.length;
                    
                    const note = scale[currentIdx];
                    const duration = this.random() < 0.4 ? '8n' : '16n';
                    const velocity = (0.5 + this.random() * 0.3) * (sectionType === 'chorus' ? 1.2 : 1.0);
                    
                    notes.push({
                        time: `${b}:${Math.floor(i * 4 / subdivision)}:${Math.floor((i * 4 / subdivision % 1) * 4)}`,
                        note, duration, velocity, section: sectionType
                    });
                }
            }
        }
        return notes;
    }

    // Bass Generation
    generateBass(harmony: any[], structure: any, settings: GenerationSettings) {
        const bassline = [];
        for (let i = 0; i < harmony.length; i++) {
            const c = harmony[i];
            const rootNote = c.notes[0].slice(0, -1);
            const octave = c.section === 'bridge' ? '1' : '2';
            const velocity = c.section === 'chorus' ? 0.95 :
                c.section === 'intro' ? 0.6 : 0.85;
            
            let finalNote = `${rootNote}${octave}`;
            if (i > 0 && settings.complexity > 0.5) {
                const prevRoot = harmony[i - 1].notes[0].slice(0, -1);
                const fifth = c.notes.length > 2 ? c.notes[2].slice(0, -1) : null;
                if (fifth && Math.abs(Tone.Frequency(prevRoot + "2").toMidi() - Tone.Frequency(fifth + "1").toMidi()) <
                    Math.abs(Tone.Frequency(prevRoot + "2").toMidi() - Tone.Frequency(rootNote + "2").toMidi())) {
                    finalNote = `${fifth}${(parseInt(octave) - 1)}`;
                }
            }

            bassline.push({
                time: c.time,
                note: finalNote,
                duration: c.duration,
                velocity,
                section: c.section
            });

            if (settings.genre === 'Drill' && this.random() < 0.4) {
                const nextNote = harmony[i + 1]?.notes[0].slice(0, -1);
                if (nextNote) {
                    const slideStartTime = Tone.Time(c.time).toSeconds() + Tone.Time('8n').toSeconds();
                    bassline.push({
                        time: slideStartTime,
                        note: `${nextNote}${octave}`,
                        duration: '16n',
                        velocity: velocity * 0.8
                    });
                }
            }
        }
        return bassline;
    }
}

// --- V5: AUDIO ENGINE (from v4 AudioService) ---

class AudioService {
    private synths: any = {};
    private parts: any[] = [];
    private players: Tone.Player[] = [];
    private analyser: Tone.Analyser | null = null;
    private reverb: Tone.Reverb | null = null;
    private distortion: Tone.Distortion | null = null;
    private vinylPlayer: Tone.Player | null = null;
    private recorder: Tone.Recorder | null = null;
    private isInit = false;

    async init() {
        if (!this.isInit) {
            await Tone.start();
            this.isInit = true;
        }
    }

    createSynth(patchName: string, masterChain: any) {
        const patch = INSTRUMENT_PATCHES[patchName];
        if (!patch) return null;
        if (patch.type === 'MonoSynth') {
            return new Tone.MonoSynth(patch.config).connect(masterChain);
        } else if (patch.type === 'PolySynth') {
            return new Tone.PolySynth(Tone.Synth, patch.config).connect(masterChain);
        }
        return null;
    }

    setReverbMix(wet: number) { if (this.reverb) this.reverb.wet.value = wet; }
    setSaturation(amount: number) { if (this.distortion) this.distortion.distortion = amount; }

    toggleVinyl(active: boolean, url: string = 'https://placehold.co/10x10/000000/000000?text=.') {
        // Using a placeholder URL as vinyl crackle isn't available
        // In a real app, this would be a URL to a looping vinyl crackle sound
        if (active && !this.vinylPlayer) {
            console.warn("Vinyl player activated with placeholder audio.");
            this.vinylPlayer = new Tone.Player(url).toDestination();
            this.vinylPlayer.loop = true;
            this.vinylPlayer.volume.value = -24;
            this.vinylPlayer.autostart = true;
        } else if (!active && this.vinylPlayer) {
            this.vinylPlayer.stop();
            this.vinylPlayer.dispose();
            this.vinylPlayer = null;
        }
    }

    async schedule(comp: any) {
        await this.init();
        this.stop();
        this.cleanup();

        const producer = comp.mixParams;
        this.reverb = new Tone.Reverb({
            decay: producer.reverb.decay,
            wet: producer.reverb.mix
        });
        await this.reverb.generate();

        this.distortion = new Tone.Distortion(producer.saturation);
        this.recorder = new Tone.Recorder();

        const masterChain = new Tone.Gain(0.7)
            .connect(this.distortion)
            .connect(this.reverb)
            .connect(this.recorder)
            .toDestination();

        this.synths.kick = new Tone.MembraneSynth({
            volume: -6,
            envelope: { attack: 0.001, decay: 0.4, sustain: 0, release: 0.1 }
        }).connect(masterChain);
        this.synths.snare = new Tone.NoiseSynth({
            volume: -10,
            noise: { type: 'white' },
            envelope: { attack: 0.001, decay: 0.15, sustain: 0, release: 0.05 }
        }).connect(masterChain);
        this.synths.hihat = new Tone.MetalSynth({
            volume: -18,
            envelope: { attack: 0.001, decay: 0.05, release: 0.03 }
        }).connect(masterChain);

        const createSynthLayer = (patchNames: string[], masterChain: any) => {
            const synths = patchNames.map(p => this.createSynth(p, masterChain)).filter(Boolean);
            return (notes: any, duration: any, time: any, velocity: number = 1) => {
                synths.forEach(synth => {
                    if (Math.random() > 0.3) {
                        synth.triggerAttackRelease(notes, duration, time, velocity * (0.8 + Math.random() * 0.2));
                    }
                });
            };
        };

        this.synths.melody = createSynthLayer(comp.patches.lead, masterChain);
        this.synths.chords = createSynthLayer(comp.patches.pad, masterChain);
        this.synths.bass = createSynthLayer(comp.patches.bass, masterChain);

        if (comp.samples && comp.samples.length > 0) {
            for (const sample of comp.samples) {
                if (sample.buffer && (sample.type === 'wav' || sample.type === 'ogg')) {
                    const player = new Tone.Player(sample.buffer).connect(masterChain);
                    player.volume.value = -12;
                    this.players.push(player);
                }
            }
        }

        if (!this.analyser) {
            this.analyser = new Tone.Analyser('waveform', 1024);
            Tone.getDestination().connect(this.analyser);
        }

        this.parts.push(new Tone.Part((time, e) => {
            const adjustedTime = e.humanize ? time + e.humanize : time;
            this.synths.kick.triggerAttackRelease('C1', '8n', adjustedTime, e.velocity);
        }, comp.rhythm.kick).start(0));
        this.parts.push(new Tone.Part((time, e) => {
            const adjustedTime = e.humanize ? time + e.humanize : time;
            this.synths.snare.triggerAttackRelease('8n', adjustedTime, e.velocity);
        }, comp.rhythm.snare).start(0));
        this.parts.push(new Tone.Part((time, e) => {
            const adjustedTime = e.humanize ? time + e.humanize : time;
            if (e.roll) {
                for (let i = 0; i < 4; i++) {
                    this.synths.hihat.triggerAttackRelease('32n', adjustedTime + (i * 0.03), e.velocity * 0.7);
                }
            } else {
                this.synths.hihat.triggerAttackRelease('32n', adjustedTime, e.velocity);
            }
        }, comp.rhythm.hihat).start(0));
        this.parts.push(new Tone.Part((time, c) => {
            this.synths.chords(c.notes, c.duration, time, c.velocity);
        }, comp.harmony).start(0));
        this.parts.push(new Tone.Part((time, n) => {
            this.synths.bass(n.note, n.duration, time, n.velocity);
        }, comp.bass).start(0));
        this.parts.push(new Tone.Part((time, n) => {
            this.synths.melody(n.note, n.duration, time, n.velocity);
        }, comp.melody).start(0));
        if (this.players.length > 0 && comp.rhythm.sample) {
            this.parts.push(new Tone.Part((time, e) => {
                const player = this.players[Math.floor(Math.random() * this.players.length)];
                if (player) player.start(time);
            }, comp.rhythm.sample).start(0));
        }

        Tone.Transport.bpm.value = comp.tempo;
        Tone.Transport.swing = producer.swing;
        Tone.Transport.swingSubdivision = '8n';
        Tone.Transport.loop = true;
        Tone.Transport.loopEnd = `${comp.bars}m`;
    }

    async exportStems(composition: any): Promise<Record<string, Blob>> {
        const stems: Record<string, Blob> = {};
        const duration = composition.duration;

        const renderStem = async (part: string, synths: string[], partData: any[]) => {
            const buffer = await Tone.Offline(async (transport) => {
                const gain = new Tone.Gain().toDestination();
                const synthInstances = synths.map(patch => this.createSynth(patch, gain)).filter(Boolean);
                new Tone.Part((time, event) => {
                    synthInstances.forEach(synth => {
                        if (!synth) return;
                        const notes = event.notes || event.note;
                        const velocity = event.velocity || 0.7;
                        synth.triggerAttackRelease(notes, event.duration, time, velocity);
                    });
                }, partData).start(0);
                transport.Transport.bpm.value = composition.tempo;
                transport.Transport.start();
            }, duration);
            return new Blob([buffer.get().buffer], { type: 'audio/wav' }); // Simplified blob creation
        };

        const renderDrums = async () => {
            const buffer = await Tone.Offline(async (transport) => {
                const gain = new Tone.Gain().toDestination();
                const kick = new Tone.MembraneSynth().connect(gain);
                const snare = new Tone.NoiseSynth().connect(gain);
                const hihat = new Tone.MetalSynth().connect(gain);
                new Tone.Part((time, e) => kick.triggerAttackRelease('C1', '8n', time, e.velocity),
                    composition.stems.drums.kick).start(0);
                new Tone.Part((time, e) => snare.triggerAttackRelease('8n', time, e.velocity),
                    composition.stems.drums.snare).start(0);
                new Tone.Part((time, e) => hihat.triggerAttackRelease('32n', time, e.velocity),
                    composition.stems.drums.hihat).start(0);
                transport.Transport.bpm.value = composition.tempo;
                transport.Transport.start();
            }, duration);
            return new Blob([buffer.get().buffer], { type: 'audio/wav' });
        }

        try {
            stems.melody = await renderStem('melody', composition.patches.lead, composition.stems.melody);
            stems.harmony = await renderStem('harmony', composition.patches.pad, composition.stems.harmony);
            stems.bass = await renderStem('bass', composition.patches.bass, composition.stems.bass);
            stems.drums = await renderDrums();
        } catch (e) {
            console.error("Error rendering stems:", e);
        }
        return stems;
    }

    async exportFullMix(composition: any): Promise<Blob> {
        const duration = composition.duration;
        const buffer = await Tone.Offline(async (transport) => {
            const producer = composition.mixParams;
            const reverb = new Tone.Reverb({
                decay: producer.reverb.decay,
                wet: producer.reverb.mix
            });
            await reverb.generate();
            const distortion = new Tone.Distortion(producer.saturation);
            const masterChain = new Tone.Gain(0.7)
                .connect(distortion)
                .connect(reverb)
                .toDestination(); // transport.destination

            const kick = new Tone.MembraneSynth().connect(masterChain);
            const snare = new Tone.NoiseSynth().connect(masterChain);
            const hihat = new Tone.MetalSynth().connect(masterChain);
            
            const createSynthLayer = (patchNames: string[], masterChain: any) => {
                const synths = patchNames.map(p => this.createSynth(p, masterChain)).filter(Boolean);
                return (notes: any, duration: any, time: any, velocity: number = 1) => {
                    synths.forEach(synth => synth.triggerAttackRelease(notes, duration, time, velocity));
                };
            };
            const melody = createSynthLayer(composition.patches.lead, masterChain);
            const chords = createSynthLayer(composition.patches.pad, masterChain);
            const bass = createSynthLayer(composition.patches.bass, masterChain);

            new Tone.Part((time, e) => kick.triggerAttackRelease('C1', '8n', time, e.velocity),
                composition.rhythm.kick).start(0);
            new Tone.Part((time, e) => snare.triggerAttackRelease('8n', time, e.velocity),
                composition.rhythm.snare).start(0);
            new Tone.Part((time, e) => hihat.triggerAttackRelease('32n', time, e.velocity),
                composition.rhythm.hihat).start(0);
            new Tone.Part((time, c) => chords(c.notes, c.duration, time, c.velocity),
                composition.harmony).start(0);
            new Tone.Part((time, n) => bass(n.note, n.duration, time, n.velocity),
                composition.bass).start(0);
            new Tone.Part((time, n) => melody(n.note, n.duration, time, n.velocity),
                composition.melody).start(0);

            transport.Transport.bpm.value = composition.tempo;
            transport.Transport.swing = producer.swing;
            transport.Transport.start();
        }, duration);
        return new Blob([buffer.get().buffer], { type: 'audio/wav' });
    }

    async startRecording() { if (this.recorder) this.recorder.start(); }
    async stopRecording(): Promise<Blob | null> {
        if (this.recorder) {
            const recording = await this.recorder.stop();
            return recording;
        }
        return null;
    }
    play() {
        Tone.Transport.start();
        this.startRecording();
    }
    stop() {
        Tone.Transport.stop();
        Tone.Transport.position = 0;
    }
    getAnalyser() { return this.analyser; }
    cleanup() {
        this.parts.forEach(p => p.dispose && p.dispose());
        this.parts = [];
        this.players.forEach(p => p.dispose());
        this.players = [];
        Object.values(this.synths).forEach((s: any) => s?.dispose && s.dispose());
        this.synths = {};
        Tone.Transport.cancel();
        this.reverb?.dispose();
        this.distortion?.dispose();
        this.vinylPlayer?.dispose();
        this.vinylPlayer = null;
    }
    dispose() {
        this.stop();
        this.cleanup();
        this.analyser?.dispose();
        this.recorder?.dispose();
    }
}

// --- V5: ORCHESTRATOR CORES (from musicPipeline.js) ---
// These Cores wrap the procedural logic from MusicGenerator

const ThemeDirectorCore = {
    run: (settings: GenerationSettings, generator: MusicGenerator) => {
        const spec = GENRE_SPECS[settings.genre];
        const producerA = PRODUCER_SPECS[settings.producer] || PRODUCER_SPECS['Default'];
        const producerB = PRODUCER_SPECS[settings.producerB] || PRODUCER_SPECS['Default'];
        const blendedProducer = generator.blendProducers(producerA, producerB, settings.producerMix);

        let currentKey = settings.key;
        if (settings.useStructure && settings.energyCurve.bridge > settings.energyCurve.verse * 1.1) {
            currentKey = generator.modulateKey(settings.key, 'upPerfectFourth');
        }

        const scale = NOTE_MAP[currentKey] || NOTE_MAP[settings.key];
        const bars = Math.ceil((settings.tempo / 60) * settings.duration / 4);

        const structure = settings.useStructure
            ? generator.generateStructure(bars, spec.structure)
            : null;

        return {
            settings,
            spec,
            blendedProducer,
            currentKey,
            scale,
            bars,
            structure
        };
    }
};

const HarmonyCore = {
    run: (plan: any, generator: MusicGenerator) => {
        const { harmony, progressionName } = generator.generateHarmony(
            plan.scale, plan.bars, plan.spec, plan.structure, plan.settings
        );
        return { harmony, progressionName };
    }
};

const RhythmCore = {
    run: (plan: any, generator: MusicGenerator) => {
        const rhythm = generator.generateRhythm(
            plan.bars, plan.spec, plan.structure, plan.blendedProducer.rhythm, plan.settings
        );
        return { rhythm };
    }
};

const MelodyCore = {
    run: (plan: any, generator: MusicGenerator, harmonyData: any) => {
        const melody = generator.generateMelody(
            plan.scale, plan.bars, harmonyData.harmony, plan.structure, plan.settings.complexity, plan.settings.melodicContour
        );
        const bass = generator.generateBass(
            harmonyData.harmony, plan.structure, plan.settings
        );
        return { melody, bass };
    }
};

const AudioSynthCore = {
    run: async (plan: any, audioService: AudioService, fullData: any) => {
        // Consolidate all data for the AudioService
        const composition = {
            rhythm: fullData.rhythm.rhythm,
            harmony: fullData.harmony.harmony,
            melody: fullData.melody.melody,
            bass: fullData.melody.bass,
            tempo: plan.settings.tempo,
            producer: plan.settings.producer,
            mixParams: plan.blendedProducer,
            patches: plan.blendedProducer.patches,
            bars: plan.bars,
            duration: plan.settings.duration,
            samples: fullData.samples, // Pass uploaded samples
            structure: plan.structure,
            stems: {
                melody: fullData.melody.melody,
                harmony: fullData.harmony.harmony,
                bass: fullData.melody.bass,
                drums: { 
                    kick: fullData.rhythm.rhythm.kick, 
                    snare: fullData.rhythm.rhythm.snare, 
                    hihat: fullData.rhythm.rhythm.hihat 
                }
            }
        };
        
        await audioService.schedule(composition);
        return { composition };
    }
};

// --- V5: UTILITY COMPONENTS ---

// Piano Roll Component (from v4)
const PianoRoll = ({ notes, bars, totalDuration }: { notes: any[], bars: number, totalDuration: number }) => {
    const PITCH_RANGE = ['C2', 'C#2', 'D2', 'D#2', 'E2', 'F2', 'F#2', 'G2', 'G#2', 'A2', 'A#2', 'B2', 'C3', 'C#3', 'D3', 'D#3', 'E3', 'F3', 'F#3', 'G3', 'G#3', 'A3', 'A#3', 'B3', 'C4', 'C#4', 'D4', 'D#4', 'E4', 'F4', 'F#4', 'G4', 'G#4', 'A4', 'A#4', 'B4', 'C5', 'C#5', 'D5', 'D#5', 'E5'];
    
    const noteToY = (note: string) => {
        const simpleNote = note.slice(0, -1);
        const octave = parseInt(note.slice(-1));
        const baseIndex = PITCH_RANGE.indexOf(`${simpleNote}${octave}`);
        if (baseIndex !== -1) return PITCH_RANGE.length - 1 - baseIndex;
        return PITCH_RANGE.length - 1 - PITCH_RANGE.indexOf(`${simpleNote}4`); // Fallback
    };

    return (
        <div className="piano-roll-container bg-gray-900 border border-gray-700 rounded-lg overflow-hidden" style={{ position: 'relative', height: '200px', width: '100%' }}>
            {/* Grid lines */}
            {[...Array(bars)].map((_, i) => (
                <div key={`bar-${i}`} style={{ position: 'absolute', left: `${(i / bars) * 100}%`, width: '1px', height: '100%', background: '#444' }} />
            ))}
            {PITCH_RANGE.map((note, i) => (
                <div key={`key-${i}`} style={{ position: 'absolute', top: `${(i / PITCH_RANGE.length) * 100}%`, width: '100%', height: `${100 / PITCH_RANGE.length}%`, background: note.includes('#') ? 'transparent' : 'rgba(0,0,0,0.1)' }} />
            ))}
            {/* Notes */}
            {notes.map((note, i) => {
                const time = Tone.Time(note.time).toSeconds();
                const duration = Tone.Time(note.duration).toSeconds();
                const x = (time / totalDuration) * 100;
                const yPercent = (noteToY(note.note) / PITCH_RANGE.length) * 100;
                const width = (duration / totalDuration) * 100;
                if (yPercent < 0 || yPercent > 100 || x < 0) return null; // Skip invalid notes
                return (
                    <div key={i} title={`${note.note} @ ${note.time}`} style={{
                        position: 'absolute',
                        left: `${x}%`,
                        top: `${yPercent}%`,
                        width: `${width}%`,
                        height: `${100 / PITCH_RANGE.length}%`,
                        background: `rgba(139, 92, 246, ${note.velocity * 0.8 + 0.2})`, // purple-500
                        borderRadius: '2px',
                        border: '1px solid rgba(255,255,255,0.3)'
                    }} />
                );
            })}
        </div>
    );
};

// Log Entry Component (from multi_llm_music_studio)
const LogEntry = ({ log }) => {
    const colors = {
        info: 'text-blue-400 border-blue-500 bg-blue-900/20',
        success: 'text-green-400 border-green-500 bg-green-900/20',
        warning: 'text-yellow-400 border-yellow-500 bg-yellow-900/20',
        error: 'text-red-400 border-red-500 bg-red-900/20',
    };
    const icons = {
        info: 'fas fa-info-circle',
        success: 'fas fa-check-circle',
        warning: 'fas fa-exclamation-triangle',
        error: 'fas fa-times-circle',
    };
    return (
        <div className={`log-entry p-2 px-3 mb-2 rounded border-l-4 font-mono text-sm ${colors[log.type]}`}>
            <span className="mr-2"><i className={icons[log.type]}></i></span>
            <span className="mr-3 text-gray-500">[{log.timestamp}]</span>
            <span>{log.message}</span>
        </div>
    );
};

// Tab Button Component
const TabButton = ({ id, activeTab, onClick, icon, label }) => (
    <button
        onClick={() => onClick(id)}
        className={`tab-button flex items-center gap-2 px-4 py-3 font-semibold rounded-lg transition-all ${
            activeTab === id
                ? 'bg-purple-600/30 text-purple-300'
                : 'text-gray-400 hover:bg-white/10'
        }`}
    >
        <i className={icon}></i>
        <span className="hidden md:inline">{label}</span>
    </button>
);

// Core Card Component (for Chain Builder)
const CoreCard = ({ core, onClick, isChained }) => (
    <div
        onClick={onClick}
        className={`core-card glass rounded-lg p-4 border-l-4 border-purple-500 cursor-pointer transition-all ${
            isChained ? 'bg-purple-900/50 opacity-60' : 'hover:bg-white/10 hover:shadow-lg'
        }`}
    >
        <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                <i className={`${core.icon} text-purple-400`}></i>
            </div>
            <div className="flex-1 min-w-0">
                <h3 className="font-bold text-sm mb-1">{core.name}</h3>
                <p className="text-xs text-gray-400 leading-tight">{core.description}</p>
                <div className="mt-2 text-xs text-purple-300">{core.model}</div>
            </div>
        </div>
    </div>
);

// Chain Node Component (for Chain Builder)
const ChainNode = ({ core, status }) => {
    const statusClasses = {
        idle: 'bg-white/5 border-white/30',
        processing: 'bg-blue-500/20 border-blue-400 animate-pulse',
        complete: 'bg-green-500/20 border-green-400',
        error: 'bg-red-500/20 border-red-400',
    };
    return (
        <div className="chain-node min-w-[140px] text-center">
            <div className={`chain-node-icon w-16 h-16 rounded-full mx-auto mb-2 flex items-center justify-center text-2xl border-2 transition-all ${statusClasses[status]}`}>
                <i className={core.icon}></i>
            </div>
            <div className="text-sm font-medium">{core.name}</div>
            <div className="text-xs text-gray-400">{core.model}</div>
        </div>
    );
};

// --- V5: MAIN APP COMPONENT ---
// Merges UI from multi_llm_music_studio and Logic from v4

export default function App() {
    // --- State ---
    const [settings, setSettings] = useState<GenerationSettings>({
        genre: 'Lo-fi',
        producer: 'J Dilla',
        producerB: 'Default',
        producerMix: 0,
        key: 'A minor',
        tempo: 85,
        duration: 32, // Shorter duration (in seconds) for quicker generation
        complexity: 0.7,
        variation: 0.5,
        useStructure: true,
        melodicContour: 'arch',
        rhythmicDensity: 1.0,
        useProducerProgressions: true,
        energyCurve: { verse: 0.8, chorus: 1.0, bridge: 0.7 },
        useLoFiVinyl: true,
        seed: '1337',
        reverbMix: PRODUCER_SPECS['J Dilla'].effects.reverb.mix,
        saturation: PRODUCER_SPECS['J Dilla'].effects.saturation
    });
    
    const [activeTab, setActiveTab] = useState('builder');
    const [logs, setLogs] = useState([]);
    
    const [availableCores, setAvailableCores] = useState<Core[]>([
        { id: 'theme', name: 'Theme Director', description: 'Establishes mood, structure, and producer blend', icon: 'fas fa-layer-group', color: 'purple', model: 'gemini-flash', generationMode: 'Procedural' },
        { id: 'harmony', name: 'Harmony Core', description: 'Builds chord progressions from theme', icon: 'fas fa-wave-square', color: 'indigo', model: 'gemini-flash', generationMode: 'Procedural' },
        { id: 'rhythm', name: 'Rhythm Architect', description: 'Designs drum patterns and percussion', icon: 'fas fa-drum', color: 'green', model: 'gemini-flash', generationMode: 'Procedural' },
        { id: 'melody', name: 'Melody & Bass', description: 'Composes melodic elements and basslines', icon: 'fas fa-music', color: 'yellow', model: 'gemini-pro', generationMode: 'Procedural' },
        { id: 'synthesis', name: 'Audio Synthesizer', description: 'Renders all elements into audio', icon: 'fas fa-sliders-h', color: 'cyan', model: 'tone.js', generationMode: 'Procedural' },
    ]);
    const [activeChain, setActiveChain] = useState<Core[]>([]);
    const [generationStatus, setGenerationStatus] = useState({});
    const [outputData, setOutputData] = useState({});

    const [isGenerating, setIsGenerating] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [composition, setComposition] = useState<any>(null);
    const [isExporting, setIsExporting] = useState(false);
    const [uploadedSamples, setUploadedSamples] = useState<UploadedSample[]>([]); // from v4

    // --- Refs ---
    const audioServiceRef = useRef<AudioService | null>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const animationFrameRef = useRef<number | null>(null);

    // --- Effects ---
    useEffect(() => {
        audioServiceRef.current = new AudioService();
        addLog('info', 'AI Music Studio v5 Initialized.');
        addLog('info', 'AudioService ready.');
        return () => {
            if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
            audioServiceRef.current?.dispose();
        };
    }, []);

    // Real-time control effects (from v4)
    useEffect(() => { audioServiceRef.current?.setReverbMix(settings.reverbMix); }, [settings.reverbMix]);
    useEffect(() => { audioServiceRef.current?.setSaturation(settings.saturation); }, [settings.saturation]);
    useEffect(() => { audioServiceRef.current?.toggleVinyl(settings.useLoFiVinyl); }, [settings.useLoFiVinyl]);

    // --- Log Helper ---
    const addLog = (type, message) => {
        setLogs(prev => [...prev, { type, message, timestamp: new Date().toLocaleTimeString() }]);
    };

    // --- Visualizer (from v4) ---
    const drawVisualizer = useCallback(() => {
        if (!canvasRef.current || !audioServiceRef.current || !isPlaying) return;
        const analyser = audioServiceRef.current.getAnalyser();
        if (!analyser) return;
        
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        const values = analyser.getValue() as Float32Array;
        ctx.fillStyle = 'rgba(15, 23, 42, 0.5)'; // bg-slate-900/50
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
        gradient.addColorStop(0, '#8b5cf6'); // purple-500
        gradient.addColorStop(0.5, '#ec4899'); // pink-500
        gradient.addColorStop(1, '#f59e0b'); // amber-500
        
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 3;
        ctx.beginPath();
        
        const sliceWidth = canvas.width / values.length;
        for (let i = 0; i < values.length; i++) {
            const v = (values[i] + 1) / 2;
            const y = v * canvas.height;
            const x = i * sliceWidth;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.stroke();
        animationFrameRef.current = requestAnimationFrame(drawVisualizer);
    }, [isPlaying]);

    // --- Chain & Generation Handlers ---

    const addCoreToChain = (coreId: string) => {
        if (isGenerating) {
            addLog('warning', 'Cannot modify chain while generation is in progress.');
            return;
        }
        const core = availableCores.find(c => c.id === coreId);
        if (core && !activeChain.find(c => c.id === coreId)) {
            setActiveChain(prev => [...prev, core]);
            addLog('info', `Added ${core.name} to chain.`);
        }
    };

    const clearChain = () => {
        if (isGenerating) {
            addLog('warning', 'Cannot clear chain while generation is in progress.');
            return;
        }
        setActiveChain([]);
        setGenerationStatus({});
        setOutputData({});
        addLog('info', 'Chain cleared.');
    };

    const toggleCoreMode = (coreId: string) => {
        const updateCores = (cores: Core[]) => 
            cores.map(c => 
                c.id === coreId 
                ? { ...c, generationMode: c.generationMode === 'Procedural' ? 'LLM' : 'Procedural' } 
                : c
            );
        
        setAvailableCores(updateCores);
        setActiveChain(updateCores);
    };

    // Simulated LLM call
    const runLLMCore = async (core: Core, context: any) => {
        addLog('info', `Running ${core.name} via LLM (Simulated)...`);
        await new Promise(res => setTimeout(res, 1500 + Math.random() * 1000));
        
        // Return mock data based on core ID
        switch(core.id) {
            case 'theme': return { 
                plan: { ...context, mood: 'Dark, Atmospheric (LLM)', structure: 'LLM-defined structure' }, 
                message: 'LLM defined a dark, atmospheric theme.' 
            };
            case 'harmony': return { 
                harmony: { harmony: [{time: '0:0:0', notes: ['A3', 'C4', 'E4'], duration: '1m'}], progressionName: 'LLM Minor' }, 
                message: 'LLM generated a simple Am progression.'
            };
            case 'rhythm': return { 
                rhythm: { rhythm: { kick: [{time: '0:0:0'}], snare: [{time: '0:2:0'}], hihat: [] } }, 
                message: 'LLM created a basic kick/snare pattern.'
            };
            case 'melody': return { 
                melody: { melody: [{time: '0:0:0', note: 'A4', duration: '4n'}], bass: [{time: '0:0:0', note: 'A2', duration: '1m'}] }, 
                message: 'LLM generated a single-note melody.'
            };
            default: return { result: 'LLM Processed', message: 'LLM Core processed.' };
        }
    };

    // Main Generation Pipeline
    const handleGenerate = async () => {
        if (activeChain.length === 0) {
            addLog('error', 'Chain is empty. Please add Cores to the chain.');
            return;
        }

        setIsGenerating(true);
        setIsPlaying(false);
        audioServiceRef.current?.stop();
        
        addLog('info', '========== V5 CHAIN EXECUTION STARTED ==========');
        addLog('info', `Seed: ${settings.seed}`);
        
        setGenerationStatus(activeChain.reduce((acc, core) => ({ ...acc, [core.id]: 'idle' }), {}));
        setOutputData({});

        const generator = new MusicGenerator(settings.seed);
        let currentContext: any = { ...settings, samples: uploadedSamples };
        let fullData: any = { ...currentContext };
        let hasError = false;

        for (const core of activeChain) {
            setGenerationStatus(prev => ({ ...prev, [core.id]: 'processing' }));
            
            try {
                let result: any;
                let message: string;

                if (core.generationMode === 'LLM' && core.id !== 'synthesis') {
                    // --- LLM (Simulated) Path ---
                    const llmResult = await runLLMCore(core, currentContext);
                    result = llmResult[core.id] || llmResult; // Get the specific data block
                    message = llmResult.message || `${core.name} completed.`;
                    
                    // Note: In this simulation, LLM data doesn't properly chain.
                    // A real implementation would need complex data mapping.
                    // We'll merge the result, but rely on the 'Procedural' path for a working song.
                    currentContext = { ...currentContext, ...result };

                } else {
                    // --- Procedural Path ---
                    switch (core.id) {
                        case 'theme':
                            result = ThemeDirectorCore.run(settings, generator);
                            currentContext = result; // The plan is the new context
                            message = `Theme locked. Producer: ${result.blendedProducer.signature.substring(0, 40)}...`;
                            break;
                        case 'harmony':
                            result = HarmonyCore.run(currentContext, generator);
                            message = `Harmony generated: ${result.progressionName}`;
                            break;
                        case 'rhythm':
                            result = RhythmCore.run(currentContext, generator);
                            message = `Rhythm patterns created.`;
                            break;
                        case 'melody':
                            result = MelodyCore.run(currentContext, generator, fullData.harmony);
                            message = `Melody & Bass composed.`;
                            break;
                        case 'synthesis':
                            result = await AudioSynthCore.run(currentContext, audioServiceRef.current, fullData);
                            setComposition(result.composition);
                            message = `Audio synthesis complete. Ready for playback.`;
                            break;
                        default:
                            throw new Error(`Unknown procedural core: ${core.id}`);
                    }
                }
                
                fullData[core.id] = result; // Store result
                setOutputData(prev => ({...prev, [core.id]: result})); // For UI
                setGenerationStatus(prev => ({ ...prev, [core.id]: 'complete' }));
                addLog('success', `✓ ${core.name} (Mode: ${core.generationMode}): ${message}`);

            } catch (error) {
                console.error('Pipeline error at core:', core.id, error);
                addLog('error', `✗ ${core.name} failed: ${error.message}`);
                setGenerationStatus(prev => ({ ...prev, [core.id]: 'error' }));
                hasError = true;
                break; // Stop chain on error
            }
        }

        setIsGenerating(false);
        if (hasError) {
            addLog('error', '========== CHAIN EXECUTION FAILED ==========');
        } else {
            addLog('success', '========== VKAIN EXECUTION COMPLETE ==========');
            setActiveTab('output');
        }
    };

    // --- Audio Handlers (from v4) ---
    const handlePlay = () => {
        if (!composition) return;
        audioServiceRef.current?.play();
        setIsPlaying(true);
        requestAnimationFrame(drawVisualizer);
        addLog('info', 'Playback started.');
    };

    const handleStop = () => {
        audioServiceRef.current?.stop();
        setIsPlaying(false);
        if (animationFrameRef.current) {
            cancelAnimationFrame(animationFrameRef.current);
        }
        addLog('info', 'Playback stopped.');
    };

    const handleDownloadStems = async () => {
        if (!composition) return;
        setIsExporting(true);
        addLog('info', 'Exporting stems...');
        try {
            const stems = await audioServiceRef.current?.exportStems(composition);
            if (stems) {
                const zip = new JSZip();
                if (stems.melody) zip.file("melody.wav", stems.melody);
                if (stems.harmony) zip.file("harmony.wav", stems.harmony);
                if (stems.bass) zip.file("bass.wav", stems.bass);
                if (stems.drums) zip.file("drums.wav", stems.drums);
                
                const content = await zip.generateAsync({ type: "blob" });
                saveAs(content, `stems_${settings.seed}.zip`);
                addLog('success', 'Stems exported as ZIP.');
            }
        } catch (e) {
            console.error("Export failed:", e);
            addLog('error', `Stem export failed: ${e.message}`);
        }
        setIsExporting(false);
    };

    const handleExportHQ = async () => {
        if (!composition) return;
        setIsExporting(true);
        addLog('info', 'Exporting HQ mix...');
        try {
            const mixBlob = await audioServiceRef.current?.exportFullMix(composition);
            if (mixBlob) {
                saveAs(mixBlob, `master_${settings.seed}.wav`);
                addLog('success', 'HQ mix exported as WAV.');
            }
        } catch (e) {
            console.error("HQ Export failed:", e);
            addLog('error', `HQ mix export failed: ${e.message}`);
        }
        setIsExporting(false);
    };

    // --- Settings Handlers (from v4) ---
    const handleRemixSeed = () => {
        const newSeed = (parseInt(settings.seed, 36) + 1).toString(36);
        setSettings(s => ({ ...s, seed: newSeed }));
        addLog('info', `New seed set: ${newSeed}`);
    };

    const handleGenreChange = (genre: Genre) => {
        const spec = GENRE_SPECS[genre];
        setSettings(prev => ({
            ...prev,
            genre,
            tempo: spec.bpm.common,
            key: spec.scales[0]
        }));
    };

    // Helper for sliders
    const handleSettingChange = (field, value) => {
        setSettings(prev => ({ ...prev, [field]: value }));
    };

    const handleEnergyChange = (section, value) => {
        setSettings(prev => ({
            ...prev,
            energyCurve: { ...prev.energyCurve, [section]: parseFloat(value) }
        }));
    };

    // --- JSX Render ---
    return (
        <div 
            className="min-h-screen p-4 md:p-6" 
            style={{ 
                fontFamily: "'Inter', sans-serif",
                background: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #312e81 100%)', 
                color: '#f8fafc' 
            }}
        >
            {/* Header (from multi_llm_music_studio) */}
            <header className="max-w-7xl mx-auto mb-6">
                <div className="glass rounded-2xl p-4 md:p-6 border border-white/10 shadow-xl">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                        <div className="flex items-center gap-4">
                            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center shadow-lg">
                                <i className="fas fa-brain text-2xl text-white"></i>
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                                    AI Music Studio v5
                                </h1>
                                <p className="text-purple-200 text-sm">LLM Chained Orchestrator (Procedural Engine)</p>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={handleExportHQ} disabled={!composition || isExporting} className="px-4 py-2 glass rounded-lg flex items-center gap-2 hover:bg-white/20 transition disabled:opacity-50">
                                <i className="fas fa-download"></i> {isExporting ? 'Exporting...' : 'Export HQ'}
                            </button>
                             <button onClick={handleDownloadStems} disabled={!composition || isExporting} className="px-4 py-2 glass rounded-lg flex items-center gap-2 hover:bg-white/20 transition disabled:opacity-50">
                                <i className="fas fa-file-archive"></i> Stems
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <div className="max-w-7xl mx-auto">
                {/* Tabs (from multi_llm_music_studio) */}
                <div className="glass rounded-xl p-2 mb-6 flex gap-2 overflow-x-auto border border-white/10">
                    <TabButton id="builder" activeTab={activeTab} onClick={setActiveTab} icon="fas fa-cubes" label="Chain Builder" />
                    <TabButton id="production" activeTab={activeTab} onClick={setActiveTab} icon="fas fa-sliders-h" label="Production" />
                    <TabButton id="output" activeTab={activeTab} onClick={setActiveTab} icon="fas fa-music" label="Output & Player" />
                    <TabButton id="logs" activeTab={activeTab} onClick={setActiveTab} icon="fas fa-terminal" label="Logs" />
                </div>

                {/* --- Tab Content: Chain Builder --- */}
                <div id="tab-builder" className={activeTab === 'builder' ? '' : 'hidden'}>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Core Selection */}
                        <div className="lg:col-span-1">
                            <div className="glass rounded-xl p-6 mb-6 border border-white/10">
                                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                                    <i className="fas fa-layer-group"></i> Available Cores
                                </h2>
                                <div className="space-y-3">
                                    {availableCores.map(core => (
                                        <div key={core.id}>
                                            <CoreCard 
                                                core={core} 
                                                onClick={() => addCoreToChain(core.id)} 
                                                isChained={!!activeChain.find(c => c.id === core.id)}
                                            />
                                            {/* Generation Mode Toggle */}
                                            {core.id !== 'synthesis' && (
                                                <div className="flex justify-end items-center -mt-2 mr-2">
                                                     <label className="flex items-center cursor-pointer">
                                                        <span className={`text-xs mr-2 ${core.generationMode === 'Procedural' ? 'text-purple-300 font-bold' : 'text-gray-500'}`}>Proc</span>
                                                        <div className="relative" onClick={(e) => { e.stopPropagation(); toggleCoreMode(core.id); }}>
                                                            <div className="w-10 h-5 bg-gray-900/50 rounded-full shadow-inner border border-white/20"></div>
                                                            <div className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full transition-transform ${core.generationMode === 'Procedural' ? 'translate-x-0 bg-purple-400' : 'translate-x-5 bg-blue-400'}`}></div>
                                                        </div>
                                                        <span className={`text-xs ml-2 ${core.generationMode === 'LLM' ? 'text-blue-300 font-bold' : 'text-gray-500'}`}>LLM</span>
                                                    </label>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Chain & Generation */}
                        <div className="lg:col-span-2 space-y-6">
                            <div className="glass rounded-xl p-6 border border-white/10">
                                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                                    <i className="fas fa-project-diagram"></i> Active Generation Chain
                                </h2>
                                <div id="chainVisualization" className="flex items-center gap-4 p-4 overflow-x-auto">
                                    {activeChain.length === 0 ? (
                                        <div className="text-center py-12 w-full text-purple-300">
                                            <i className="fas fa-plus-circle text-5xl mb-4 opacity-50"></i>
                                            <p>Click Cores on the left to build your chain</p>
                                        </div>
                                    ) : (
                                        activeChain.map((core, index) => (
                                            <React.Fragment key={core.id}>
                                                <ChainNode core={core} status={generationStatus[core.id] || 'idle'} />
                                                {index < activeChain.length - 1 && (
                                                    <i className="chain-arrow fas fa-arrow-right text-2xl text-white/20 flex-shrink-0"></i>
                                                )}
                                            </React.Fragment>
                                        ))
                                    )}
                                </div>
                                <button onClick={clearChain} className="mt-4 px-4 py-2 bg-red-600/20 hover:bg-red-600/30 rounded-lg flex items-center gap-2 transition text-sm">
                                    <i className="fas fa-trash"></i> Clear Chain
                                </button>
                            </div>

                            <div className="glass rounded-xl p-6 border border-white/10">
                                <h2 className="text-xl font-bold mb-4">Run Orchestrator</h2>
                                <div>
                                    <label className="block text-sm font-medium mb-2 text-gray-300">Generation Seed</label>
                                    <div className="flex gap-2">
                                        <input
                                            type="text"
                                            value={settings.seed}
                                            onChange={e => handleSettingChange('seed', e.target.value)}
                                            placeholder="Leave empty for random"
                                            className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                        />
                                        <button onClick={handleRemixSeed} title="Remix Seed" className="p-3 bg-white/5 hover:bg-white/20 rounded-lg border border-white/20 text-xl">
                                            <i className="fas fa-dice"></i>
                                        </button>
                                    </div>
                                </div>
                                <button
                                    onClick={handleGenerate}
                                    disabled={isGenerating}
                                    className="w-full mt-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-lg px-6 py-4 font-bold text-lg transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    {isGenerating ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-play"></i>}
                                    {isGenerating ? 'Generating Chain...' : 'Generate Music'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                {/* --- Tab Content: Production Settings --- */}
                <div id="tab-production" className={activeTab === 'production' ? 'grid grid-cols-1 lg:grid-cols-2 gap-6' : 'hidden'}>
                    <div className="glass rounded-xl p-6 border border-white/10">
                        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                            <i className="fas fa-palette"></i> Core Vibe
                        </h2>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-2">Genre</label>
                                <select value={settings.genre} onChange={e => handleGenreChange(e.target.value as Genre)} className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    {Object.keys(GENRE_SPECS).map(g => (<option key={g} value={g}>{g}</option>))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">Producer A (Base)</label>
                                <select value={settings.producer} onChange={e => handleSettingChange('producer', e.target.value)} className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    {Object.keys(PRODUCER_SPECS).map(p => (<option key={p} value={p}>{p}</option>))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">Producer B (Blend)</label>
                                <select value={settings.producerB} onChange={e => handleSettingChange('producerB', e.target.value)} className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    {Object.keys(PRODUCER_SPECS).map(p => (<option key={p} value={p}>{p}</option>))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2 flex justify-between">
                                    <span>Producer Mix</span>
                                    <span className="text-purple-300 font-bold">{Math.round(settings.producerMix * 100)}% B</span>
                                </label>
                                <input type="range" min="0" max="1" step="0.01" value={settings.producerMix} onChange={e => handleSettingChange('producerMix', parseFloat(e.target.value))} className="w-full accent-purple-500" />
                            </div>
                        </div>
                    </div>
                    <div className="glass rounded-xl p-6 border border-white/10">
                        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                            <i className="fas fa-sliders-h"></i> Composition Parameters
                        </h2>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-2 flex justify-between">
                                    <span>Tempo (BPM)</span>
                                    <span className="text-purple-300 font-bold">{settings.tempo}</span>
                                </label>
                                <input type="range" min={GENRE_SPECS[settings.genre].bpm.min} max={GENRE_SPECS[settings.genre].bpm.max} value={settings.tempo} onChange={e => handleSettingChange('tempo', parseInt(e.target.value))} className="w-full accent-purple-500" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium mb-2">Musical Key</label>
                                <select value={settings.key} onChange={e => handleSettingChange('key', e.target.value)} className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    {Object.keys(NOTE_MAP).map(k => (<option key={k} value={k}>{k}</option>))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2">Melodic Contour</label>
                                <select value={settings.melodicContour} onChange={e => handleSettingChange('melodicContour', e.target.value)} className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    <option value="arch">Arch</option>
                                    <option value="rising">Rising</option>
                                    <option value="falling">Falling</option>
                                    <option value="random">Random</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-2 flex justify-between">
                                    <span>Complexity</span>
                                    <span className="text-purple-300 font-bold">{Math.round(settings.complexity * 100)}%</span>
                                </label>
                                <input type="range" min="0" max="1" step="0.1" value={settings.complexity} onChange={e => handleSettingChange('complexity', parseFloat(e.target.value))} className="w-full accent-purple-500" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium mb-2 flex justify-between">
                                    <span>Rhythmic Density</span>
                                    <span className="text-purple-300 font-bold">{Math.round(settings.rhythmicDensity * 100)}%</span>
                                </label>
                                <input type="range" min="0.5" max="1" step="0.05" value={settings.rhythmicDensity} onChange={e => handleSettingChange('rhythmicDensity', parseFloat(e.target.value))} className="w-full accent-purple-500" />
                            </div>
                        </div>
                    </div>
                    <div className="glass rounded-xl p-6 border border-white/10 lg:col-span-2">
                        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                            <i className="fas fa-fire"></i> Energy & FX
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <fieldset className="border border-white/20 rounded-lg p-3 h-full">
                                    <legend className="text-sm font-medium text-purple-300 px-1">Song Energy Curve</legend>
                                    <div className="space-y-3 pt-2">
                                        <div>
                                            <label className="block text-xs mb-1 flex justify-between"><span>Verse</span><span className="font-bold">{settings.energyCurve.verse * 100}%</span></label>
                                            <input type="range" min="0.5" max="1.2" step="0.1" value={settings.energyCurve.verse} onChange={e => handleEnergyChange('verse', e.target.value)} className="w-full accent-purple-500" />
                                        </div>
                                        <div>
                                            <label className="block text-xs mb-1 flex justify-between"><span>Chorus</span><span className="font-bold">{settings.energyCurve.chorus * 100}%</span></label>
                                            <input type="range" min="0.8" max="1.5" step="0.1" value={settings.energyCurve.chorus} onChange={e => handleEnergyChange('chorus', e.target.value)} className="w-full accent-purple-500" />
                                        </div>
                                         <div>
                                            <label className="block text-xs mb-1 flex justify-between"><span>Bridge</span><span className="font-bold">{settings.energyCurve.bridge * 100}%</span></label>
                                            <input type="range" min="0.5" max="1.2" step="0.1" value={settings.energyCurve.bridge} onChange={e => handleEnergyChange('bridge', e.target.value)} className="w-full accent-purple-500" />
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                            <div>
                                <fieldset className="border border-white/20 rounded-lg p-3 h-full">
                                    <legend className="text-sm font-medium text-purple-300 px-1">Master FX</legend>
                                    <div className="space-y-3 pt-2">
                                        <div>
                                            <label className="block text-xs mb-1 flex justify-between"><span>Reverb</span><span className="font-bold">{Math.round(settings.reverbMix * 100)}%</span></label>
                                            <input type="range" min="0" max="1" step="0.01" value={settings.reverbMix} onChange={e => handleSettingChange('reverbMix', parseFloat(e.target.value))} className="w-full accent-blue-500" />
                                        </div>
                                        <div>
                                            <label className="block text-xs mb-1 flex justify-between"><span>Saturation</span><span className="font-bold">{Math.round(settings.saturation * 100)}%</span></label>
                                            <input type="range" min="0" max="1" step="0.01" value={settings.saturation} onChange={e => handleSettingChange('saturation', parseFloat(e.target.value))} className="w-full accent-orange-500" />
                                        </div>
                                        <div className="flex items-center gap-3 pt-2">
                                            <input type="checkbox" id="lofi-vinyl" checked={settings.useLoFiVinyl} onChange={e => handleSettingChange('useLoFiVinyl', e.target.checked)} className="w-4 h-4 accent-pink-500" />
                                            <label htmlFor="lofi-vinyl" className="text-sm text-gray-300">Lo-fi Vinyl Crackle</label>
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                    </div>
                </div>

                {/* --- Tab Content: Output & Player --- */}
                <div id="tab-output" className={activeTab === 'output' ? 'grid grid-cols-1 lg:grid-cols-3 gap-6' : 'hidden'}>
                    <div className="lg:col-span-2 space-y-6">
                        <div className="glass rounded-xl p-6 border border-white/10">
                            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                                <i className="fas fa-play-circle"></i> Master Player
                            </h2>
                             <div className="flex items-center justify-center gap-6 mb-4">
                                {!isPlaying ? (
                                    <button onClick={handlePlay} disabled={!composition || isGenerating} className="text-6xl text-purple-400 hover:text-purple-300 transition disabled:opacity-50">
                                        <i className="fas fa-play-circle"></i>
                                    </button>
                                ) : (
                                    <button onClick={handleStop} className="text-6xl text-purple-400 hover:text-purple-300 transition">
                                        <i className="fas fa-stop-circle"></i>
                                    </button>
                                )}
                            </div>
                            <canvas ref={canvasRef} width="1024" height="100" className="w-full h-24 rounded-lg bg-slate-900/50 border border-white/10"></canvas>
                        </div>
                        
                        <div className="glass rounded-xl p-6 border border-white/10">
                            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                                <i className="fas fa-pen-nib"></i> Generated Melody
                            </h2>
                            {composition ? (
                                <PianoRoll notes={composition.stems.melody} bars={composition.bars} totalDuration={composition.duration} />
                            ) : (
                                <div className="h-[200px] flex items-center justify-center text-purple-300 opacity-50">
                                    <i className="fas fa-music text-3xl mr-3"></i>
                                    Generate a track to see the piano roll
                                </div>
                            )}
                        </div>
                    </div>
                    <div className="lg:col-span-1 glass rounded-xl p-6 border border-white/10">
                        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                            <i className="fas fa-cogs"></i> Chain Output
                        </h2>
                        <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                            {activeChain.length === 0 && (
                                <div className="text-center py-12 text-purple-300 opacity-50">
                                    <i className="fas fa-box-open text-4xl mb-3"></i>
                                    <p>Output from cores will appear here</p>
                                </div>
                            )}
                            {activeChain.map(core => (
                                <div key={core.id} className="output-card glass rounded-lg p-4 border-l-4 border-purple-500">
                                    <h3 className="font-bold text-purple-300 mb-2 flex items-center gap-2">
                                        <i className={core.icon}></i>
                                        {core.name}
                                        <span className="ml-auto text-xs px-2 py-0.5 rounded-full bg-purple-900/50">
                                            {generationStatus[core.id] || 'idle'}
                                        </span>
                                    </h3>
                                    {outputData[core.id] ? (
                                        <pre className="text-xs text-gray-400 overflow-auto max-h-40 bg-black/20 p-2 rounded">
                                            {JSON.stringify(outputData[core.id], null, 2)}
                                        </pre>
                                    ) : (
                                        <p className="text-xs text-gray-500 italic">Waiting to run...</p>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* --- Tab Content: Logs --- */}
                <div id="tab-logs" className={activeTab === 'logs' ? '' : 'hidden'}>
                    <div className="glass rounded-xl p-6 border border-white/10">
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-xl font-bold flex items-center gap-2">
                                <i className="fas fa-terminal"></i> System Logs
                            </h2>
                            <button onClick={() => setLogs([])} className="px-4 py-2 bg-red-600/20 hover:bg-red-600/30 rounded-lg flex items-center gap-2 transition text-sm">
                                <i className="fas fa-trash"></i> Clear Logs
                            </button>
                        </div>
                        <div id="logContainer" className="bg-black/30 rounded-lg p-4 h-96 overflow-y-auto">
                            {logs.length === 0 && (
                                 <div className="text-center py-12 text-gray-500">
                                    <i className="fas fa-scroll text-4xl mb-3"></i>
                                    <p>Logs will appear here</p>
                                </div>
                            )}
                            {logs.map((log, i) => (
                                <LogEntry key={i} log={log} />
                            ))}
                        </div>
                    </div>
                </div>

            </div>
            
            {/* FontAwesome Script */}
            <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js" async></script>
            <style jsx global>{`
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
                
                .glass {
                    background: rgba(255, 255, 255, 0.03);
                    backdrop-filter: blur(12px);
                    -webkit-backdrop-filter: blur(12px);
                }

                input[type="range"] {
                    -webkit-appearance: none;
                    width: 100%;
                    height: 6px;
                    border-radius: 3px;
                    background: rgba(255, 255, 255, 0.1);
                    outline: none;
                }

                input[type="range"]::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    width: 18px;
                    height: 18px;
                    border-radius: 50%;
                    cursor: pointer;
                    box-shadow: 0 2px 8px rgba(0,0,0, 0.5);
                }
                
                input[type="range"].accent-purple-500::-webkit-slider-thumb { background: #a855f7; }
                input[type="range"].accent-blue-500::-webkit-slider-thumb { background: #3b82f6; }
                input[type_="range"].accent-orange-500::-webkit-slider-thumb { background: #f97316; }

                input[type="range"]::-moz-range-thumb {
                    width: 18px;
                    height: 18px;
                    border-radius: 50%;
                    cursor: pointer;
                    box-shadow: 0 2px 8px rgba(0,0,0, 0.5);
                    border: none;
                }
                
                input[type="range"].accent-purple-500::-moz-range-thumb { background: #a855f7; }
                input[type="range"].accent-blue-500::-moz-range-thumb { background: #3b82f6; }
                input[type="range"].accent-orange-500::-moz-range-thumb { background: #f97316; }

                /* Custom scrollbar */
                ::-webkit-scrollbar {
                    width: 8px;
                    height: 8px;
                }
                ::-webkit-scrollbar-track {
                    background: rgba(0,0,0,0.2);
                    border-radius: 4px;
                }
                ::-webkit-scrollbar-thumb {
                    background: rgba(139, 92, 246, 0.5);
                    border-radius: 4px;
                }
                ::-webkit-scrollbar-thumb:hover {
                    background: rgba(139, 92, 246, 0.8);
                }
            `}</style>
        </div>
    );
}