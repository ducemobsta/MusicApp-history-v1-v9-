#include "PluginProcessor.h"
#include "PluginEditor.h" // We'll need this later for the UI

// ==============================================================================
// --- CONSTRUCTOR & DESTRUCTOR ---
// ==============================================================================

MusicGeneratorVSTAudioProcessor::MusicGeneratorVSTAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true).withOutput("Output", juce::AudioChannelSet::stereo(), true))
#endif
{
    // --- Set up the File Bridge directory and files ---
    bridgeDir = juce::File::getSpecialLocation(juce::File::userMusicDirectory).getChildFile("MusicAIBridge");
    
    if (!bridgeDir.exists())
    {
        auto result = bridgeDir.createDirectory();
        if (!result.wasOk()) {
            // Handle error: couldn't create directory
            juce::Logger::writeToLog("Could not create bridge directory: " + bridgeDir.getFullPathName());
        }
    }

    promptFile = bridgeDir.getChildFile("prompt.txt");
    responseFile = bridgeDir.getChildFile("response.json");
    statusFile = bridgeDir.getChildFile("status.txt");

    // Initialize status
    statusFile.replaceWithText("idle");
}

MusicGeneratorVSTAudioProcessor::~MusicGeneratorVSTAudioProcessor()
{
    stopTimer();
}

// ==============================================================================
// --- CORE GENERATION LOGIC ---
// ==============================================================================

void MusicGeneratorVSTAudioProcessor::startAIGeneration(const juce::String& promptText)
{
    if (isTimerRunning()) {
        if (onStatusChanged) onStatusChanged("Generation already in progress.", true);
        return;
    }

    // 1. Write the prompt to the designated file.
    //    The external Python script will be watching this file.
    if (promptFile.exists()) promptFile.deleteFile();
    promptFile.replaceWithText(promptText);

    // 2. Update status for user and external script
    statusFile.replaceWithText("waiting_for_ai");
    if (onStatusChanged) onStatusChanged("Waiting for AI response...", false);

    // 3. Start the timer to check for the response file every second.
    startTimerHz(1);
}

void MusicGeneratorVSTAudioProcessor::timerCallback()
{
    // This function is called once per second while the timer is running.

    // 1. Check if the response file exists and is newer than our prompt.
    if (responseFile.existsAsFile() && responseFile.getLastModificationTime() > promptFile.getLastModificationTime())
    {
        // 2. We have a response, so we can stop polling.
        stopTimer();

        // 3. Read the content and process it.
        juce::String jsonText = responseFile.loadFileAsString();
        processAIResponse(jsonText);
    }
}

void MusicGeneratorVSTAudioProcessor::processAIResponse(const juce::String& jsonText)
{
    // 1. Parse the text as JSON
    juce::var jsonResponse;
    juce::Result result = juce::JSON::parse(jsonText, jsonResponse);

    if (result.wasOk())
    {
        // 2. Extract the musical parameters from the JSON object.
        //    We use .getProperty() and provide a default value with .or() for safety.
        auto key = jsonResponse.getProperty("key", "A minor").toString().toStdString();
        auto tempo = (int)jsonResponse.getProperty("tempo", 120);
        
        std::vector<std::string> progression;
        if (auto* romanArray = jsonResponse.getProperty("roman", juce::var()).getArray())
        {
            for (const auto& numeral : *romanArray)
            {
                progression.push_back(numeral.toString().toStdString());
            }
        }
        
        // Use a default progression if none is provided
        if (progression.empty()) {
            progression = {"i", "v", "bVI", "bVII"};
        }

        // Generate a seed from the description or current time for randomness
        auto seed = jsonResponse.getProperty("description", "default seed").toString().toStdString()
                  + std::to_string(juce::Time::currentTimeMillis());

        // 3. Call the engine to generate the MIDI file.
        //    For this example, we generate an 8-bar loop.
        try {
            realEngine.generate(key, progression, tempo, 8, 0.7, 0.4, seed);
            
            // 4. Update status and notify the UI
            statusFile.replaceWithText("ready");
            if (onStatusChanged) onStatusChanged("Success! MIDI generated.", false);
            DBG("AI MIDI Generation successful. Key: " + key + ", Tempo: " + std::to_string(tempo));

        } catch (const std::exception& e) {
            statusFile.replaceWithText("error_generation_failed");
            if (onStatusChanged) onStatusChanged("Error during music generation: " + juce::String(e.what()), true);
        }
    }
    else
    {
        // JSON parsing failed.
        statusFile.replaceWithText("error_json_parse");
        if (onStatusChanged) onStatusChanged("Error: Could not parse AI response. Check JSON format.", true);
        DBG("JSON parsing failed: " + result.getErrorMessage());
    }
}


// ==============================================================================
// --- JUCE BOILERPLATE ---
// ==============================================================================

const juce::String MusicGeneratorVSTAudioProcessor::getName() const { return JucePlugin_Name; }
bool MusicGeneratorVSTAudioProcessor::acceptsMidi() const { return false; }
bool MusicGeneratorVSTAudioProcessor::producesMidi() const { return true; }
double MusicGeneratorVSTAudioProcessor::getTailLengthSeconds() const { return 0.0; }
int MusicGeneratorVSTAudioProcessor::getNumPrograms() { return 1; }
int MusicGeneratorVSTAudioProcessor::getCurrentProgram() { return 0; }
void MusicGeneratorVSTAudioProcessor::setCurrentProgram(int) {}
const juce::String MusicGeneratorVSTAudioProcessor::getProgramName(int) { return {}; }
void MusicGeneratorVSTAudioProcessor::changeProgramName(int, const juce::String&) {}
void MusicGeneratorVSTAudioProcessor::prepareToPlay(double, int) {}
void MusicGeneratorVSTAudioProcessor::releaseResources() {}

void MusicGeneratorVSTAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    // This plugin does not process audio, it only generates MIDI data.
    // So we just clear the audio buffer.
    buffer.clear();
}

bool MusicGeneratorVSTAudioProcessor::hasEditor() const { return true; }
juce::AudioProcessorEditor* MusicGeneratorVSTAudioProcessor::createEditor()
{
    // You would create your PluginEditor class here.
    return new juce::GenericAudioProcessorEditor(*this);
    // return new MusicGeneratorVSTAudioProcessorEditor(*this);
}

void MusicGeneratorVSTAudioProcessor::getStateInformation(juce::MemoryBlock& destData) {}
void MusicGeneratorVSTAudioProcessor::setStateInformation(const void* data, int sizeInBytes) {}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new MusicGeneratorVSTAudioProcessor();
}