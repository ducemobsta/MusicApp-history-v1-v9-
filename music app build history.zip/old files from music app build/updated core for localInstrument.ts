// In App.tsx

import TinySynth from 'webaudio-tinysynth'; // Import the new library

// Add a new state to hold your synth instance
const [localSynth, setLocalSynth] = useState<TinySynth | null>(null);

const handleSoundFontFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
        return;
    }

    addLog('info', `Loading local SoundFont: ${file.name}...`);
    const reader = new FileReader();

    reader.onload = (e) => {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        if (arrayBuffer) {
            // Initialize the synth
            const synth = new TinySynth();
            synth.loadSoundFont(arrayBuffer); // This is the key step!
            setLocalSynth(synth);
            
            // webaudio-tinysynth provides a list of presets (instruments)
            const instrumentNames = synth.getTimbreList().map(p => p.name);
            addLog('success', `SoundFont loaded! Available instruments: ${instrumentNames.slice(0, 5).join(', ')}...`);

            // Now, you would need to update your app's state to make
            // these instruments available for selection.
        }
    };
    
    reader.onerror = () => {
        addLog('error', 'Failed to read the .sf2 file.');
    };

    reader.readAsArrayBuffer(file);
};```

#### Step 4: Adapt the AudioService to Use the New Synth

`webaudio-tinysynth` has a different API for playing notes (`noteOn`, `noteOff`) compared to `soundfont-player`. You would need to adapt your `AudioService` or create a new playback path for it.

The `TinySynth` methods are more like traditional MIDI:

*   `synth.send([0x90, note, velocity])`: Note On on channel 0 (e.g., `note` = 60 for Middle C, `velocity` = 100).
*   `synth.send([0x80, note, 0])`: Note Off on channel 0.
*   `synth.setTimbre(channel, programNumber)`: Selects the instrument for a channel.

Your `AudioService.schedule` method would need a condition: if the selected instrument is from the local SoundFont, use the `localSynth` object to schedule notes; otherwise, use the `getInstrument` logic from v6.

**Example of a new play function for the local synth:**

```typescript
// A conceptual function showing how you'd play a note with TinySynth
async function playLocalNote(note: string, duration: number) {
    if (!localSynth) {
        console.error("Local synth not loaded!");
        return;
    }
    
    // TinySynth uses MIDI note numbers, not note names like "C4"
    const midiNote = Tone.Frequency(note).toMidi();
    const velocity = 100; // 0-127

    // 0x90 is Note On for channel 0
    localSynth.send([0x90, midiNote, velocity]);

    // Schedule the Note Off event
    setTimeout(() => {
        // 0x80 is Note Off for channel 0
        localSynth.send([0x80, midiNote, 0]);
    }, duration * 1000);
}