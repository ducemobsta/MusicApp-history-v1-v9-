// Inside the return() of your App component

return (
    <div>
        <h1>AI Music Generator</h1>
        <p>Sampler Status: {isSamplerReady ? 'Ready' : 'Loading...'}</p>
        
        {/* Add a UI element to switch producer profiles */}
        <select value={activeProducer} onChange={(e) => setActiveProducer(e.target.value)}>
            {Object.keys(producerPresets).map(name => <option key={name} value={name}>{name}</option>)}
        </select>

        <button onClick={generateAndPlaySequence} disabled={!isSamplerReady || isPlaying}>
            Generate and Play
        </button>
        <button onClick={stopSequence} disabled={!isPlaying}>
            Stop
        </button>

        {/* Add the mode toggle UI */}
        <button onClick={() => GenreSamplerAPI.setMode('lite')}>
            Set Lite Mode (Reload Required)
        </button>
        <button onClick={() => GenreSamplerAPI.setMode('full')}>
            Set Full Mode (Reload Required)
        </button>
    </div>
);