export const PRODUCER_PROGRESSIONS = {
  "Timbaland": [
    { id: "tim_1", name: "Dark syncopation (minor vamp)", roman: ["i", "bVI", "bIII", "bVII"] },
    { id: "tim_2", name: "Chromatic stutter", roman: ["i", "bII", "i", "v"] },
    // ... all other Timbaland progressions
  ],
  "DJ Quik": [
    { id: "quik_1", name: "G-Funk classic 1", roman: ["i", "bVII", "bVI", "V7"] },
    // ... all other DJ Quik progressions
  ],
  // ... all other producers (Zaytoven, Just Blaze, Missy Elliott, Dr. Dre, etc.)
};

export const GENRE_PROGRESSIONS = {
  "Trap": [
    { id: "trap_1", name: "Classic trap minor loop", roman: ["i", "bVI", "bIII", "bVII"] },
    // ... all other Trap progressions
  ],
  "Drill": [
    { id: "drill_1", name: "Dark slide vamp", roman: ["i", "bIII", "bVI", "bVII"] },
    // ... all other Drill progressions
  ],
  // ... all other genres (R&B, Soul, G-Funk, Lo-fi, etc.)
};