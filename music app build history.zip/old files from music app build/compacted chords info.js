// src/data/chordProgressions.js
// Quantized 4-bar chord progressions for producers & genres
// Default absolute mappings use C minor or C major depending on `key` field.

export const PRODUCER_PROGRESSIONS = {
  "Timbaland": [
    {
      id: "tim_1",
      name: "Dark syncopation (minor vamp)",
      key: "C minor",
      roman: ["i", "bVI", "bIII", "bVII"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Abmaj7", duration: "1m" },
        { time: "2:0:0", chord: "Ebmaj7", duration: "1m" },
        { time: "3:0:0", chord: "Bb7", duration: "1m" }
      ],
      notes: "Sparse pads, syncopated vocal chops – good for stuttered rhythms."
    },
    {
      id: "tim_2",
      name: "Chromatic stutter",
      key: "C minor",
      roman: ["i", "bII", "i", "v"],
      schedule: [
        { time: "0:0:0", chord: "Cm9", duration: "1m" },
        { time: "1:0:0", chord: "Dbmaj7(#11)", duration: "1m" },
        { time: "2:0:0", chord: "Cm9", duration: "1m" },
        { time: "3:0:0", chord: "Gm7", duration: "1m" }
      ],
      notes: "Use heavy rhythmic gating and vocal chops; tension on bar 2."
    },
    {
      id: "tim_3",
      name: "Modal vamp w/ suspension",
      key: "C minor",
      roman: ["i", "iv", "v", "i"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Fm7", duration: "1m" },
        { time: "2:0:0", chord: "Gm7", duration: "1m" },
        { time: "3:0:0", chord: "Cm7", duration: "1m" }
      ],
      notes: "Great for warm pads and percussive FM accents."
    },
    {
      id: "tim_4",
      name: "Vocal chop tonic ride",
      key: "A minor",
      roman: ["i", "VI", "III", "VII"],
      schedule: [
        { time: "0:0:0", chord: "Am7", duration: "1m" },
        { time: "1:0:0", chord: "Fmaj7", duration: "1m" },
        { time: "2:0:0", chord: "Cmaj7", duration: "1m" },
        { time: "3:0:0", chord: "G7", duration: "1m" }
      ],
      notes: "Useful when layering pitch-shifted vocal chops and syncopation."
    },
    {
      id: "tim_5",
      name: "Minor 7th pad loop",
      key: "C minor",
      roman: ["i", "iv", "bVII", "bIII"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Fm7", duration: "1m" },
        { time: "2:0:0", chord: "Bb7", duration: "1m" },
        { time: "3:0:0", chord: "Ebmaj7", duration: "1m" }
      ],
      notes: "Classic Timbaland-style dark bed; add vocal fx and percussive stabs."
    },
    {
      id: "tim_6",
      name: "Suspended drive",
      key: "C minor",
      roman: ["i", "ivsus2", "i", "v"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Fsus2", duration: "1m" },
        { time: "2:0:0", chord: "Cm7", duration: "1m" },
        { time: "3:0:0", chord: "Gm7", duration: "1m" }
      ],
      notes: "Use for sweeping filter automation and rhythmic delays."
    },
    {
      id: "tim_7",
      name: "Minor → major lift",
      key: "C minor",
      roman: ["i", "bVI", "bIII", "IV"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Abmaj7", duration: "1m" },
        { time: "2:0:0", chord: "Ebmaj7", duration: "1m" },
        { time: "3:0:0", chord: "Fmaj7", duration: "1m" }
      ],
      notes: "Great for builds – switch pads to brighter voicing on bar 4."
    },
    {
      id: "tim_8",
      name: "Tension-release loop",
      key: "C minor",
      roman: ["i", "v", "iv", "bVII"],
      schedule: [
        { time: "0:0:0", chord: "Cm9", duration: "1m" },
        { time: "1:0:0", chord: "Gm7", duration: "1m" },
        { time: "2:0:0", chord: "Fm7", duration: "1m" },
        { time: "3:0:0", chord: "Bb7", duration: "1m" }
      ],
      notes: "Use quick gated sounds during the tension bar."
    },
    {
      id: "tim_9",
      name: "Minor ladder (chromatic color)",
      key: "C minor",
      roman: ["i", "bIImaj7", "bIII", "bIII7"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Dbmaj7(#11)", duration: "1m" },
        { time: "2:0:0", chord: "Ebmaj7", duration: "1m" },
        { time: "3:0:0", chord: "Eb7", duration: "1m" }
      ],
      notes: "Dissonant charm – great for experimental Timbaland textures."
    },
    {
      id: "tim_10",
      name: "Sparse minor vamp w/ lift",
      key: "C minor",
      roman: ["i", "ivadd9", "i", "bVI"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Fm9", duration: "1m" },
        { time: "2:0:0", chord: "Cm7", duration: "1m" },
        { time: "3:0:0", chord: "Abmaj7", duration: "1m" }
      ],
      notes: "Minimalist arrangement; use rhythmic gating and micro-edits."
    }
  ],
  "DJ Quik": [
    {
      id: "quik_1",
      name: "G-Funk classic 1",
      key: "C minor",
      roman: ["i", "bVII", "bVI", "V7"],
      schedule: [
        { time: "0:0:0", chord: "Cm7", duration: "1m" },
        { time: "1:0:0", chord: "Bb7", duration: "1m" },
        { time: "2:0:0", chord: "Abmaj7", duration: "1m" },
        { time: "3:0:0", chord: "G7", duration: "1m" }
      ],
      notes: "Classic Quik / West Coast movement; wah-key comping fits well."
    },
    // ... all other producer progressions from the OCR ...
  ]
  // ... continue for all producers
};

export const GENRE_PROGRESSIONS = {
  "Trap": [
    {
      id: "trap_1",
      name: "Classic trap minor loop",
      key: "A minor",
      roman: ["i", "bVI", "bIII", "bVII"],
      schedule: [
        { time: "0:0:0", chord: "Am7", duration: "1m" },
        { time: "1:0:0", chord: "Fmaj7", duration: "1m" },
        { time: "2:0:0", chord: "Cmaj7", duration: "1m" },
        { time: "3:0:0", chord: "G7", duration: "1m" }
      ],
      notes: "808s and sparse hi-hats; pitch slides on 808s recommended."
    },
    // ... all other genre progressions from the OCR ...
  ],
  // ... continue for all genres
};