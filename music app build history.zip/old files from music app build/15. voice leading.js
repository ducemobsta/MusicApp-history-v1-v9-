// Basic voice leading rules
const applyVoiceLeading = (chords) => {
  for (let i = 1; i < chords.length; i++) {
    const prevChord = chords[i - 1].notes;
    const currentChord = chords[i].notes;
    currentChord.forEach((note, index) => {
      const prevNote = prevChord[index];
      const interval = Math.abs(Tone.Frequency(note).toMidi() - Tone.Frequency(prevNote).toMidi());
      if (interval > 7) { // Avoid large leaps
        currentChord[index] = prevNote;
      }
    });
  }
  return chords;
};

// Generate Harmony with voice leading
generateHarmony(scale, bars, spec, structure, settings) {
  const chords = [];
  // ... (existing code for generating chords)
  return { harmony: applyVoiceLeading(chords), progressionName: activeProgressionName };
}