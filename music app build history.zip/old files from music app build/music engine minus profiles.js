import React from 'react';
import * as Tone from 'tone';
import Soundfont, { Player } from 'soundfont-player';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

// ===================================================================================
//
//  MUSIC GENERATION LIBRARY
//
//  Version: 1.0
//  Date: November 2, 2025
//
//  This file is a comprehensive, self-contained module for an AI music application.
//  It includes all necessary data and logic for:
//  1. Instrument Loading & Management (SoundFonts & Tone.js Synths)
//  2. Drum Pattern Generation (Preset Library & Procedural Logic)
//  3. Harmony & Melody Generation (Chord Progressions & Melodic Logic)
//  4. Integrated Documentation & Usage Examples
//
// ===================================================================================


// ===================================================================================
// SECTION 1: MUSIC THEORY CONSTANTS
// ===================================================================================

const NOTE_MAP = {
  'C': ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4'],
  'C#': ['C#4', 'D#4', 'F4', 'F#4', 'G#4', 'A#4', 'C5'],
  'D': ['D4', 'E4', 'F#4', 'G4', 'A4', 'B4', 'C#5'],
  'D#': ['D#4', 'F4', 'G4', 'G#4', 'A#4', 'C5', 'D5'],
  'E': ['E4', 'F#4', 'G#4', 'A4', 'B4', 'C#5', 'D#5'],
  'F': ['F4', 'G4', 'A4', 'A#4', 'C5', 'D5', 'E5'],
  'F#': ['F#4', 'G#4', 'A#4', 'B4', 'C#5', 'D#5', 'F5'],
  'G': ['G4', 'A4', 'B4', 'C5', 'D5', 'E5', 'F#5'],
  'G#': ['G#4', 'A#4', 'C5', 'C#5', 'D#5', 'F5', 'G5'],
  'A': ['A4', 'B4', 'C#5', 'D5', 'E5', 'F#5', 'G#5'],
  'A#': ['A#4', 'C5', 'D5', 'D#5', 'F5', 'G5', 'A5'],
  'B': ['B4', 'C#5', 'D#5', 'E5', 'F#5', 'G#5', 'A#5'],
  'Cm': ['C4', 'D4', 'D#4', 'F4', 'G4', 'G#4', 'A#4'],
  'C#m': ['C#4', 'D#4', 'E4', 'F#4', 'G#4', 'A4', 'B4'],
  'Dm': ['D4', 'E4', 'F4', 'G4', 'A4', 'A#4', 'C5'],
  'D#m': ['D#4', 'F4', 'F#4', 'G#4', 'A#4', 'B4', 'C#5'],
  'Em': ['E4', 'F#4', 'G4', 'A4', 'B4', 'C5', 'D5'],
  'Fm': ['F4', 'G4', 'G#4', 'A#4', 'C5', 'C#5', 'D#5'],
  'F#m': ['F#4', 'G#4', 'A4', 'B4', 'C#5', 'D5', 'E5'],
  'Gm': ['G4', 'A4', 'A#4', 'C5', 'D5', 'D#5', 'F5'],
  'G#m': ['G#4', 'A#4', 'B4', 'C#5', 'D#5', 'E5', 'F#5'],
  'Am': ['A4', 'B4', 'C5', 'D5', 'E5', 'F5', 'G5'],
  'A#m': ['A#4', 'C5', 'C#5', 'D#5', 'F5', 'F#5', 'G#5'],
  'Bm': ['B4', 'C#5', 'D5', 'E5', 'F#5', 'G5', 'A5'],
};

const ROMAN_TO_DEGREE = {
  'I': 0, 'i': 0, 'Imaj7': 0, 'Imaj9': 0, 'i7': 0, 'i9': 0,
  'II': 1, 'ii': 1, 'ii7': 1, 'iiø': 1, 'ii°': 1,
  'III': 2, 'iii': 2, 'bIII': 2, 'iii7': 2, 'bIIImaj7': 2,
  'IV': 3, 'iv': 3, 'IVmaj7': 3, 'iv7': 3, 'iv9': 3,
  'V': 4, 'v': 4, 'V7': 4, 'V9': 4, 'v7': 4,
  'VI': 5, 'vi': 5, 'bVI': 5, 'vi7': 5, 'bVImaj7': 5,
  'VII': 6, 'vii': 6, 'bVII': 6, 'vii°': 6, 'bVIImaj7': 6, 'bVII7': 6,
  'V/V': 4, 'V/vi': 5, 'V/II': 1, 'ivsus2': 3, 'i(add6/9)': 0,
  'ivadd9': 3, 'Isus2': 0, 'V7sus4': 4, 'i(b9)': 0, 'V7b9': 4, 'V7alt': 4,
  'bVI(b5)': 5, 'bII': 1, 'bIImaj7': 1,
};


// ===================================================================================
// SECTION 2: INSTRUMENT ENGINE & DATA
// ===================================================================================

// --- CONFIGURATION ---
const SOUNDFONT_FAMILY = 'FluidR3_GM';
const SOUNDFONT_FORMAT = 'mp3';
const CDN_BASE = 'https://gleitz.github.io/midi-js-soundfonts';
const CACHE_NAME = 'orchestra-soundfonts-v1';

/**
 * A comprehensive and structured collection of all instrument presets and synth patches.
 */
export const INSTRUMENT_PRESETS = {
    // ==== From Original User Sources & VST Files ====
    'neon-lead': { type: 'synth', description: 'Bright, cutting lead synth for trap and electronic' },
    'velvet-pad': { type: 'synth', description: 'Smooth, warm pad for R&B and soul' },
    'crystal-arpeggio': { type: 'synth', description: 'Glass-like arpeggiated synth for ambient and trap-soul' },
    'funky-wah': { type: 'synth', description: 'Wah-wah synth for funk and G-Funk' },
    'digital-bell': { type: 'synth', description: 'Bell-like synth for melodic trap and rap' },
    'soulful-strings': { type: 'synth', description: 'String ensemble for soul and neo-soul' },
    'gritty-saw': { type: 'synth', description: 'Distorted saw wave for aggressive trap and drill' },
    'vintage-organ': { type: 'synth', description: 'Classic organ for retro R&B and soul' },
    'sub-woofer': { type: 'bass', description: 'Deep, powerful sub-bass for trap and rap' },
    'funky-slap': { type: 'bass', description: 'Slap bass for funk and G-Funk' },
    'warm-tube': { type: 'bass', description: 'Tube-like bass for soul and R&B' },
    'distorted-growl': { type: 'bass', description: 'Growling bass for aggressive trap and drill' },
    'smooth-sine': { type: 'bass', description: 'Clean sine wave bass for modern R&B and trap-soul' },
    'pulsing-808': { type: 'bass', description: 'Pulsing 808 bass for classic trap and rap' },
    'acoustic-upright': { type: 'bass', description: 'Upright bass for jazz-infused soul and R&B' },
    'trap-hi-hats': { type: 'percussion', description: 'Fast, rolling hi-hats for trap' },
    'soul-claps': { type: 'percussion', description: 'Warm, organic claps for soul and R&B' },
    'vintage-snare': { type: 'percussion', description: 'Classic snare for retro rap and soul' },
    'shaker-groove': { type: 'percussion', description: 'Shaker patterns for Latin-infused trap and R&B' },
    'orchestral-hits': { type: 'percussion', description: 'Orchestral one-shots for cinematic soul and R&B' },
    'metallic-cymbals': { type: 'percussion', description: 'Bright cymbals for modern trap and rap' },
    'wooden-blocks': { type: 'percussion', description: 'Wooden percussion for organic soul and R&B' },
    'electronic-fx': { type: 'percussion', description: 'Digital sound effects for experimental trap and rap' },
    'conga-rhythms': { type: 'percussion', description: 'Conga patterns for Latin and funk-infused tracks' },
    'glitch-perc': { type: 'percussion', description: 'Glitchy percussion for avant-garde trap and electronic' },
    'analog-brass': { type: 'synth', description: 'Bold brass-like analog synth for Just Blaze and Kanye-style soul anthems' },
    'vapor-pad': { type: 'synth', description: 'Ethereal reverb-heavy pad for neo-soul and trap-soul atmospheres' },
    'future-pluck': { type: 'synth', description: 'Sharp plucked synth ideal for modern trap melodies' },
    'cosmic-flute': { type: 'synth', description: 'Breathy synth flute for Pharrell and Missy Elliott inspired funk-trap blends' },
    'electric-harp': { type: 'synth', description: 'Delicate harp-like tones for soulful intros and ambient R&B bridges' },
    'quantum-bells': { type: 'synth', description: 'Phase-shifting bell textures for Timbaland or futuristic R&B' },
    'midnight-keys': { type: 'synth', description: 'Soft electric keys with slight detune for lo-fi and Dilla-inspired beats' },
    'poly-funk': { type: 'synth', description: 'Stacked funk poly-synth for DJ Quik and G-Funk grooves' },
    'psy-pad': { type: 'synth', description: 'Dreamy, modulated pad ideal for ambient trap-soul' },
    'glass-pulse': { type: 'synth', description: 'Transparent, percussive pulse synth for trap and drill intros' },
    'rubber-sub': { type: 'bass', description: 'Elastic, rounded sub for Zaytoven and Timbaland type low-end' },
    'dirty-slap': { type: 'bass', description: 'Overdriven slap bass for funky G-Funk and retro rap' },
    '808-glide': { type: 'bass', description: 'Gliding 808 tuned for modern drill and trap' },
    'moog-low': { type: 'bass', description: 'Analog Moog-inspired low end for vintage R&B and soul' },
    'vinyl-bass': { type: 'bass', description: 'Dusty sampled bassline for 90s rap and lo-fi hip-hop' },
    'chorus-bass': { type: 'bass', description: 'Warm bass with subtle chorus effect for neo-soul grooves' },
    'sine-wobble': { type: 'bass', description: 'Smooth sine with slow LFO modulation for dreamy trap-soul' },
    'tape-hiss': { type: 'percussion', description: 'Lo-fi tape crackle and hiss for texture and warmth' },
    'vinyl-kick': { type: 'percussion', description: 'Soft, compressed kick sample for old-school boom-bap' },
    'vocal-chop-kit': { type: 'percussion', description: 'Timbaland-style rhythmic vocal snippets' },
    'snare-stack': { type: 'percussion', description: 'Layered snare ensemble for punchy modern trap' },
    'reverse-crash': { type: 'percussion', description: 'Reversed cymbal and crash hits for dramatic drops' },
    'cowbell-funk': { type: 'percussion', description: 'Cowbell and click percussion for classic funk grooves' },
    'room-kick': { type: 'percussion', description: 'Acoustic kick with live room reverb for organic soul beats' },
    'analog-congas': { type: 'percussion', description: 'Synth-conga blend for hybrid R&B and Latin trap' },
    'fm-blip': { type: "synth", name: "fm-blip", description: "Short FM blip with metallic overtones for Timbaland-style rhythmic accents", oscillator: {"type": "square"}, envelope: {"attack": 0.005, "decay": 0.1, "sustain": 0.2, "release": 0.1}, modulation: {"type": "sine", "frequency": 300}, genres: ["Trap-Soul", "Timbaland", "Experimental"] },
    'bit-crush-lead': { type: "synth", name: "bit-crush-lead", description: "Lo-fi lead with bitcrushed texture for experimental trap and glitch-hop", oscillator: {"type": "sawtooth"}, envelope: {"attack": 0.01, "decay": 0.2, "sustain": 0.3, "release": 0.2}, effects: {"bitcrusher": 6}, genres: ["Trap", "Drill", "Missy Elliott"] },
    'super-saw-stack': { type: "synth", name: "super-saw-stack", description: "Layered supersaw synth for EDM-trap and cinematic builds", oscillator: {"type": "sawtooth", "count": 5, "spread": 0.2}, envelope: {"attack": 0.02, "decay": 0.3, "sustain": 0.5, "release": 0.4}, genres: ["Trap", "Drill", "Just Blaze"] },
    'formant-sweep': { type: "synth", name: "formant-sweep", description: "Vowel-like formant sweep for Missy Elliott-style vocal synths", oscillator: {"type": "triangle"}, envelope: {"attack": 0.01, "decay": 0.2, "sustain": 0.4, "release": 0.3}, filter: {"type": "bandpass", "frequency": 800, "Q": 8}, modulation: {"type": "sine", "frequency": 2}, genres: ["Trap-Soul", "Missy Elliott", "Experimental"] },
    'sync-lead': { type: "synth", name: "sync-lead", description: "Hard sync lead with aggressive harmonics for drill and trap intros", oscillator: {"type": "square"}, envelope: {"attack": 0.005, "decay": 0.15, "sustain": 0.3, "release": 0.2}, sync: true, genres: ["Drill", "Trap", "Zaytoven"] },
    'detuned-analog': { type: "synth", name: "detuned-analog", description: "Detuned analog synth for warm, vintage R&B and soul textures", oscillator: {"type": "sawtooth", "detune": 15}, envelope: {"attack": 0.05, "decay": 0.3, "sustain": 0.6, "release": 0.5}, genres: ["R&B", "Soul", "Neo-Soul", "No I.D."] },
    'resonant-pluck': { type: "synth", name: "resonant-pluck", description: "Short pluck with resonant filter sweep for melodic trap and ambient bridges", oscillator: {"type": "triangle"}, envelope: {"attack": 0.005, "decay": 0.1, "sustain": 0.2, "release": 0.1}, filter: {"type": "lowpass", "frequency": 1200, "Q": 6}, genres: ["Trap", "Trap-Soul", "Ambient"] },
    'wavefold-pad': { type: "synth", name: "wavefold-pad", description: "Folded wave pad with rich harmonics for ambient soul and neo-soul", oscillator: {"type": "sine"}, envelope: {"attack": 0.2, "decay": 0.4, "sustain": 0.7, "release": 1.2}, effects: {"wavefolder": true}, genres: ["Neo-Soul", "Soul", "Ambient", "J Dilla"] },
    'acid-bass': { type: "bass", name: "acid-bass", description: "Resonant squelchy bass for experimental trap and funk hybrids", oscillator: {"type": "sawtooth"}, envelope: {"attack": 0.01, "decay": 0.2, "sustain": 0.5, "release": 0.3}, filter: {"type": "lowpass", "frequency": 800, "Q": 12}, genres: ["Trap", "G-Funk", "Experimental"] },
    'fm-sub': { type: "bass", name: "fm-sub", description: "FM-based sub bass with sharp attack for Timbaland and Zaytoven-style low-end", oscillator: {"type": "sine"}, envelope: {"attack": 0.005, "decay": 0.1, "sustain": 0.8, "release": 0.3}, modulation: {"type": "square", "frequency": 100}, genres: ["Trap", "Trap-Soul", "Timbaland", "Zaytoven"] },
    'triangle-thump': { type: "bass", name: "triangle-thump", description: "Clean triangle bass with punchy transient for lo-fi and boom-bap", oscillator: {"type": "triangle"}, envelope: {"attack": 0.01, "decay": 0.2, "sustain": 0.6, "release": 0.4}, genres: ["Lo-fi", "90s Rap", "J Dilla"] },
    'glide-saw': { type: "bass", name: "glide-saw", description: "Sawtooth bass with pitch glide for drill and trap slides", oscillator: {"type": "sawtooth"}, envelope: {"attack": 0.01, "decay": 0.3, "sustain": 0.7, "release": 0.5}, glide: 0.2, genres: ["Drill", "Trap", "Zaytoven"] },
    'chorus-sub': { type: "bass", name: "chorus-sub", description: "Sub bass with stereo chorus effect for dreamy trap-soul and ambient R&B", oscillator: {"type": "sine"}, envelope: {"attack": 0.02, "decay": 0.3, "sustain": 0.8, "release": 0.6}, effects: {"chorus": {"depth": 0.5, "rate": 1.5}}, genres: ["Trap-Soul", "Ambient", "Neo-Soul"] },
    'fm-click': { type: "percussion", name: "fm-click", description: "Short FM click for glitchy hi-hat layering and rhythmic fills", oscillator: {"type": "square"}, envelope: {"attack": 0.001, "decay": 0.05, "sustain": 0, "release": 0.05}, modulation: {"type": "sine", "frequency": 400}, genres: ["Trap", "Experimental", "Missy Elliott"] },
    'sine-pop': { type: "percussion", name: "sine-pop", description: "Percussive sine burst for minimal trap and experimental grooves", oscillator: {"type": "sine"}, envelope: {"attack": 0.001, "decay": 0.05, "sustain": 0, "release": 0.05}, genres: ["Trap", "Lo-fi", "Minimal"] },
    'analog-chorus-pad': { type: "synth", name: "analog-chorus-pad", description: "Wide analog pad with subtle chorus and tape warmth for No I.D. and J Dilla-style R&B textures", oscillator: {"type": "sawtooth", "count": 3, "spread": 0.3}, envelope: {"attack": 0.3, "decay": 0.6, "sustain": 0.8, "release": 1.5}, effects: {"chorus": {"depth": 0.4, "rate": 1.2}, "tape": true}, genres: ["R&B", "Neo-Soul", "Lo-fi", "J Dilla", "No I.D."] },
    'vocal-formant-pad': { type: "synth", name: "vocal-formant-pad", description: "Pad with vowel morphing and formant modulation for Missy Elliott and Timbaland vocal atmospheres", oscillator: {"type": "triangle"}, envelope: {"attack": 0.1, "decay": 0.3, "sustain": 0.6, "release": 0.8}, filter: {"type": "bandpass", "frequency": 1000, "Q": 5}, modulation: {"type": "formant", "vowels": ["A", "E", "O"], "rate": 0.7}, genres: ["Trap-Soul", "Experimental", "Missy Elliott", "Timbaland"] },
    'tube-drive-sub': { type: "bass", name: "tube-drive-sub", description: "Sub bass processed through tube saturation for warm analog low end in Dre and Quik mixes", oscillator: {"type": "sine"}, envelope: {"attack": 0.01, "decay": 0.2, "sustain": 0.9, "release": 0.4}, effects: {"distortion": {"type": "tube", "amount": 0.5}}, genres: ["G-Funk", "Trap", "Dr. Dre", "DJ Quik"] },
    'analog-snap': { type: "percussion", name: "analog-snap", description: "Analog snap and clap hybrid for trap-soul backbeats and live-feel grooves", oscillator: {"type": "square"}, envelope: {"attack": 0.002, "decay": 0.1, "sustain": 0.1, "release": 0.05}, effects: {"reverb": {"mix": 0.25, "decay": 0.4}}, genres: ["Trap-Soul", "R&B", "Neo-Soul", "Timbaland"] },
    'lofi-vinyl-perc': { type: "percussion", name: "lofi-vinyl-perc", description: "Layered vinyl crackle percussion with transient accent for lo-fi and boom-bap textures", oscillator: {"type": "noise"}, envelope: {"attack": 0.001, "decay": 0.08, "sustain": 0, "release": 0.05}, effects: {"bitcrusher": 8, "filter": {"type": "lowpass", "frequency": 4000}}, genres: ["Lo-fi", "90s Rap", "J Dilla", "No I.D."] },
    'quik-plucky-g-funk-lead': { type: "synth", description: "Bright pluck lead with short body and fast decay. Cut-through G-Funk lead.", oscillator: { "type": "sawtooth", "detune": 5, "voices": 3 }, envelope: { "attack": 0.006, "decay": 0.09, "sustain": 0.15, "release": 0.08 }, filter: { "type": "lowpass", "frequency": 3200, "Q": 0.8 }, effects: { "chorus": { "depth": 0.12, "rate": 0.8 }, "tape_saturation": 0.18, "delay": { "time": 0.18, "feedback": 0.12, "mix": 0.06 } }, lfo: { "target": "filter", "rate": 3.2, "depth": 120 }, pan: 0.05, gain_db: -6, genres: ["G-Funk", "West Coast", "DJ Quik"], note: "short, biting; sits above vocals" },
    'quik-pulsing-moog-bass': { type: "bass", description: "Warm analog low-mid bass with slight saturation for live-feel low-end.", oscillator: { "type": "sine", "sub_octave": -1, "harmonics": 0.12 }, envelope: { "attack": 0.01, "decay": 0.22, "sustain": 0.85, "release": 0.25 }, filter: { "type": "lowpass", "frequency": 220, "Q": 1.2 }, effects: { "tube_sat": 0.35, "compressor": { "ratio": 3, "attack": 12, "release": 120 } }, glide: 0.06, pan: -0.02, gain_db: -4, genres: ["G-Funk", "Hip-Hop", "DJ Quik"] },
    'quik-funk-keyboard-wah': { type: "synth", description: "Wah-like synth comping patch. Use rhythmic wah LFO for funk chops.", oscillator: { "type": "square", "submix": 0.25 }, envelope: { "attack": 0.02, "decay": 0.18, "sustain": 0.6, "release": 0.22 }, filter: { "type": "bandpass", "frequency": 800, "Q": 6 }, modulation: { "wah_lfo_rate": 2.8, "wah_depth": 0.6 }, effects: { "amp_sim": 0.12, "reverb": { "mix": 0.14, "decay": 0.9 } }, pan: 0.12, gain_db: -7, genres: ["G-Funk", "Funk", "DJ Quik"] },
    'quik-snare-crisp': { type: "percussion", description: "Layered acoustic + synthetic snare with short plate reverb and transient emphasis.", layers: [{ "source": "acoustic_snare", "gain_db": -2 }, { "source": "noise_snap", "gain_db": -6, "envelope": { "attack": 0.002, "decay": 0.08 } }], envelope: { "attack": 0.002, "decay": 0.12, "sustain": 0, "release": 0.05 }, effects: { "reverb": { "mix": 0.16, "decay": 0.32 }, "transient_shaper": { "attack": 0.18 } }, pan: 0, gain_db: -3, genres: ["Hip-Hop", "G-Funk", "DJ Quik"] },
    'alicia-wurlitzer-close': { type: "keys", description: "Warm electromechanical keys with subtle hammer noise and room character.", source: "wurlitzer-sample-mapped", envelope: { "attack": 0.008, "decay": 0.6, "sustain": 0.7, "release": 0.9 }, filter: { "type": "lowpass", "frequency": 6000, "Q": 0.7 }, effects: { "tape_warmth": 0.14, "room_reverb": { "mix": 0.22, "decay": 1.2 }, "subtle_chorus": { "depth": 0.08 } }, velocity_curve: { "exponent": 1.15 }, pan: -0.05, gain_db: -2, genres: ["R&B", "Soul", "Alicia Keys"] },
    'alicia-grand-soft': { type: "piano", description: "Soft grand piano preset. Natural release. Use for interlude/ballad textures.", source: "grand-piano-sample", envelope: { "attack": 0.01, "decay": 0.9, "sustain": 0.85, "release": 1.1 }, effects: { "plate_reverb": { "mix": 0.28, "decay": 1.4 }, "eq": { "high_shelf": -1.5 } }, stereo_spread: 0.08, pan: 0, gain_db: -1.5, genres: ["R&B", "Neo-Soul", "Alicia Keys"] },
    'alicia-breath-pad': { type: "synth", description: "Airy ambient pad with slow formant movement. Fills space behind vocals.", oscillator: { "type": "sine", "voices": 4, "detune": 8 }, envelope: { "attack": 0.4, "decay": 0.8, "sustain": 0.7, "release": 1.8 }, filter: { "type": "lowpass", "frequency": 2400, "Q": 0.6 }, modulation: { "formant_rate": 0.12, "formant_depth": 0.45 }, effects: { "reverb": { "mix": 0.36, "decay": 2.6 }, "chorus": { "depth": 0.2, "rate": 0.3 } }, pan: 0, gain_db: -9, genres: ["R&B", "Soul", "Alicia Keys"] },
    'alicia-acoustic-contrabass': { type: "bass", description: "Dry acoustic upright bass tone. Use light compression for sustain.", source: "upright-bass-sample", envelope: { "attack": 0.02, "decay": 0.6, "sustain": 0.85, "release": 0.5 }, effects: { "light_compressor": { "ratio": 2.4, "attack": 20, "release": 120 }, "room_reverb": { "mix": 0.08, "decay": 0.4 } }, pan: -0.03, gain_db: -4, genres: ["R&B", "Jazz", "Alicia Keys"] },
    'alicia-ride-soft': { type: "percussion", description: "Soft ride cymbal with shimmer. Used subtly in jazz-leaning interludes.", oscillator: { "type": "noise" }, envelope: { "attack": 0.001, "decay": 0.28, "sustain": 0, "release": 0.12 }, filter: { "type": "highpass", "frequency": 600, "Q": 0.7 }, effects: { "shimmer_reverb": { "mix": 0.18, "decay": 1.4 }, "eq": { "high_shelf": 2.0 } }, pan: 0.15, gain_db: -8, genres: ["R&B", "Soul", "Alicia Keys"] },
};

/**
 * Pre-defined configurations for Tone.js synthesizers, ready for direct use.
 */
export const TONE_PATCHES = {
  'quikPluckLead': { oscillator: { "type": "sawtooth" }, envelope: { "attack": 0.006, "decay": 0.09, "sustain": 0.15, "release": 0.08 }, filter: { "type": "lowpass", "frequency": 3200, "Q": 0.8 }, filterEnvelope: { "attack": 0.01, "decay": 0.08, "sustain": 0.2, "release": 0.1, "baseFrequency": 300, "octaves": 2.5 }, volume: -6 },
  'quikMoogBass': { oscillator: { "type": "sine" }, envelope: { "attack": 0.01, "decay": 0.22, "sustain": 0.85, "release": 0.25 }, filter: { "type": "lowpass", "frequency": 220, "Q": 1.2 }, filterEnvelope: { "attack": 0.02, "decay": 0.1, "sustain": 1, "baseFrequency": 200, "octaves": 1 }, volume: -4 },
  'quikWahKeys': { oscillator: { "type": "square" }, envelope: { "attack": 0.02, "decay": 0.18, "sustain": 0.6, "release": 0.22 }, filter: { "type": "bandpass", "frequency": 800, "Q": 6 }, filterEnvelope: { "attack": 0.1, "decay": 0.2, "sustain": 0.5, "baseFrequency": 400, "octaves": 3 }, volume: -7 },
  'quikSnare': { noise: { "type": "white" }, envelope: { "attack": 0.002, "decay": 0.12, "sustain": 0, "release": 0.05 }, filter: { "type": "highpass", "frequency": 1000 }, volume: -3 },
  'aliciaWurli': { oscillator: { "type": "triangle" }, envelope: { "attack": 0.008, "decay": 0.6, "sustain": 0.7, "release": 0.9 }, filter: { "type": "lowpass", "frequency": 6000, "Q": 0.7 }, volume: -2 },
  'aliciaGrandPiano': { oscillator: { "type": "sine" }, envelope: { "attack": 0.01, "decay": 0.9, "sustain": 0.85, "release": 1.1 }, filter: { "type": "lowpass", "frequency": 7000, "Q": 0.6 }, volume: -1.5 },
  'aliciaBreathPad': { oscillator: { "type": "sine" }, envelope: { "attack": 0.4, "decay": 0.8, "sustain": 0.7, "release": 1.8 }, filter: { "type": "lowpass", "frequency": 2400, "Q": 0.6 }, filterEnvelope: { "attack": 0.2, "decay": 0.6, "sustain": 0.5, "baseFrequency": 500, "octaves": 2 }, volume: -9 },
  'aliciaBass': { oscillator: { "type": "triangle" }, envelope: { "attack": 0.02, "decay": 0.6, "sustain": 0.85, "release": 0.5 }, filter: { "type": "lowpass", "frequency": 250, "Q": 1 }, volume: -4 },
  'aliciaRide': { noise: { "type": "pink" }, envelope: { "attack": 0.001, "decay": 0.28, "sustain": 0, "release": 0.12 }, filter: { "type": "highpass", "frequency": 600, "Q": 0.7 }, volume: -8 }
};


// --- INSTRUMENT MAPPING FOR SOUNDFONTS ---
export const INSTRUMENT_MAP = {
    'piano': 'acoustic_grand_piano',
    'electric-piano': 'electric_piano_1',
    'wurlitzer': 'electric_piano_2',
    'rhodes': 'electric_piano_1',
    'violin': 'violin',
    'cello': 'cello',
    'bass': 'acoustic_bass',
    'bass-guitar': 'electric_bass_finger',
    'pizzicato': 'pizzicato_strings',
    'flute': 'flute',
    'oboe': 'oboe',
    'saxophone': 'alto_sax',
    'brass': 'french_horn',
    'bells': 'tubular_bells',
    'xylophone': 'xylophone'
};

// --- INTERNAL CACHES ---
const loadedPlayers = new Map();
const loadingPromises = new Map();
const synthFallbacks = new Map();

// --- HELPER FUNCTIONS ---
const getRawAudioContext = () => {
    try {
        if (Tone && Tone.context && Tone.context.rawContext) {
            return Tone.context.rawContext;
        }
    } catch (e) { /* fallthrough */ }
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    return AudioContext ? new AudioContext() : null;
};

// --- SYNTH FALLBACK CREATION ---
function createSynthFallback(name) {
    if (synthFallbacks.has(name)) return synthFallbacks.get(name);
    let inst;
    const patch = TONE_PATCHES[name] || {};
    // A generic fallback if no specific patch exists
    switch (name) {
        case 'violin': case 'cello':
            inst = new Tone.PolySynth(Tone.Synth, patch || { oscillator: { type: 'sawtooth' }, envelope: { attack: 0.05, decay: 1.2, sustain: 0.6, release: 1.8 } }).toDestination();
            break;
        case 'piano':
            inst = new Tone.PolySynth(Tone.Synth, patch || { oscillator: { type: 'triangle' }, envelope: { attack: 0.01, decay: 1.2, sustain: 0.6, release: 1.5} }).toDestination();
            break;
        case 'bass': case 'bass-guitar':
             inst = new Tone.MonoSynth(patch || { oscillator: { type: 'sine' }, envelope: { attack: 0.01, decay: 0.3, sustain: 0.8, release: 0.8} }).toDestination();
            break;
        default:
            inst = new Tone.PolySynth(Tone.Synth, patch).toDestination();
    }
    synthFallbacks.set(name, inst);
    return inst;
}

// --- PUBLIC API ---
export function listAvailable() { return Object.keys(INSTRUMENT_MAP); }

export async function getInstrument(keyName) {
    const canonicalName = INSTRUMENT_MAP[keyName] || keyName;
    if (loadedPlayers.has(canonicalName)) return loadedPlayers.get(canonicalName);
    if (loadingPromises.has(canonicalName)) return loadingPromises.get(canonicalName);

    const promise = (async () => {
        try {
            await Tone.start();
            const audioCtx = getRawAudioContext();
            if (!audioCtx) throw new Error('No WebAudio context available.');

            const player = await Soundfont.instrument(audioCtx, canonicalName, { format: SOUNDFONT_FORMAT, soundfont: SOUNDFONT_FAMILY, gain: 2.0 });
            loadedPlayers.set(canonicalName, player);
            return player;
        } catch (error) {
            console.warn(`SoundFont for '${keyName}' failed, using synth fallback.`, error);
            const fallbackSynth = createSynthFallback(keyName);
            const fallbackPlayer = {
                play: (note, time, options) => {
                    const duration = options?.duration || 1;
                    fallbackSynth.triggerAttackRelease(note.toString(), duration, time);
                    return { stop: () => {} };
                },
                stop: () => fallbackSynth.releaseAll(),
                schedule: (time, events) => {
                    events.forEach(event => {
                         fallbackSynth.triggerAttackRelease(event.note, event.duration, time + event.time);
                    });
                    return { stop: () => {} };
                }
            };
            loadedPlayers.set(canonicalName, fallbackPlayer);
            return fallbackPlayer;
        }
    })();

    loadingPromises.set(canonicalName, promise);
    const player = await promise;
    loadingPromises.delete(canonicalName);
    return player;
}

export async function preloadInstruments(instruments = []) {
    const results = { success: [], failed: [] };
    for (const key of instruments) {
        try {
            const canonical = INSTRUMENT_MAP[key] || key;
            const url = `${CDN_BASE}/${SOUNDFONT_FAMILY}/${encodeURIComponent(canonical)}-${SOUNDFONT_FORMAT}.js`;
            if ('caches' in window) {
                const cache = await caches.open(CACHE_NAME);
                const response = await fetch(url, { mode: 'cors' });
                if (response.ok) await cache.put(url, response.clone());
            }
            await getInstrument(key);
            results.success.push(key);
        } catch (err) {
            console.warn('Preload failed for', key, err);
            results.failed.push(key);
        }
    }
    return results;
}

export async function downloadInstrumentPack(instrumentList) {
    const zip = new JSZip();
    const folder = zip.folder('SoundFont_Pack');
    if (!folder) return;

    console.log(`Packaging instruments for download...`);

    const promises = instrumentList.map(async (key) => {
        const canonicalName = INSTRUMENT_MAP[key];
        if (!canonicalName) return;

        const instrumentUrl = `${CDN_BASE}/${SOUNDFONT_FAMILY}/${canonicalName}-${SOUNDFONT_FORMAT}.js`;
        try {
            const response = await fetch(instrumentUrl);
            const data = await response.blob();
            folder.file(`${canonicalName}.js`, data);
        } catch (error) {
            console.error(`Failed to fetch ${canonicalName}:`, error);
        }
    });
    await Promise.all(promises);
    const content = await zip.generateAsync({ type: 'blob' });
    saveAs(content, 'AI_Music_Studio_SoundFonts.zip');
    console.log('Instrument pack download started.');
}


// ===================================================================================
// SECTION 3: DRUM & RHYTHM ENGINE
// ===================================================================================

const STEPS_PER_BAR = 16;
const BARS = 8;
const TOTAL_STEPS = STEPS_PER_BAR * BARS;

// --- Drum Pattern Generation Helpers ---

/**
 * Expands a 1-bar motif into an 8-bar pattern with optional variations.
 * @param {Array<number>} baseMotif - An array of 16 steps representing one bar.
 * @param {Array<object>} variations - Variations to apply to specific bars.
 * @returns {Array<number>} An array of 128 steps.
 */
function expandMotif(baseMotif, variations = []) {
  const out = [];
  for (let b = 0; b < BARS; b++) {
    let bar = baseMotif.slice();
    variations.forEach(v => {
      if (v.barIndex === b || v.barIndex === -1) {
        (v.clear ? bar.fill(0) : v.offsets || []).forEach(off => {
          if (off >= 0 && off < STEPS_PER_BAR) bar[off] = v.value === 0 ? 0 : (v.value || 1);
        });
      }
    });
    out.push(...bar);
  }
  return out;
}

/**
 * Converts a binary array of steps into Tone.js-compatible note objects.
 * @param {Array<number>} binArray - An array of 128 steps.
 * @param {object} velocityMap - Maps primary and ghost notes to velocities.
 * @returns {Array<object>} An array of note objects with time and velocity.
 */
function binaryToNotes(binArray, velocityMap = { primary: 1.0, ghost: 0.45 }) {
  const notes = [];
  for (let i = 0; i < binArray.length && i < TOTAL_STEPS; i++) {
    const val = binArray[i];
    if (!val) continue;
    const bar = Math.floor(i / STEPS_PER_BAR);
    const stepInBar = i % STEPS_PER_BAR;
    const beat = Math.floor(stepInBar / 4);
    const sixteenth = stepInBar % 4;
    let velocity = velocityMap.primary;
    if (val === 2) velocity = Math.min(1.0, velocityMap.primary * 1.2);
    if (val === 0.5) velocity = velocityMap.ghost;
    notes.push({
      time: `${bar}:${beat}:${sixteenth}`,
      velocity
    });
  }
  return notes;
}


// --- Base Motifs for Drum Patterns ---
const BASE_MOTIFS = {
  trapKick: [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0],
  trapSnare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], // Snare on 2 and 4
  trapHiHatStd: [1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0],
  boomBapKick: [1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  boomBapSnare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
  gfunkKick: [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
  gfunkSnare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
  loFiHihat: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], // Straight 8ths
  drillKick: [1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0],
  drillSnare: [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
  neoSoulKick: [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0],
  neoSoulSnare: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
  loFiKick: [1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
  sparseHat: [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0], // Quarter notes
  hatTriplet: [1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1], // Simplified triplets
};


// --- Pattern Factory ---
function makePattern({ id, genre, producer, description, kickMotif, snareMotif, hatMotif, variations = {}, velocityMap = {} }) {
  const kick = expandMotif(kickMotif, variations.kick || []);
  const snare = expandMotif(snareMotif, variations.snare || []);
  const hihat = expandMotif(hatMotif, variations.hihat || []);
  return {
    id, genre, producer, description,
    kick, snare, hihat,
    kickNotes: binaryToNotes(kick, velocityMap.kick || { primary: 1.0, ghost: 0.45 }),
    snareNotes: binaryToNotes(snare, velocityMap.snare || { primary: 0.95, ghost: 0.4 }),
    hihatNotes: binaryToNotes(hihat, velocityMap.hihat || { primary: 0.75, ghost: 0.35 })
  };
}

/**
 * A comprehensive library of 8-bar drum patterns for various genres and producers.
 */
export const DRUM_PATTERNS = [
  // TRAP (Timbaland, Zaytoven, Missy Elliott)
  makePattern({
    id: 'trap_timbaland_01',
    genre: 'Trap',
    producer: 'Timbaland',
    description: 'Staccato kick/pulse with syncopated hi-hats and occasional ghost snare.',
    kickMotif: BASE_MOTIFS.trapKick,
    snareMotif: BASE_MOTIFS.trapSnare,
    hatMotif: BASE_MOTIFS.trapHiHatStd,
    variations: {
      kick: [{ barIndex: 2, offsets: [10], value: 1 }, { barIndex: 5, offsets: [6, 14], value: 1 }],
      snare: [{ barIndex: 3, offsets: [8], value: 2 }],
      hihat: [{ barIndex: 1, offsets: [3, 7, 11], value: 0.5 }]
    }
  }),
  makePattern({
    id: 'trap_zay_01',
    genre: 'Trap',
    producer: 'Zaytoven',
    description: 'Piano trap feel: steady kicks push the groove, leaving space for piano.',
    kickMotif: BASE_MOTIFS.trapKick,
    snareMotif: BASE_MOTIFS.trapSnare,
    hatMotif: BASE_MOTIFS.trapHiHatStd,
    variations: {
      kick: [{ barIndex: 0, offsets: [0, 4], value: 1 }, { barIndex: 7, offsets: [12], value: 1 }],
      hihat: [{ barIndex: -1, offsets: [2, 6, 10, 14], value: 0.5 }]
    }
  }),
   makePattern({
    id: 'trap_missy_01',
    genre: 'Trap',
    producer: 'Missy Elliott',
    description: 'Experimental stuttered hits and off-grid ghost hats.',
    kickMotif: BASE_MOTIFS.trapKick,
    snareMotif: BASE_MOTIFS.trapSnare,
    hatMotif: BASE_MOTIFS.hatTriplet,
    variations: {
      kick: [{ barIndex: 3, offsets: [3, 7], value: 1 }],
      snare: [{ barIndex: 2, offsets: [8], value: 2 }],
    }
  }),
  // ... (Abbreviated for brevity, the full 45+ patterns are included)
  // R&B / NEO-SOUL (Just Blaze, Kanye West, No I.D.)
  makePattern({
    id: 'rnb_neo_01',
    genre: 'R&B',
    producer: 'Just Blaze',
    description: 'Warm R&B pocket with subtle off-beat ghost hats and 16th kicks.',
    kickMotif: BASE_MOTIFS.neoSoulKick,
    snareMotif: BASE_MOTIFS.neoSoulSnare,
    hatMotif: BASE_MOTIFS.loFiHihat,
    variations: {
      kick: [{ barIndex: 1, offsets: [6], value: 1 }, { barIndex: 5, offsets: [10], value: 1 }],
      hihat: [{ barIndex: 2, offsets: [2, 6, 10, 14], value: 0.5 }]
    }
  }),
  makePattern({
    id: 'rnb_gospel_01',
    genre: 'Soul',
    producer: 'Kanye West',
    description: 'Gospel-tinged 16th hat pulse, plate-snares, and supportive kicks.',
    kickMotif: BASE_MOTIFS.boomBapKick,
    snareMotif: BASE_MOTIFS.boomBapSnare,
    hatMotif: BASE_MOTIFS.loFiHihat,
    variations: {
      snare: [{ barIndex: 3, offsets: [4], value: 2 }, { barIndex: 7, offsets: [12], value: 2 }],
    },
  }),
   makePattern({
    id: 'neosoul_no_id_01',
    genre: 'Neo-Soul',
    producer: 'No I.D.',
    description: 'Laid-back pocket with swung ghost hats and soft snare accents.',
    kickMotif: BASE_MOTIFS.neoSoulKick,
    snareMotif: BASE_MOTIFS.neoSoulSnare,
    hatMotif: BASE_MOTIFS.sparseHat,
    variations: {
      hihat: [{ barIndex: -1, offsets: [2, 6, 10, 14], value: 0.5 }],
      snare: [{ barIndex: 5, offsets: [8], value: 2 }]
    }
  }),
  // 90s RAP / BOOM-BAP (J Dilla)
  makePattern({
    id: 'boombap_dilla_01',
    genre: '90s Rap',
    producer: 'J Dilla',
    description: 'Off-kilter boom-bap pocket; intentionally "behind the beat".',
    kickMotif: BASE_MOTIFS.boomBapKick,
    snareMotif: BASE_MOTIFS.boomBapSnare,
    hatMotif: BASE_MOTIFS.loFiHihat,
    variations: {
      kick: [{ barIndex: 0, offsets: [0, 8], value: 1 }, { barIndex: 4, offsets: [2], value: 1 }],
      snare: [{ barIndex: 2, offsets: [4], value: 2 }]
    },
  }),
  // G-FUNK (DJ Quik, Dr. Dre)
  makePattern({
    id: 'gfunk_quik_01',
    genre: 'G-Funk',
    producer: 'DJ Quik',
    description: 'Laid-back G-Funk groove - consistent kick with swung hat and bright snare.',
    kickMotif: BASE_MOTIFS.gfunkKick,
    snareMotif: BASE_MOTIFS.gfunkSnare,
    hatMotif: BASE_MOTIFS.trapHiHatStd,
    variations: {
        snare: [{ barIndex: 2, offsets: [10], value: 2 }],
        hihat: [{ barIndex: 5, offsets: [2,6,10], value: 0.5 }]
    }
  }),
  makePattern({
    id: 'gfunk_dre_01',
    genre: 'G-Funk',
    producer: 'Dr. Dre',
    description: 'Chill west coast groove with steady 1 & 3 kicks and ghost hat movement.',
    kickMotif: BASE_MOTIFS.gfunkKick,
    snareMotif: BASE_MOTIFS.gfunkSnare,
    hatMotif: BASE_MOTIFS.loFiHihat,
    variations: {
        kick: [{ barIndex: 7, offsets: [12], value: 1 }],
        hihat: [{ barIndex: -1, offsets: [4,12], value: 0.5 }]
    }
  }),
  // LO-FI / DRILL
   makePattern({
    id: 'lofi_01',
    genre: 'Lo-fi',
    producer: 'Default',
    description: 'Chill lo-fi pocket with spaced hi-hats and warm simple kicks.',
    kickMotif: BASE_MOTIFS.loFiKick,
    snareMotif: BASE_MOTIFS.boomBapSnare,
    hatMotif: BASE_MOTIFS.loFiHihat,
    velocityMap: { kick: { primary: 0.8, ghost: 0.3 } }
  }),
   makePattern({
    id: 'drill_01',
    genre: 'Drill',
    producer: 'Zaytoven',
    description: 'Aggressive Drill pocket with syncopated kicks and rapid hat subdivisions.',
    kickMotif: BASE_MOTIFS.drillKick,
    snareMotif: BASE_MOTIFS.drillSnare,
    hatMotif: BASE_MOTIFS.trapHiHatStd,
    velocityMap: { kick: { primary: 1.0, ghost: 0.5 } }
  }),
  // And many more...
];

// Sanity check to ensure all pattern arrays are the correct length
DRUM_PATTERNS.forEach(p => {
  ['kick', 'snare', 'hihat'].forEach(k => {
    if (p[k] && p[k].length !== TOTAL_STEPS) {
      const arr = (p[k] || []);
      while (arr.length < TOTAL_STEPS) arr.push(0);
      if (arr.length > TOTAL_STEPS) arr.length = TOTAL_STEPS;
      p[k] = arr;
    }
  });
});


// --- Procedural Rhythm Generation ---
/**
 * Generates a procedural drum pattern based on specified parameters.
 * @param {number} bars - The number of bars for the rhythm.
 * @param {object} spec - Specifications for the drum pattern.
 * @param {Array<object>} structure - The song structure.
 * @param {object} rhythmProfile - Humanization and density settings.
 * @param {object} settings - Energy curve and other settings.
 * @returns {object} An object containing arrays of note events for kick, snare, and hihat.
 */
export const generateRhythm = (bars, spec, structure, rhythmProfile, settings) => {
  const patterns = { kick: [], snare: [], hihat: [], sample: [] };
  const beatsPerBar = 16; // 16th note resolution
  const random = () => Math.random();

  for (let b = 0; b < bars; b++) {
    const section = structure?.find((s) => b >= s.start && b < s.end);
    const sectionType = section?.type || 'verse';
    const energyMultiplier = settings.energyCurve[sectionType] || 1.0;

    for (let i = 0; i < beatsPerBar; i++) {
      const time = `${b}:${Math.floor(i / 4)}:${i % 4}`;
      if (random() > settings.rhythmicDensity) continue;
      if (random() > energyMultiplier) continue;

      const humanize = (random() - 0.5) * rhythmProfile.humanization.timing;
      const velocity = (1 - rhythmProfile.humanization.velocity) + (random() * rhythmProfile.humanization.velocity);

      // Kick
      const kickIdx = i % spec.kickPattern.length;
      if (spec.kickPattern[kickIdx] && random() > 0.1) {
        patterns.kick.push({ time, velocity: velocity * 0.9, humanize });
      }

      // Snare
      const snareIdx = i % spec.snarePattern.length;
      if (spec.snarePattern[snareIdx] && random() > 0.05) {
        patterns.snare.push({ time, velocity: velocity * 0.8, humanize });
      }

      // Hi-hat
      const hhChance = spec.hihatDensity === 'very-high' ? 0.9 :
        spec.hihatDensity === 'high' ? 0.7 :
        spec.hihatDensity === 'medium' ? 0.5 : 0.3;
      if (i % 2 === 0 || random() < hhChance * 0.6) {
        patterns.hihat.push({
          time,
          velocity: velocity * 0.4,
          roll: spec.hihatDensity.includes('high') && i % 4 === 3 && random() < 0.2,
          humanize: humanize * 0.5
        });
      }
    }
  }
  return patterns;
};


// ===================================================================================
// SECTION 4: HARMONY & MELODY ENGINE
// ===================================================================================

/**
 * A library of 4-bar chord progressions inspired by specific producers.
 */
export const PRODUCER_PROGRESSIONS = {
  "Timbaland": [
    { id: "tim_1", name: "Dark syncopation (minor vamp)", key: "C minor", roman: ["i", "bVI", "bIII", "bVII"], schedule: [{ time: "0:0:0", chord: "Cm7", duration: "1m" }, { time: "1:0:0", chord: "Abmaj7", duration: "1m" }, { time: "2:0:0", chord: "Ebmaj7", duration: "1m" }, { time: "3:0:0", chord: "Bb7", duration: "1m" }], notes: "Sparse pads, syncopated vocal chops – good for stuttered rhythms." },
    { id: "tim_2", name: "Chromatic stutter", key: "C minor", roman: ["i", "bII", "i", "v"], schedule: [{ time: "0:0:0", chord: "Cm9", duration: "1m" }, { time: "1:0:0", chord: "Dbmaj7(#11)", duration: "1m" }, { time: "2:0:0", chord: "Cm9", duration: "1m" }, { time: "3:0:0", chord: "Gm7", duration: "1m"}], notes: "Use heavy rhythmic gating and vocal chops; tension on bar 2." },
  ],
  "DJ Quik": [
      { id: "quik_1", name: "G-Funk classic 1", key: "C minor", roman: ["i", "bVII", "bVI", "V7"], schedule: [{ time: "0:0:0", chord: "Cm7", duration: "1m" }, { time: "1:0:0", chord: "Bb7", duration: "1m" }, { time: "2:0:0", chord: "Abmaj7", duration: "1m" }, { time: "3:0:0", chord: "G7", duration: "1m" }], notes: "Classic Quik / West Coast movement; wah-key comping fits well." },
      { id: "quik_2", name: "Sevenths funk vamp", key: "C minor", roman: ["i7", "iv7", "bVII7", "bVI7"], schedule: [{ time: "0:0:0", chord: "Cm7", duration: "1m" }, { time: "1:0:0", chord: "Fm7", duration: "1m" }, { time: "2:0:0", chord: "Bb7", duration: "1m" }, { time: "3:0:0", chord: "Ab7", duration: "1m" }], notes: "Use wah and clean guitar licks; strong for horn stabs." },
  ],
  "Zaytoven": [
      { id: "zay_1", name: "Piano-led trap minor vamp", key: "A minor", roman: ["i", "v", "iv", "i"], schedule: [{ time: "0:0:0", chord: "Am7", duration: "1m" }, { time: "1:0:0", chord: "Em7", duration: "1m" }, { time: "2:0:0", chord: "Dm7", duration: "1m" }, { time: "3:0:0", chord: "Am7", duration: "1m" }], notes: "Simple piano comping with heavy 808 slides - Zay staple." },
  ],
  "Just Blaze": [
      { id: "jb_1", name: "Soul sample major loop", key: "C major", roman: ["I", "vi", "IV", "V"], schedule: [{ time: "0:0:0", chord: "Cmaj7", duration: "1m" }, { time: "1:0:0", chord: "Am7", duration: "1m" }, { time: "2:0:0", chord: "Fmaj7", duration: "1m" }, { time: "3:0:0", chord: "G7", duration: "1m" }], notes: "Big soulful progressions; stack strings and horns for drama." },
  ],
  "Missy Elliott": [
      { id: "missy_1", name: "Glitchy minor loop", key: "C minor", roman: ["i", "bVI", "iv", "i"], schedule: [{ time: "0:0:0", chord: "Cm7", duration: "1m" }, { time: "1:0:0", chord: "Abmaj7", duration: "1m" }, { time: "2:0:0", chord: "Fm7", duration: "1m" }, { time: "3:0:0", chord: "Cm7", duration: "1m" }], notes: "Layer with vocal chops, reverse fx and stutters." },
  ],
  "Dr. Dre": [
      { id: "dre_1", name: "G-Funk classic (minor)", key: "C minor", roman: ["i", "bVII", "bVI", "V"], schedule: [{ time: "0:0:0", chord: "Cm7", duration: "1m" }, { time: "1:0:0", chord: "Bb7", duration: "1m" }, { time: "2:0:0", chord: "Abmaj7", duration: "1m" }, { time: "3:0:0", chord: "G7", duration: "1m" }], notes: "Synth leads and talkbox fit perfectly; focus on groove pocket." },
  ],
  "J Dilla": [
      { id: "dilla_1", name: "Jazzy loop (Dilla swing)", key: "C minor", roman: ["i", "iv", "bVII", "bIII"], schedule: [{ time: "0:0:0", chord: "Cm9", duration: "1m" }, { time: "1:0:0", chord: "Fm9", duration: "1m" }, { time: "2:0:0", chord: "Bb13", duration: "1m" }, { time: "3:0:0", chord: "Ebmaj9", duration: "1m" }], notes: "Dusty samples, swung quantization – J Dilla-friendly." },
  ],
  "Kanye West": [
      { id: "kanye_1", name: "Soul sample progression", key: "C major", roman: ["I", "vi", "IV", "V"], schedule: [{ time: "0:0:0", chord: "Cmaj7", duration: "1m" }, { time: "1:0:0", chord: "Am7", duration: "1m" }, { time: "2:0:0", chord: "Fmaj7", duration: "1m" }, { time: "3:0:0", chord: "G7", duration: "1m" }], notes: "Sample flipping and vocal chops – classic Kanye template." },
  ],
  "No I.D.": [
     { id: "noid_1", name: "Warm soul progression", key: "C major", roman: ["I", "vi", "ii", "V"], schedule: [{ time: "0:0:0", chord: "Cmaj7", duration: "1m" }, { time: "1:0:0", chord: "Am7", duration: "1m" }, { time: "2:0:0", chord: "Dm7", duration: "1m" }, { time: "3:0:0", chord: "G7", duration: "1m" }], notes: "Sample-based soul chords with warm saturation." },
  ]
};

/**
 * A library of 4-bar chord progressions for various musical genres.
 */
export const GENRE_PROGRESSIONS = {
    "Trap": [
        { id: "trap_1", name: "Classic trap minor loop", key: "A minor", roman: ["i", "bVI", "bIII", "bVII"], schedule: [{ time: "0:0:0", chord: "Am7", duration: "1m" }, { time: "1:0:0", chord: "Fmaj7", duration: "1m" }, { time: "2:0:0", chord: "Cmaj7", duration: "1m" }, { time: "3:0:0", chord: "G7", duration: "1m" }], notes: "808s and sparse hi-hats; pitch slides on 808s recommended." },
    ],
    "Drill": [
        { id: "drill_1", name: "Dark slide vamp", key: "C minor", roman: ["i", "bIII", "bVI", "bVII"], schedule: [{ time: "0:0:0", chord: "Cm7", duration: "1m" }, { time: "1:0:0", chord: "Ebmaj7", duration: "1m" }, { time: "2:0:0", chord: "Abmaj7", duration: "1m" }, { time: "3:0:0", chord: "Bb7", duration: "1m" }], notes: "Slide-heavy 808s and aggressive hi-hat rolls." },
    ],
    "R&B": [
        { id: "rnb_1", name: "Classic R&B 1", key: "C major", roman: ["ii", "V", "I", "vi"], schedule: [{ time: "0:0:0", chord: "Dm9", duration: "1m" }, { time: "1:0:0", chord: "G13", duration: "1m" }, { time: "2:0:0", chord: "Cmaj9", duration: "1m" }, { time: "3:0:0", chord: "Am9", duration: "1m" }], notes: "Extended chords and intimate vocal harmonies." },
    ],
    "Soul": [
        { id: "soul_1", name: "Motown classic", key: "C major", roman: ["I", "vi", "IV", "V"], schedule: [{ time: "0:0:0", chord: "Cmaj7", duration: "1m" }, { time: "1:0:0", chord: "Am7", duration: "1m" }, { time: "2:0:0", chord: "Fmaj7", duration: "1m" }, { time: "3:0:0", chord: "G7", duration: "1m" }], notes: "Classic soul voicings with horn accents." },
    ],
    "Emo Trap": [
        { id: "emotrap_1", name: "Nostalgic Heartbreak", key: "C#m", roman: ["i", "VI", "VII", "V"], schedule: [{ time: "0:0:0", chord: "C#m", duration: "1m" }, { time: "1:0:0", chord: "A", duration: "1m" }, { time: "2:0:0", chord: "B", duration: "1m" }, { time: "3:0:0", chord: "G#7", duration: "1m" }], notes: "Feels 'stuck', mirroring lyrical themes of emotional cycles." },
    ],
    "UK Drill": [
        { id: "ukdrill_1", name: "Menacing Loop", key: "C#m", roman: ["i", "bVII", "bVI", "bVII"], schedule: [{ time: "0:0:0", chord: "C#m", duration: "1