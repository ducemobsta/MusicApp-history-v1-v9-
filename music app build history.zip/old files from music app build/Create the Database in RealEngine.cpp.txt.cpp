// In RealEngine.cpp

// Define this at the top with your other static const maps
const std::map<std::string, GenreProfile> GENRE_DB = {
    {"Trap", {
        "Trap",
        {
            {"i", "v", "bVI", "bVII"},      // The classic trap progression
            {"i", "iv", "v", "i"},         // A more minor-key focused one
            {"i", "bIII", "bVII", "iv"}    // Moody and atmospheric
        }
    }},
    {"Neo-Soul", {
        "Neo-Soul",
        {
            {"i7", "iv7", "v7", "i7"},
            {"ii7", "V7", "Imaj7", "IVmaj7"}, // More major/jazzy feel
            {"i7", "bVI7", "iv7", "bVII7"}
        }
    }},
    // Add more genres...
    {"Lo-fi", { /* ... */ }},
    {"R&B", { /* ... */ }}
};