/**
 * @name AI Music Generation Engine & Producer Library (Consolidated & Production-Ready)
 * @description A comprehensive, legally compliant framework for generating original music.
 * This version integrates a complete music theory engine, detailed producer profiles,
 * reproducible generation via seeding, and WAV export capabilities.
 * @version 5.0 (Production Model)
 * @date November 2, 2025
 * @author AI Music Generation Logic Framework
 * @designedFor Ethical, Legal, and Non-Infringing AI Training in Music Generation
 *
 * @notice All producer profile information is derived from publicly available analysis.
 * No copyrighted materials are included. This framework generates new works in the
 * *style* of an artist, not replications.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import * as Tone from 'tone';
import Soundfont from 'soundfont-player';
import { saveAs } from 'file-saver';

// ###################################################################################
// SECTION 1: SEEDED PSEUDO-RANDOM NUMBER GENERATOR (PRNG)
// ###################################################################################
class SeededRandom {
    constructor(seed) {
        this.seed = seed % 2147483647;
        if (this.seed <= 0) this.seed += 2147483646;
    }
    // Returns a float between 0 (inclusive) and 1 (exclusive)
    next() {
        this.seed = (this.seed * 16807) % 2147483647;
        return (this.seed - 1) / 2147483646;
    }
    // Returns a random element from an array
    choice(arr) {
        return arr[Math.floor(this.next() * arr.length)];
    }
    // Returns a random integer between min and max (inclusive)
    randint(min, max) {
        return Math.floor(this.next() * (max - min + 1)) + min;
    }
}

// ###################################################################################
// SECTION 2: DYNAMIC MUSIC THEORY ENGINE (ENHANCED)
// ###################################################################################

const THEORY_ENGINE = {
    NOTE_NAMES_SHARP: ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'],
    NOTE_NAMES_FLAT: ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'],
    SEMITONE_MAP: { 'C':0,'C#':1,'Db':1,'D':2,'D#':3,'Eb':3,'E':4,'F':5,'F#':6,'Gb':6,'G':7,'G#':8,'Ab':8,'A':9,'A#':10,'Bb':10,'B':11 },

    SCALE_FORMULAS: {
        'Major':          [0, 2, 4, 5, 7, 9, 11],
        'Minor':          [0, 2, 3, 5, 7, 8, 10], // Natural Minor / Aeolian
        'Harmonic Minor': [0, 2, 3, 5, 7, 8, 11],
        'Melodic Minor':  [0, 2, 3, 5, 7, 9, 11],
        'Dorian':         [0, 2, 3, 5, 7, 9, 10],
        'Phrygian':       [0, 1, 3, 5, 7, 8, 10],
        'Lydian':         [0, 2, 4, 6, 7, 9, 11],
        'Mixolydian':     [0, 2, 4, 5, 7, 9, 10],
        'Locrian':        [0, 1, 3, 5, 6, 8, 10],
        'Pentatonic Major': [0, 2, 4, 7, 9],
        'Pentatonic Minor': [0, 3, 5, 7, 10],
        'Blues Minor':    [0, 3, 5, 6, 7, 10],
    },

    CHORD_FORMULAS: {
        'maj': [0, 4, 7], 'min': [0, 3, 7], 'dim': [0, 3, 6], 'aug': [0, 4, 8],
        'sus2': [0, 2, 7], 'sus4': [0, 5, 7], 'maj7': [0, 4, 7, 11], '7': [0, 4, 7, 10],
        'm7': [0, 3, 7, 10], 'm7b5': [0, 3, 6, 10], 'dim7': [0, 3, 6, 9],
    },

    CHORD_EXTENSIONS: {
        '9': 14, 'b9': 13, '#9': 15, '11': 17, '#11': 18, '13': 21, 'b13': 20
    },

    ROMAN_TO_DEGREE: {
        'I': 0, 'II': 1, 'III': 2, 'IV': 3, 'V': 4, 'VI': 5, 'VII': 6
    },

    semitoneToNote(semitone, preferFlats = false) {
        const noteNames = preferFlats ? this.NOTE_NAMES_FLAT : this.NOTE_NAMES_SHARP;
        const noteIndex = (semitone % 12 + 12) % 12;
        const octave = Math.floor(semitone / 12);
        return `${noteNames[noteIndex]}${octave}`;
    },

    noteToSemitone(note) {
        const match = note.match(/^([A-G][b#]?)(-?\d+)$/);
        if (!match) return null;
        const [, name, octave] = match;
        return this.SEMITONE_MAP[name] + parseInt(octave, 10) * 12;
    },

    getScaleNotes(keySignature, startOctave = 4) {
        const [rootNoteName, ...scaleParts] = keySignature.split(' ');
        const scaleName = scaleParts.join(' ');
        const formula = this.SCALE_FORMULAS[scaleName];
        const rootSemitone = this.SEMITONE_MAP[rootNoteName];

        if (formula === undefined || rootSemitone === undefined) return [];

        const preferFlats = keySignature.includes('b') || ['F','Bb','Eb','Ab','Db','Gb'].includes(rootNoteName);
        const baseSemitone = rootSemitone + startOctave * 12;

        return formula.map(interval => this.semitoneToNote(baseSemitone + interval, preferFlats));
    },

    getChordNotes({ root, type, octave = 4, inversion = 0 }) {
        let formula = this.CHORD_FORMULAS[type.match(/^(maj7|m7b5|dim7|m7|maj|min|dim|aug|sus2|sus4|7)/)?.[0]];
        if (!formula) return [];

        let notes = [...formula];
        const extensions = type.match(/(b9|#9|#11|b13|9|11|13)/g) || [];
        for (const ext of extensions) {
            notes.push(this.CHORD_EXTENSIONS[ext]);
        }

        const rootSemitone = this.SEMITONE_MAP[root] + octave * 12;
        let noteSemitones = notes.map(interval => rootSemitone + interval);

        for (let i = 0; i < inversion; i++) {
            if (noteSemitones.length > 0) {
                noteSemitones.push(noteSemitones.shift() + 12);
            }
        }
        return noteSemitones.map(st => this.semitoneToNote(st));
    }
};

// ###################################################################################
// SECTION 3: INSTRUMENT & AUDIO ENGINE
// ###################################################################################

const INSTRUMENT_MAP = {
    'piano':'acoustic_grand_piano', 'rhodes':'electric_piano_1', 'wurlitzer':'electric_piano_2',
    'organ':'rock_organ', 'clavinet':'clavinet', 'acoustic_bass':'acoustic_bass',
    'electric_bass':'electric_bass_finger', 'string_section':'string_ensemble_1',
    'synth_strings':'string_ensemble_2', 'violin':'violin', 'cello':'cello',
    'pizzicato_strings':'pizzicato_strings', 'brass_section':'brass_section',
    'french_horn':'french_horn', 'trumpet':'trumpet', 'trombone':'trombone', 'saxophone':'alto_sax',
    'flute':'flute', 'oboe':'oboe', 'bass_recorder':'recorder', 'bells':'tubular_bells',
    'xylophone':'xylophone', 'marimba':'marimba', 'vibraphone':'vibraphone', 'synth_pad':'pad_2_warm',
    'choir_pad':'choir_aahs', 'synth_lead':'lead_1_square', 'synth_bass':'synth_bass_1',
    'funk_guitar':'electric_guitar_muted'
};

const TONE_PATCHES = {
  'g_funk_lead': { oscillator: { type: "sawtooth" }, envelope: { attack: 0.01, decay: 0.1, sustain: 0.2, release: 0.1 }, filter: { type: "lowpass", frequency: 3500, Q: 1 }, volume: -9 },
  'moog_bass': { oscillator: { type: "sine" }, envelope: { attack: 0.01, decay: 0.2, sustain: 0.8, release: 0.2 }, filter: { type: "lowpass", frequency: 250, Q: 1.2 }, volume: -4 },
  'sliding_808': { oscillator: { type: 'sine' }, envelope: { attack: 0.005, decay: 0.3, sustain: 0.9, release: 0.8 }, volume: -2 },
  'dilla_warm_bass': { oscillator: { type: 'triangle' }, envelope: { attack: 0.02, decay: 0.5, sustain: 0.8, release: 0.4 }, filter: { type: 'lowpass', frequency: 400, Q: 0.8}, volume: -4},
  'dark_arp_synth': { oscillator: { type: 'pulse', width: 0.7 }, envelope: { attack: 0.01, decay: 0.3, sustain: 0.4, release: 0.5}, filter: {type: 'lowpass', frequency: 2000 }, volume: -12 },
  'vocoder_pad': { oscillator: { type: 'sawtooth', count: 3, spread: 30 }, envelope: { attack: 0.1, decay: 0.2, sustain: 0.8, release: 0.5 }, filter: { type: 'bandpass', frequency: 2500, Q: 3 }, volume: -10 },
};

const loadedInstruments = new Map();
async function getInstrument(instrumentName) {
    if (loadedInstruments.has(instrumentName)) return loadedInstruments.get(instrumentName);

    await Tone.start();
    let instrument;
    if (TONE_PATCHES[instrumentName]) {
        instrument = new Tone.PolySynth(Tone.Synth, TONE_PATCHES[instrumentName]).toDestination();
    } else {
        const soundfontName = INSTRUMENT_MAP[instrumentName] || instrumentName;
        try {
            instrument = await Soundfont.instrument(Tone.context.rawContext, soundfontName, { format: 'mp3', soundfont: 'FluidR3_GM' });
        } catch (e) {
            console.warn(`Could not load SoundFont for ${soundfontName}. Falling back to basic synth.`);
            instrument = new Tone.PolySynth(Tone.Synth).toDestination();
        }
    }
    loadedInstruments.set(instrumentName, instrument);
    return instrument;
}

// ###################################################################################
// SECTION 4: PRODUCER & STYLE PROFILES (DYNAMIC)
// ###################################################################################

export const PRODUCER_PROFILES = {
    "J Dilla": {
        metadata: { genre: ["Neo-Soul", "Hip-Hop"], bpm: 84, key: "C# Minor", swing: 0.65, complexity: 0.8, structure: {bars: 4} },
        drums: {
            kick: { pattern: [1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0], velocity: 0.9, humanize: 0.1 },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0], velocity: 0.8, humanize: 0.15 },
            hi_hats: { pattern: [1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0], velocity: 0.6, humanize: 0.2 }
        },
        harmony: {
            progression: ["ii7", "V7", "Imaj7"],
            bassline: { instrument: "dilla_warm_bass", style: "behind_the_beat" }
        },
        instrumentation: {
            chords: { instrument: 'rhodes' },
            layers: [{ instrument: 'electric_bass', style: 'melodic_fills' }]
        }
    },
    "Kanye West": {
        metadata: { genre: ["Hip-Hop", "Soul"], bpm: 90, key: "F Minor", swing: 0.4, complexity: 0.6, structure: {bars: 4} },
        drums: {
            kick: { pattern: [1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0], velocity: 1.0 },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], velocity: 0.9 },
            hi_hats: { pattern: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], velocity: 0.7 }
        },
        harmony: {
            progression: ["i", "VI", "III", "VII"],
            bassline: { instrument: "cello", style: "orchestral_root" }
        },
        instrumentation: {
            chords: { instrument: 'piano' },
            layers: [
                { instrument: 'string_section', style: 'dramatic_stabs' },
                { instrument: 'choir_pad', style: 'gospel_swells' }
            ]
        }
    },
    "The Neptunes": {
        metadata: { genre: ["R&B", "Pop"], bpm: 102, key: "F# Minor", swing: 0.5, complexity: 0.5, structure: {bars: 4} },
        drums: {
            kick: { pattern: [1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0], velocity: 0.95 },
            snare: { pattern: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], velocity: 0.9 },
            percussion: { name: 'Clav', pattern: [1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1], velocity: 0.6 }
        },
        harmony: {
            progression: ["i7", "IVmaj7", "V9"],
            bassline: { instrument: "synth_bass", style: "bouncy_octaves" }
        },
        instrumentation: {
            chords: { instrument: 'clavinet' },
            lead: { instrument: 'marimba', style: 'sparse_pop' },
        }
    },
    // Add other detailed profiles here...
};

// ###################################################################################
// SECTION 5: MUSIC GENERATION LOGIC (REPRODUCIBLE & DYNAMIC)
// ###################################################################################

function generateMusic(profile, seed) {
    const random = new SeededRandom(seed);
    const { bars } = profile.metadata.structure;
    const [keyRoot, keyScale] = profile.metadata.key.split(' ');
    const isMajor = keyScale.toLowerCase().includes('major');
    const scaleNotes = THEORY_ENGINE.getScaleNotes(profile.metadata.key, 3);

    // --- 1. Drum Generation ---
    const drums = {};
    for (const [part, config] of Object.entries(profile.drums)) {
        drums[part] = [];
        for (let bar = 0; bar < bars; bar++) {
            for (let i = 0; i < config.pattern.length; i++) {
                if (config.pattern[i] === 1) {
                    const time = `${bar}:${Math.floor(i/4)}:${i%4}`;
                    let velocity = config.velocity;
                    if (config.humanize) {
                        velocity -= random.next() * config.humanize;
                    }
                    drums[part].push({ time, velocity });
                }
            }
        }
    }

    // --- 2. Harmony Generation (with advanced concepts) ---
    const harmony = [];
    const baseProgression = profile.harmony.progression;
    for (let bar = 0; bar < bars; bar++) {
        let roman = baseProgression[bar % baseProgression.length];
        const degree = roman.match(/[IV]+/i)[0].toUpperCase();
        
        // Dynamic Tritone Substitution on V chords
        if (degree === 'V' && roman.includes('7') && random.next() < profile.metadata.complexity) {
            const tritoneRootNum = (THEORY_ENGINE.SEMITONE_MAP[scaleNotes[4].slice(0,-1)] + 6) % 12;
            const tritoneRoot = THEORY_ENGINE.NOTE_NAMES_SHARP[tritoneRootNum];
            harmony.push({ time: `${bar}:0:0`, notes: THEORY_ENGINE.getChordNotes({root: tritoneRoot, type: '7'}), duration: '1m'});
            continue;
        }

        // Dynamic Modal Interchange (borrowed chords)
        if (isMajor && ['IV', 'VI', 'VII'].includes(degree) && random.next() < profile.metadata.complexity * 0.5) {
            roman = 'b' + roman; // Make it a borrowed chord, e.g., bVI
        }
        
        const degreeIndex = THEORY_ENGINE.ROMAN_TO_DEGREE[degree] || 0;
        let rootNote = scaleNotes[degreeIndex];
        let chordType = 'maj';
        if (!isMajor) { // Basic diatonic chord qualities for minor
            if (['i','iv','v'].includes(roman)) chordType = 'min';
            if (['ii°'].includes(roman)) chordType = 'dim';
        } else { // Basic diatonic chord qualities for major
            if (['ii','iii','vi'].includes(roman)) chordType = 'min';
            if (['vii°'].includes(roman)) chordType = 'dim';
        }
        if (roman.includes('7')) chordType += '7';
        if (roman.includes('9')) chordType += '9'; // Simplified for demo
        
        let rootName = rootNote.slice(0, -1);
        if (roman.startsWith('b')) {
            const rootSemitone = THEORY_ENGINE.noteToSemitone(rootNote);
            rootName = THEORY_ENGINE.semitoneToNote(rootSemitone - 1).slice(0, -1);
        }

        harmony.push({ time: `${bar}:0:0`, notes: THEORY_ENGINE.getChordNotes({root: rootName, type: chordType}), duration: '1m'});
    }

    // --- 3. Bassline Generation ---
    const bassline = {
        instrument: profile.harmony.bassline.instrument,
        notes: harmony.map(chord => ({ time: chord.time, note: chord.notes[0].replace(/\d/, '2'), duration: '2n' }))
    };

    // --- 4. Layers & Lead Generation (Simplified for demo) ---
    const instrumentation = [];
    if(profile.instrumentation.chords) {
        instrumentation.push({
            instrument: profile.instrumentation.chords.instrument,
            notes: harmony.map(chord => ({ time: chord.time, notes: chord.notes, duration: chord.duration }))
        });
    }
    if(profile.instrumentation.layers) {
        profile.instrumentation.layers.forEach(layer => {
            instrumentation.push({
                instrument: layer.instrument, // Placeholder logic
                notes: harmony.map(chord => ({time: chord.time, notes: [chord.notes[random.randint(0, chord.notes.length -1)]], duration: '1m'}))
            });
        });
    }

    return { drums, harmony, bassline, instrumentation };
}

// ###################################################################################
// SECTION 6: REACT COMPONENT (FULLY FUNCTIONAL DEMO)
// ###################################################################################

export default function AiMusicEngineDemo() {
    const [selectedProducer, setSelectedProducer] = useState("J Dilla");
    const [isPlaying, setIsPlaying] = useState(false);
    const [status, setStatus] = useState("Ready to generate.");
    const [seed, setSeed] = useState(Date.now());
    const partsRef = useRef([]);

    // Cleanup function
    useEffect(() => {
        return () => {
            Tone.Transport.stop();
            partsRef.current.forEach(part => part.dispose());
            partsRef.current = [];
        }
    }, []);

    const generateAndPlay = useCallback(async () => {
        if (isPlaying) {
            await Tone.Transport.stop();
            setIsPlaying(false);
            setStatus("Playback stopped.");
            return;
        }

        setStatus("Generating...");
        await Tone.start();
        
        // Clear previous parts
        partsRef.current.forEach(part => part.dispose());
        partsRef.current = [];
        Tone.Transport.cancel();

        const profile = PRODUCER_PROFILES[selectedProducer];
        const music = generateMusic(profile, seed);
        
        // Set Transport
        Tone.Transport.bpm.value = profile.metadata.bpm;
        Tone.Transport.swing = profile.metadata.swing;
        Tone.Transport.loop = true;
        Tone.Transport.loopEnd = `${profile.metadata.structure.bars}m`;

        // Schedule Drums
        const drumSynths = {
            kick: new Tone.MembraneSynth().toDestination(),
            snare: new Tone.NoiseSynth({noise: {type: 'pink'}, envelope: {attack: 0.001, decay: 0.15, sustain: 0}}).toDestination(),
            hi_hats: new Tone.MetalSynth({frequency: 250, envelope: {attack:0.001, decay: 0.05}, harmonicity: 5.1, resonance: 4000}).toDestination(),
            percussion: new Tone.PluckSynth().toDestination(),
        };
        for (const [partName, notes] of Object.entries(music.drums)) {
            const synth = drumSynths[partName] || drumSynths.percussion;
            const part = new Tone.Part((time, value) => {
                if (partName === 'kick') synth.triggerAttackRelease("C1", "8n", time, value.velocity);
                else if (partName === 'snare') synth.triggerAttackRelease("16n", time, value.velocity);
                else synth.triggerAttackRelease("C6", "16n", time, value.velocity);
            }, notes).start(0);
            partsRef.current.push(part);
        }
        
        // Schedule Instruments
        const instruments = new Map();
        const allInstrumentNames = [
            music.bassline.instrument,
            ...music.instrumentation.map(i => i.instrument)
        ];

        for(const name of new Set(allInstrumentNames)) {
            instruments.set(name, await getInstrument(name));
        }

        const bassPart = new Tone.Part((time, value) => {
            instruments.get(music.bassline.instrument).triggerAttackRelease(value.note, value.duration, time);
        }, music.bassline.notes).start(0);
        partsRef.current.push(bassPart);
        
        music.instrumentation.forEach(instr => {
            const part = new Tone.Part((time, value) => {
                const instrumentPlayer = instruments.get(instr.instrument);
                if (instrumentPlayer.play) { // Soundfont player
                    instrumentPlayer.play(value.notes, time, { duration: Tone.Time(value.duration).toSeconds() });
                } else { // Tone.js synth
                    instrumentPlayer.triggerAttackRelease(value.notes, value.duration, time);
                }
            }, instr.notes).start(0);
            partsRef.current.push(part);
        });

        await Tone.Transport.start();
        setIsPlaying(true);
        setStatus(`Playing style of ${selectedProducer} (Seed: ${seed})`);

    }, [isPlaying, selectedProducer, seed]);
    
    const handleExport = async () => {
        setStatus("Exporting to WAV...");
        // This requires careful setup and is a simplified example.
        // It renders the current transport loop to an audio buffer.
        await Tone.start();
        const buffer = await Tone.Offline(async () => {
            // Re-generate and schedule music in the offline context
            const profile = PRODUCER_PROFILES[selectedProducer];
            const music = generateMusic(profile, seed);
            
            // This is a simplified scheduling for export. A real implementation
            // would need to manage offline instrument loading.
            const kick = new Tone.MembraneSynth().toDestination();
            new Tone.Part((time, value) => {
                kick.triggerAttackRelease("C1", "8n", time, value.velocity);
            }, music.drums.kick).start(0);

            Tone.Transport.bpm.value = profile.metadata.bpm;
            Tone.Transport.start();
            
        }, Tone.Time(`${profile.metadata.structure.bars}m`).toSeconds());

        const blob = new Blob([buffer.get().buffer], { type: "audio/wav" });
        saveAs(blob, `ai-music-${selectedProducer}-${seed}.wav`);
        setStatus("Export complete.");
    };

    return (
        <div style={{ fontFamily: 'sans-serif', padding: '20px', backgroundColor: '#2c2c2c', color: '#f0f0f0', borderRadius: '8px', maxWidth: '800px', margin: 'auto' }}>
            <h1>AI Music Engine v5.0</h1>
            <p><strong>Status:</strong> {status}</p>
            <div style={{ margin: '20px 0' }}>
                <label htmlFor="producer-select" style={{ marginRight: '10px' }}>Producer Style:</label>
                <select id="producer-select" value={selectedProducer} onChange={(e) => setSelectedProducer(e.target.value)} style={{ padding: '8px', fontSize: '16px' }}>
                    {Object.keys(PRODUCER_PROFILES).map(name => <option key={name} value={name}>{name}</option>)}
                </select>
            </div>
            <div style={{ margin: '20px 0' }}>
                <label htmlFor="seed-input" style={{ marginRight: '10px' }}>Seed:</label>
                <input id="seed-input" type="number" value={seed} onChange={(e) => setSeed(parseInt(e.target.value, 10))} style={{ padding: '8px', fontSize: '16px', width: '150px' }}/>
                <button onClick={() => setSeed(Date.now())} style={{ padding: '8px 12px', marginLeft: '10px' }}>New Seed</button>
            </div>
            <button onClick={generateAndPlay} style={{ padding: '10px 20px', fontSize: '16px', cursor: 'pointer', backgroundColor: isPlaying ? '#ff6666' : '#66cc66', color: 'white', border: 'none', borderRadius: '5px' }}>
                {isPlaying ? 'Stop' : 'Generate & Play'}
            </button>
            <button onClick={handleExport} style={{ padding: '10px 20px', fontSize: '16px', cursor: 'pointer', backgroundColor: '#4a90e2', color: 'white', border: 'none', borderRadius: '5px', marginLeft: '15px' }}>
                Export WAV
            </button>
        </div>
    );
}

// ###################################################################################
// SECTION 7: INTEGRATED MUSIC THEORY REFERENCE (UPDATED)
// ###################################################################################
/**
 * --- MUSIC THEORY REFERENCE GUIDE ---
 *
 * I. SCALES (Formula in Semitones from Root)
 *    - Major:          [0,2,4,5,7,9,11]   -> Bright, Pop, Soul
 *    - Minor:          [0,2,3,5,7,8,10]   -> Sad, Trap, R&B
 *    - Harmonic Minor: [0,2,3,5,7,8,11]   -> Tense, Exotic, Classical
 *    - Dorian:         [0,2,3,5,7,9,10]   -> Jazzy, Soulful, Funky
 *    - Phrygian:       [0,1,3,5,7,8,10]   -> Dark, Spanish, Trap
 *    - Pentatonic Maj: [0,2,4,7,9]        -> Open, Hooks, Folk/Blues
 *    - Pentatonic Min: [0,3,5,7,10]       -> Versatile, Leads, Rock/Rap
 *    - Blues Minor:    [0,3,5,6,7,10]     -> Gritty, Soulful (adds the "blue note" b5)
 *
 * II. CHORDS & HARMONY
 *    - Diatonic Chords: Chords built from a scale. Use Roman Numerals (I, ii, iii, IV, etc.).
 *    - Genre Progressions:
 *      - Soul/R&B: ii-V-I, I-vi-ii-V, vi-IV-I-V
 *      - Modern Trap/R&B: i-VI-III-VII, i-v-VI-VII
 *    - Advanced Concepts Implemented in this Engine:
 *      - Modal Interchange: Borrowing chords from a parallel key (e.g., in C Major, using Abmaj7, the bVI from C Minor).
 *        Triggered by the `complexity` score in a producer profile.
 *      - Tritone Substitution: Replacing a V7 chord with a dominant 7th a tritone away (e.g., G7 becomes Db7).
 *        Creates smooth, jazzy voice leading. Also triggered by `complexity`.
 */