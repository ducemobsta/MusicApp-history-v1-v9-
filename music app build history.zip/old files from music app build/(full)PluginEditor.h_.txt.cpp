#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"

class MusicGeneratorVSTAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit MusicGeneratorVSTAudioProcessorEditor(MusicGeneratorVSTAudioProcessor&);
    ~MusicGeneratorVSTAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    MusicGeneratorVSTAudioProcessor& processor;

    // --- UI Components ---
    juce::TextEditor promptEditor;
    juce::TextButton generateButton{ "Generate Music" };
    juce::Label statusLabel;
    juce::Label titleLabel;

    // --- Helper to format the prompt ---
    juce::String formatPromptForAI(const juce::String& userInput);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MusicGeneratorVSTAudioProcessorEditor)
};