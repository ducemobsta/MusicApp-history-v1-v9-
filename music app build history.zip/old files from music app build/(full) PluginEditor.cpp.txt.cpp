#include "PluginProcessor.h"
#include "PluginEditor.h"

// ==============================================================================
// --- CONSTRUCTOR & DESTRUCTOR ---
// ==============================================================================
MusicGeneratorVSTAudioProcessorEditor::MusicGeneratorVSTAudioProcessorEditor(MusicGeneratorVSTAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    // --- Title Label ---
    titleLabel.setText("AI Music Assistant", juce::dontSendNotification);
    titleLabel.setFont(juce::Font(22.0f, juce::Font::bold));
    titleLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(titleLabel);

    // --- Prompt Text Editor ---
    promptEditor.setMultiLine(true);
    promptEditor.setReturnKeyStartsNewLine(true);
    promptEditor.setText("A dark, introspective trap beat in A minor, inspired by Metro Boomin.");
    addAndMakeVisible(promptEditor);

    // --- Generate Button ---
    generateButton.onClick = [this]
    {
        // When clicked, format the user's text into a full prompt and send it to the processor.
        auto userRequest = promptEditor.getText();
        if (userRequest.isNotEmpty()) {
            auto fullPrompt = formatPromptForAI(userRequest);
            processor.startAIGeneration(fullPrompt);
            generateButton.setEnabled(false); // Disable button while processing
        }
    };
    addAndMakeVisible(generateButton);

    // --- Status Label ---
    statusLabel.setText("Enter a musical idea and click 'Generate'.", juce::dontSendNotification);
    statusLabel.setJustificationType(juce::Justification::centred);
    addAndMakeVisible(statusLabel);

    // --- Processor Callback ---
    // This is the crucial link from the processor back to the UI.
    // The processor will call this function to update the status label text.
    processor.onStatusChanged = [this](const juce::String& newStatus, bool isError)
    {
        // This lambda will be called on the message thread, so it's safe to update UI here.
        statusLabel.setText(newStatus, juce::dontSendNotification);
        statusLabel.setColour(juce::Label::textColourId, isError ? juce::Colours::red : juce::Colours::white);
        generateButton.setEnabled(true); // Re-enable the button
    };
    
    // Set the size of the editor window
    setSize(500, 350);
}

MusicGeneratorVSTAudioProcessorEditor::~MusicGeneratorVSTAudioProcessorEditor()
{
    // Unset the callback to prevent dangling pointers
    processor.onStatusChanged = nullptr;
}

// ==============================================================================
// --- UI LAYOUT & PAINTING ---
// ==============================================================================
void MusicGeneratorVSTAudioProcessorEditor::paint(juce::Graphics& g)
{
    // Fill the background with a dark gradient
    g.fillAll(juce::Colour(30, 32, 36));
}

void MusicGeneratorVSTAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced(20); // Add some padding

    titleLabel.setBounds(area.removeFromTop(40));
    area.removeFromTop(10); // Spacer
    
    statusLabel.setBounds(area.removeFromBottom(30));
    area.removeFromBottom(10); // Spacer
    
    generateButton.setBounds(area.removeFromBottom(50));
    area.removeFromBottom(10); // Spacer

    promptEditor.setBounds(area);
}

// ==============================================================================
// --- PROMPT FORMATTING HELPER ---
// ==============================================================================
juce::String MusicGeneratorVSTAudioProcessorEditor::formatPromptForAI(const juce::String& userInput)
{
    // This function wraps the user's simple request into the detailed prompt format
    // that the AI model expects.
    juce::String prompt;
    prompt += "You are HarmonyMind, a music theory AI assistant.\n\n";
    prompt += "Task: Generate a chord progression for the following music concept.\n\n";
    prompt += "User Request: " + userInput + "\n\n";
    prompt += "Respond with ONLY a JSON object in this exact format (no markdown, no explanations):\n\n";
    prompt += "{\n";
    prompt += "  \"key\": \"A minor\",\n";
    prompt += "  \"roman\": [\"i\", \"iv\", \"bVII\", \"bIII\"],\n";
    prompt += "  \"tempo\": 85,\n";
    prompt += "  \"mood\": \"dark and introspective\",\n";
    prompt += "  \"description\": \"A brief description of the progression.\"\n";
    prompt += "}\n\n";
    prompt += "Available keys: C major, A minor, G major, E minor, F major, D minor, C# minor, F minor, F# minor, C minor, Eb major, G minor\n\n";
    prompt += "Generate the JSON now:";
    return prompt;
}