import React, a part of the 'react' library, is a popular JavaScript library for building user interfaces. { useState, useEffect } from 'react';
import *'tone';

/******************************************************************************
 *
 * @description A comprehensive, legally compliant framework for training
 * artificial intelligence models to generate original music inspired by the
 * stylistic, structural, and emotional characteristics of influential R&B and
 * rap artists and producers. This file defines the core data structures,
 * stylistic parameters, DSP functions, and component logic for the AI Music
 * Generation App.
 * @version 1.2
 * @date November 1, 2025
 * @author AI Music Generation Logic Framework
 * @designedFor Ethical, Legal, and Non-Infringing AI Training in Music Generation
 *
 ******************************************************************************/

/**
 * @notice All information is derived from publicly available analysis,
 * interviews, music theory, and stylistic observation. No copyrighted
 * lyrics, melodies, or direct samples are included.
 */

// Placeholder helpers (for context, actual logic lives elsewhere)
const STEPS_PER_BAR = 16;
const BARS = 8;
const TOTAL_STEPS = STEPS_PER_BAR * BARS;
const MOCK_DRUM_ARRAY = new Array(TOTAL_STEPS).fill(0);

// 1. DRUM PATTERNS (Rhythm, Swing, Common Hits)
export const DRUM_PATTERNS = {
    "R. Kelly": {
        kick: [
            "Smooth 90s R&B: punchy kick on 1, 3, and & of 2",
            "Gospel Swing: slightly late kicks on 2 and 4, full attack on 1",
            "Pop Crossover: driving 4-on-the-floor in choruses, simple boom-bap in verses"
        ],
        snare: [
            "Sharp, layered snare/clap combo on 2 and 4 (often slightly offset for fullness)",
            "Frequent use of gated reverb or short delay on snare hits",
            "Accentuated rimshots/sidestick patterns during verses"
        ],
        hats: [
            "Tight, closed hi-hats with light shuffle/swing (1/8th or 1/16th)",
            "Minimal, clean, consistent rhythm; focus on groove over complexity"
        ]
    },
    "Organized Noize": {
        kick: [
            "Deep, subby 808 hits, often overlapping and highly resonant",
            "Acoustic kick drum sampled for a 'live' feel, often slightly behind the beat",
            "Emphasis on pocket and syncopation rather than straight rhythm"
        ],
        snare: [
            "Layered acoustic snare and clap/snap combination on 2 and 4",
            "Occasional ghost notes or quick snare rolls (1/32nd) to create texture",
            "Reverb heavy, smoky atmosphere around the primary hit"
        ],
        hats: [
            "Sparse, open hi-hats used as accents on the & of 3 or 4",
            "Closed hats are typically acoustic/crisp, not electronic 808 style"
        ]
    },
    "Cardo Got Wings": {
        kick: [
            "808 Bass Hits: very long, sustained, distorted 808 samples",
            "Frequent use of 808 **slides** (pitch automation across 2-4 steps)",
            "Kicks often fall heavily on the 1st beat of the bar, sparse elsewhere"
        ],
        snare: [
            "Simple, sharp, loud clap/snare sound, almost exclusively on the 3rd beat",
            "Minimal variation; used as an anchor point for the rhythmic chaos of the hats"
        ],
        hats: [
            "Extremely fast, tight 1/32nd and 1/64th hi-hat rolls",
            "Complex, programmed stutter and delay effects on hats (e.g., triplets every 1/4 bar)",
            "Stereo panning automation for movement"
        ]
    }
};

// 2. CHORD PROGRESSIONS (Harmony and Key)
export const CHORD_PROGRESSIONS = {
    "R. Kelly": {
        key: ["Minor keys for ballads (Cm, Fm)", "Major keys for upbeat tracks (Cmaj, Gmaj)"],
        common: [
            "I - vi - ii - V (Classic R&B/Pop)",
            "ii - V - I (Gospel/Soul turnaround, often with 7th/9th extensions)",
            "IV - V - vi - iii (Soaring pop movement)",
            "Tritone substitution leading to the V chord"
        ],
        voicing: [
            "Lush, wide voicings using 7ths and 9ths (Rhodes/Piano)",
            "Smooth voice leading, minimal leaps between chords",
            "Inverted chords for continuous, flowing bassline movement"
        ]
    },
    "Organized Noize": {
        key: ["Minor keys with a blues/jazz feel (Eb minor, G minor)"],
        common: [
            "Diatonic movements using extended chords (e.g., Cmaj9 - Fmaj7)",
            "Use of diminished or altered chords for tension",
            "Simple 4-bar loops that feel harmonically deep due to voicing",
            "Often starting and ending on non-root chords (e.g., starting on the ii or iii)"
        ],
        voicing: [
            "Dark, smoky voicings (Wurlitzer/Rhodes)",
            "Lower register piano chords mixed with high, filtered pads",
            "Heavy reliance on the bassline to provide harmonic context"
        ]
    },
    "Cardo Got Wings": {
        key: ["Atmospheric minor keys (F#m, Bbm)"],
        common: [
            "Simple, modal two-chord vamp (i - VII or i - VI)",
            "Repetitive, melancholic 4-bar or 8-bar loop",
            "A progression that leads nowhere, designed to create a floating/ambient feel"
        ],
        voicing: [
            "Sparse, open voicings (minimal chords, lots of space)",
            "Heavy use of synth pads and arpeggiated motifs",
            "Melody and harmony often blend into a single atmospheric layer"
        ]
    }
};

// 3. INSTRUMENTATION & TEXTURE (Sound Palette)
export const INSTRUMENTATION = {
    "R. Kelly": {
        bass: ["Round, sustained synth bass or clean electric bass, prominent in the mix"],
        keys: ["Yamaha DX7 bell synths, lush M1-style strings, clean acoustic grand piano, Fender Rhodes"],
        lead: ["Sharp synth leads, bright brass samples (Trumpets/Saxes), filtered pads for background"],
        vocals: ["Layered background vocals (choir/gospel feel), complex ad-libs ('Whoa!', 'Yeah!'), spoken interludes"]
    },
    "Organized Noize": {
        bass: ["Live, warm electric bass (often slightly distorted), deep 808s supporting the live bass"],
        keys: ["Vintage sounds: Fender Rhodes, analog synth pads, Hammond B3 organ (with Leslie effect)"],
        lead: ["Flute and saxophone samples, acoustic guitar riffs, muted electric guitar stabs"],
        texture: ["Environmental sounds (rain, vinyl crackle), vocal samples, subtle sound effects"]
    },
    "Cardo Got Wings": {
        bass: ["**The 808 is the bassline** (sub-only, distorted/saturated)"],
        keys: ["Wide, atmospheric synth pads (Juno/CS-80 style), bright digital plucks"],
        lead: ["Minimalist, high-pitch synth leads or bell-like motifs"],
        texture: ["Reverb and delay are key: long decay times on synths and melodies", "Vocal chops/samples heavily processed and filtered for background texture"]
    }
};

// 4. SEQUENCING & ARRANGEMENT TEMPLATES
export const SEQUENCING = {
    "R. Kelly": {
        structure: {
            standard: [
                "Intro (8 bars: establish main chord loop/vocal ad-lib)",
                "Verse 1 (16 bars: drums/bass drop slightly for intimacy)",
                "Pre-Chorus (4 bars: building energy, ascending harmony)",
                "Chorus (8-16 bars: full instrumentation, lead vocal melody)",
                "Verse 2 (16 bars: harmonic variation or subtle instrumentation change)",
                "Bridge (8-16 bars: key change, emotional/vocal climax, drop to piano/vocals)",
                "Chorus (16 bars: full energy, often with gospel backing vocals + driving groove)",
                "Outro (4-8 bars: fade-out with ad-libs, guitar riff, or organ vamp; live feel)"
            ],
            variations: [
                "Extended instrumental break after Verse 2 with guitar or synth solo",
                "A cappella section before final chorus (rhythm drops out)",
                "Call-and-response vocal section in the outro"
            ]
        },
        transitions: {
            verseToChorus: ["Ascending string line + big drum fill", "Vocals hit a higher register"],
            chorusToVerse: ["Drop main kick/snare, keep percussive hi-hat/shaker loop", "Bassline simplifies/drops octaves"],
            bridge: ["Key change or gospel vamp, drop elements then rebuild"]
        },
        dynamics: {
            layering: ["Add strings and brass only in the chorus/bridge", "Remove main drums/bass for a dramatic shift in the bridge"],
            automation: ["Filter organ or Rhodes in bridge section for lift", "Automate reverb depth on vocals for emotional swell"]
        }
    },
    "Organized Noize": {
        structure: {
            standard: [
                "Intro (8-16 bars: establishes main mood/sample, sparse drums)",
                "Verse 1 (16 bars: focus on lyricism, subtle background instrumentation)",
                "Chorus (8-16 bars: full groove, layered vocals, emotional focus)",
                "Verse 2 (16 bars: new background elements, slight rhythm variation)",
                "Bridge / Breakdown (8-16 bars: instrumental jam/band feel, key melodic elements)",
                "Chorus (16 bars: high energy, often with gospel backing vocals)",
                "Outro (4-8 bars: fades out with a live band feel, deep bass, and airy textures)"
            ],
            variations: [
                "Double chorus with gospel backing vocals",
                "Live band break before final hook",
                "Key change modulation on final chorus/outro vamp",
                "Instrumental interlude with live horns/guitar between verses"
            ]
        },
        transitions: {
            verseToChorus: ["Add hand-claps + guitar stabs", "Bass slide into downbeat"],
            chorusToVerse: ["Drop hi-hats, retain percussion groove", "Introduce vocal ad-lib tail leading into verse"],
            bridge: ["Organ swell + live snare fill", "Add gospel chord vamp, then resolve into chorus"]
        },
        dynamics: {
            layering: ["Start organic and sparse, add layers every 4 bars", "Drop bass or drums for emotional breakdowns"],
            automation: ["Filter sweep on the Rhodes/Organ", "Automation on tape saturation/lo-fi plugins for texture"]
        }
    },
    "Cardo Got Wings": {
        structure: {
            standard: [
                "Intro (12-16 bars: long ambient buildup, focused on pads and main melody)",
                "Verse 1 (8-12 bars: minimal percussion, heavy 808 hits, main vocal focus)",
                "Chorus (8 bars: highly repetitive, all elements locked in, simple melody)",
                "Verse 2 (8-12 bars: new hi-hat patterns introduced for variation)",
                "Chorus (8 bars: repeat)",
                "Bridge (4 bars: short melodic switch or dramatic pause/filter effect)",
                "Chorus (8 bars: repeat, often with extra vocal ad-libs)",
                "Outro (8-16 bars: long fade-out, removing elements until only pads and 808 remain)"
            ],
            variations: [
                "Half-time feel in the intro or outro (slower hi-hats)",
                "Instrumental loop section placed after the first chorus",
                "Dramatic, full stop/silence before the last chorus drops back in"
            ]
        },
        transitions: {
            verseToChorus: ["Reverse cymbal or filtered white noise riser", "808 slide pitch automation up to the root note"],
            chorusToVerse: ["Immediate drop of pads/reverb tail used as a link", "Quick, sharp vocal sample drop"],
            bridge: ["Heavy low-pass filter on all instruments, removing high end", "Switch to a different synth patch for 4 bars, then back"]
        },
        dynamics: {
            layering: ["Keep instrumentation consistent across sections; use mixing to create dynamics", "Bring hi-hat rolls in and out to create energy surges"],
            automation: ["Heavy filtering on melodic elements to push them forward or back", "Stereo panning automation on the hi-hats"]
        }
    }
};


const ProducerDsp = () => {

    const [isPlaying, setIsPlaying] = useState(false);

    /******************************************************************************
     *
     * @section A detailed guide for training an AI to generate music in specific
     * styles, focusing on legally compliant, non-infringing emulation of patterns
     * and techniques.
     *
     ******************************************************************************/

    /**
     * @subsection Artist-Focused Generation Logic
     */
    const artistFocusedGenerationLogic = {
        "Beyoncé (R&B / Pop / Soul / Afrobeat Fusion)": {
            "Core Identity": "Blends R&B with soul, pop, and Afrobeat. Known for vocal mastery and themes of empowerment.",
            "AI Generation Parameters": {
                "Vocal Processing": "Apply melisma algorithms (6-12 notes per run); use layered harmonies (3-5 tracks) with slight detuning.",
                "Melodic Structure": "Use Dorian and natural minor modes. Progressions often feature extended 9ths and 11ths (e.g., Am7-D9-Gmaj7).",
                "Rhythmic Elements": "Syncopated 4/4 grooves with triplet subdivisions and Afrobeat hi-hat patterns."
            }
        },
        "Bruno Mars (R&B / Pop / Funk / Soul Revival)": {
            "Core Identity": "70s/80s funk and soul revivalist with high-energy vocals.",
            "AI Generation Parameters": {
                "Vocal Style": "Bright, nasal tone; retro vibrato (3-5 Hz).",
                "Melodic Logic": "Pentatonic-based melodies with blue notes (b3, b7). Use standard pop (I-vi-IV-V) and soul (iv-V-I) turnarounds.",
                "Rhythm": "Tight 16th-note funk guitar \"chanks\"; snare on 2 and 4 with a syncopated kick."
            }
        },
    };

    /**
     * @subsection Producer-Focused Generation Logic
     */
    const producerFocusedGenerationLogic = {
        "DJ Quik (West Coast G-Funk / Jazz Rap)": {
            "Core Identity": "Smooth, melodic, funk-based production with live instrumentation.",
            "AI Beat Generation Logic": {
                "Bassline": "Synth bass with portamento and filter sweeps. Common pattern: Root-5-6-5 (C-G-A-G).",
                "Keys": "Fender Rhodes or Clavinet with phaser; 7th and 9th chord extensions.",
                "Drums": "LinnDrum or SP-1200 style; kick on 1 and 3, snare with reverb."
            }
        },
        "Kanye West (Sample-Based / Emotional Production)": {
            "Core Identity": "Soul, gospel, and rock sampling; choral swells and pitch-shifted vocals.",
            "AI Generation Logic": {
                "Sampling Engine": "AI identifies emotionally rich soul/gospel vocals, applies pitch-shifting (±3 semitones), and uses only fragmented, transformed elements—never full phrases.",
                "Drums": "Early style uses sampled kicks/snares. Later style uses 808s with sidechain compression.",
                "Chord Progressions": "Use of circle of fifths motion (C-G-Dm-A7); extended chords like 7#9 and 13sus."
            }
        },
    };


    /******************************************************************************
     *
     * @section Producer and Artist Presets
     *
     ******************************************************************************/

    const producerPresets = {
        "Pharrell Williams": {
            metadata: {
                genre: ["R&B", "Pop", "Hip-Hop"],
                producer: "Pharrell Williams",
                bpm_range: [90, 110],
                default_bpm: 100,
                key_preference: ["F Minor", "A Minor", "C Major"],
                swing: 0.4
            },
            drums: {
                kick: {
                    sample: "short_punchy_kick.wav",
                    layer: ["sine_sub_60hz.wav"],
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0], // 1 = hit, 0 = rest (1/8th notes)
                    effects: ["saturation:0.3", "compressor:4:1"]
                },
                snare: {
                    sample: "metallic_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.2s", "delay:1/8"]
                },
                hi_hats: {
                    sample: "closed_hats_shimmer.wav",
                    pattern: [1, 1, 1, 1, 1, 1, 1, 1], // 1/8th notes
                    effects: ["highpass:500hz"]
                },
                percussion: {
                    finger_snaps: {
                        sample: "finger_snap.wav",
                        pattern: [0, 1, 0, 1, 0, 1, 0, 1],
                        effects: ["delay:1/16"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "iv", "V"], // e.g., Fm → Bbm → C
                    ["vi", "IV", "I", "V"] // e.g., Dm → Bb → F → C
                ],
                voicings: {
                    preference: ["7ths", "9ths"],
                    example: ["Fm9", "Bbm7", "Cmaj7"]
                },
                bassline: {
                    type: "plucky_funk",
                    waveform: "saw",
                    effects: ["pitch_modulation:0.1hz:2st", "saturation:0.2"]
                }
            },
            instrumentation: {
                synths: ["rhodes.wav", "wurlitzer.wav", "funk_guitar.wav"],
                layers: {
                    pads: ["atmospheric_pad.wav"],
                    leads: ["fm_bell.wav"]
                }
            },
            fx_mixing: {
                global: ["tape_saturation:0.2", "sidechain:kick:-12db"],
                vocals: ["autotune:retune_speed:15ms", "delay:1/8"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Pre-Chorus", "Chorus", "Bridge", "Outro"],
                transitions: ["filter_sweep_up", "drum_fill"]
            }
        },
        "Timbaland": {
            metadata: {
                genre: ["R&B", "Hip-Hop"],
                producer: "Timbaland",
                bpm_range: [95, 115],
                default_bpm: 105,
                key_preference: ["A Minor", "C# Minor", "E Minor"],
                swing: 0.7,
                syncopation: "high"
            },
            drums: {
                kick: {
                    sample: "deep_808_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["saturation:0.6", "compressor:6:1"]
                },
                snare: {
                    sample: "snappy_snare.wav",
                    pattern: [0, 0, 0, 1, 0, 0, 0, 1],
                    rolls: [ // Triplet rolls before downbeat
                        [0, 0.25, 0.5, 0.75], // 1/32nd notes
                        ["16n", "32n", "16n"]
                    ],
                    effects: ["reverb:nonlinear:0.8s", "delay:1/32"]
                },
                hi_hats: {
                    sample: "glitchy_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], // 1/16th notes
                    effects: ["reverse:50%"]
                },
                percussion: {
                    vocal_chops: {
                        sample: ["vocal_hey.wav", "vocal_uh.wav"],
                        pattern: [0, 1, 0, 0, 1, 0, 0, 1],
                        effects: ["pitch_shift:+2st", "filter_sweep"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "bIII", "bVI", "bVII"], // e.g., Am → C → F → G
                    ["i", "bII", "bVI", "bVII"] // e.g., Am → B → F → G
                ],
                voicings: {
                    preference: ["dissonant", "cluster"],
                    example: ["Am(C-E-G)", "C(E-G-B)", "F(A-C-F)"]
                },
                bassline: {
                    type: "sliding_808",
                    waveform: "sine",
                    effects: ["portamento:100ms", "distortion:0.5"]
                }
            },
            instrumentation: {
                synths: ["fm_bell.wav", "dark_pad.wav"],
                vocal_chops: ["hey.wav", "uh.wav", "yo.wav"],
                orchestral_hits: ["string_stab.wav", "brass_hit.wav"]
            },
            fx_mixing: {
                global: ["saturation:0.7", "sidechain:kick:-18db"],
                vocals: ["autotune:retune_speed:5ms", "formant_shift:+1st"],
                drums: ["reverse_reverb:snare"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Breakdown", "Outro"],
                transitions: ["beat_drop", "stutter_edit:8bars"]
            }
        },
        "Zaytoven": {
            metadata: {
                genre: ["Trap", "Drill"],
                producer: "Zaytoven",
                bpm_range: [60, 80],
                default_bpm: 70,
                key_preference: ["C Minor", "F Minor", "G Minor"],
                swing: 0.2,
                half_time_feel: true
            },
            drums: {
                kick: {
                    sample: "aggressive_808.wav",
                    pattern: [1, 0, 0, 0, 0, 0, 1, 0], // Half-time feel
                    effects: ["saturation:0.8", "compressor:8:1"],
                    pitch_up: "5st:50ms" // Rapid pitch-up on attack
                },
                snare: {
                    sample: "crisp_snare.wav",
                    pattern: [0, 0, 0, 1, 0, 0, 0, 0],
                    effects: ["reverb:room:0.5s"]
                },
                hi_hats: {
                    sample: "rolling_hats.wav",
                    pattern: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], // 1/16th rolls
                    flams: true,
                    effects: ["delay:1/32"]
                },
                percussion: {
                    shaker_rattle: {
                        sample: "shaker_rattle.wav",
                        pattern: [0, 1, 0, 1, 0, 1, 0, 1],
                        effects: ["highpass:800hz"]
                    },
                    bongos: {
                        sample: "bongo.wav",
                        pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                        effects: ["saturation:0.4"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "III", "vi", "V"], // e.g., Cm → Eb → Ab → G
                    ["i", "v", "IV", "i"] // e.g., Cm → Gm → Ab → Cm
                ],
                voicings: {
                    preference: ["piano", "wide_intervals"],
                    example: ["Cm(Eb-G-Bb)", "Eb(G-Bb-D)", "Ab(C-Eb-G)"]
                },
                bassline: {
                    type: "sliding_808",
                    waveform: "sine",
                    effects: ["portamento:200ms", "distortion:0.6"]
                }
            },
            instrumentation: {
                piano: {
                    sample: "detuned_piano.wav",
                    effects: ["chorus:0.3", "reverb:hall:1.5s"]
                },
                synths: ["digital_fm_pad.wav"],
                brass: ["trumpet_stab.wav"]
            },
            fx_mixing: {
                global: ["saturation:0.9", "sidechain:kick:-24db"],
                piano: ["detune:±5cents"],
                drums: ["lowpass:120hz:kick", "highpass:500hz:hi_hats"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Piano Solo", "Outro"],
                transitions: ["808_slide_up", "drum_fill:32nd"]
            }
        },
        "Just Blaze": {
            metadata: {
                genre: ["Hip-Hop", "Soul"],
                producer: "Just Blaze",
                bpm_range: [85, 95],
                default_bpm: 90,
                key_preference: ["Eb Major", "G Minor", "A Minor"],
                swing: 0.5
            },
            drums: {
                kick: {
                    sample: ["acoustic_kick.wav", "808_sub.wav"],
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["saturation:0.4", "compressor:4:1"]
                },
                snare: {
                    sample: "vinyl_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.0s", "delay:1/4"]
                },
                hi_hats: {
                    sample: "swung_hats.wav",
                    pattern: [1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1], // Swung 1/16th
                    effects: ["highpass:600hz"]
                },
                percussion: {
                    orchestral_hits: {
                        sample: ["string_hit.wav", "brass_hit.wav"],
                        pattern: [1, 0, 0, 0, 0, 0, 1, 0],
                        effects: ["reverb:hall:2.0s"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["ii", "V", "I"], // e.g., Gm → C7 → F
                    ["I", "vi", "ii", "V"] // e.g., F → Dm → Gm → C7
                ],
                voicings: {
                    preference: ["extended", "9ths", "11ths"],
                    example: ["Fmaj9", "Dm11", "Gm7", "C13"]
                },
                bassline: {
                    type: "live_bass",
                    waveform: "sine",
                    effects: ["saturation:0.3", "compressor:3:1"]
                }
            },
            instrumentation: {
                samples: ["jazz_piano_loop.wav", "soul_guitar.wav"],
                synths: ["rhodes_pad.wav", "string_section.wav"],
                brass: ["trumpet_section.wav", "sax_stab.wav"]
            },
            fx_mixing: {
                global: ["tape_saturation:0.3", "parallel_compression:drums:-18db"],
                samples: ["lowpass:5000hz", "vinyl_crackle"],
                vocals: ["autotune:retune_speed:20ms", "delay:1/8"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Sample Solo", "Outro"],
                transitions: ["filter_sweep_down", "orchestral_hit"]
            }
        },
        "Missy Elliott": {
            metadata: {
                genre: ["Hip-Hop", "R&B"],
                producer: "Missy Elliott",
                bpm_range: [90, 110],
                default_bpm: 100,
                key_preference: ["C# Minor", "F Minor", "G# Minor"],
                swing: 0.8,
                experimental: true
            },
            drums: {
                kick: {
                    sample: ["distorted_kick.wav", "sub_bass.wav"],
                    pattern: [1, 0, 0, 0, 1, 0, 1, 0],
                    effects: ["saturation:0.9", "compressor:6:1"]
                },
                snare: {
                    sample: "layered_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 0, 1],
                    effects: ["reverb:reverse:1.0s", "delay:1/16"]
                },
                hi_hats: {
                    sample: "glitchy_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["bitcrush:4bit", "delay:1/32"]
                },
                percussion: {
                    sound_fx: {
                        samples: ["laser.wav", "vinyl_stop.wav"],
                        pattern: [0, 0, 1, 0, 0, 0, 0, 1],
                        effects: ["pitch_shift:+5st", "filter_sweep:lowpass"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "bII", "bVI", "bVII"], // e.g., C#m → D# → G# → A#
                    ["i", "bIII", "bVI", "bVII"] // e.g., C#m → E → G# → A#
                ],
                voicings: {
                    preference: ["dissonant", "cluster"],
                    example: ["C#m(E-G#-B)", "E(G#-B-D#)", "G#(C#-E-G#)"]
                },
                bassline: {
                    type: "synth_bass",
                    waveform: "square",
                    effects: ["portamento:50ms", "distortion:0.7"]
                }
            },
            instrumentation: {
                synths: ["fm_synth_bass.wav", "dark_pad.wav"],
                sound_fx: ["laser.wav", "siren.wav"],
                vocal_chops: ["hey.wav", "uh.wav", "go.wav"]
            },
            fx_mixing: {
                global: ["saturation:0.8", "sidechain:kick:-20db"],
                drums: ["bitcrush:8bit", "reverse_reverb:snare"],
                vocals: ["autotune:retune_speed:5ms", "formant_shift:+2st"],
                synths: ["filter_sweep:highpass:8bars"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Beat Switch", "Outro"],
                transitions: ["sudden_stop", "bpm_change:+5"]
            }
        },
        "Dr. Dre": {
            metadata: {
                genre: ["Hip-Hop", "G-Funk"],
                producer: "Dr. Dre",
                era: "1995-2010",
                signature: "Deep bass, synth strings, funky guitars, and piano melodies.",
                bpm_range: [85, 95],
                default_bpm: 90,
                key_preference: ["C Minor", "F Minor", "G Minor"],
                swing: 0.5
            },
            drums: {
                kick: {
                    sample: "deep_808_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["saturation:0.7", "compressor:6:1"]
                },
                snare: {
                    sample: "crisp_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.0s"]
                },
                hi_hats: {
                    sample: "swung_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["highpass:600hz"]
                },
                percussion: {
                    shaker: {
                        sample: "shaker.wav",
                        pattern: [0, 1, 0, 1, 0, 1, 0, 1],
                        effects: ["delay:1/16"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "VI", "VII", "i"], // e.g., Cm → Ab → Bb → Cm
                    ["i", "iv", "VII", "III"] // e.g., Cm → Fm → Bb → Eb
                ],
                voicings: {
                    preference: ["7ths", "9ths"],
                    example: ["Cm9", "Abmaj7", "Bb7"]
                },
                bassline: {
                    type: "deep_synth",
                    waveform: "sine",
                    effects: ["distortion:0.5", "lowpass:100hz"]
                }
            },
            instrumentation: {
                synths: ["funky_synth.wav", "piano_loop.wav"],
                guitars: ["funk_guitar.wav"],
                strings: ["synth_strings.wav"]
            },
            fx_mixing: {
                global: ["tape_saturation:0.4", "sidechain:kick:-18db"],
                synths: ["reverb:hall:2.0s", "chorus:0.3"],
                vocals: ["delay:1/8", "compressor:4:1"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Bridge", "Outro"],
                transitions: ["filter_sweep", "piano_riff"]
            }
        },
        "J Dilla": {
            metadata: {
                genre: ["Neo-Soul", "Hip-Hop"],
                producer: "J Dilla",
                era: "1995-2006",
                signature: "Off-kilter rhythms, jazz chords, and warm, dusty samples.",
                bpm_range: [70, 90],
                default_bpm: 80,
                key_preference: ["D Minor", "Eb Major", "G Minor"],
                swing: 0.6
            },
            drums: {
                kick: {
                    sample: "dusty_kick.wav",
                    pattern: [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0], // Off-kilter
                    effects: ["saturation:0.3", "lowpass:120hz"]
                },
                snare: {
                    sample: "lofi_snare.wav",
                    pattern: [0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["reverb:room:0.8s"]
                },
                hi_hats: {
                    sample: "swung_hats.wav",
                    pattern: [1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1],
                    effects: ["highpass:800hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "VII", "VI", "V"], // e.g., Dm → C → Bb → A
                    ["ii", "V", "I", "IV"] // e.g., Em7 → A7 → Dmaj7 → Gmaj7
                ],
                voicings: {
                    preference: ["extended", "jazz"],
                    example: ["Dm11", "Cmaj9", "Bb7#9"]
                },
                bassline: {
                    type: "warm_synth",
                    waveform: "sine",
                    effects: ["saturation:0.2", "compressor:3:1"]
                }
            },
            instrumentation: {
                samples: ["jazz_piano.wav", "vinyl_crackle.wav"],
                synths: ["rhodes.wav", "wurlitzer.wav"]
            },
            fx_mixing: {
                global: ["vinyl_noise", "sidechain:kick:-12db"],
                samples: ["lowpass:5000hz", "reverb:spring:1.0s"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Solo", "Outro"],
                transitions: ["vinyl_stop", "drum_fill"]
            }
        },
        "Kanye West": {
            metadata: {
                genre: ["Hip-Hop", "Soul"],
                producer: "Kanye West",
                era: "2000-2010",
                signature: "Soul samples, orchestral hits, and emotional chords.",
                bpm_range: [80, 95],
                default_bpm: 88,
                key_preference: ["Eb Major", "C Minor", "G Minor"],
                swing: 0.4
            },
            drums: {
                kick: {
                    sample: "orchestral_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["compressor:5:1", "saturation:0.5"]
                },
                snare: {
                    sample: "orchestral_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:hall:1.5s"]
                },
                hi_hats: {
                    sample: "tight_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["highpass:700hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["I", "V", "vi", "IV"], // e.g., Eb → Bb → Cm → Ab
                    ["i", "VI", "III", "VII"] // e.g., Cm → Ab → Eb → Bb
                ],
                voicings: {
                    preference: ["7ths", "9ths", "orchestral"],
                    example: ["Ebmaj9", "Bb7", "Cm11"]
                },
                bassline: {
                    type: "orchestral",
                    waveform: "sine",
                    effects: ["reverb:hall:2.0s"]
                }
            },
            instrumentation: {
                samples: ["soul_vocal.wav", "orchestral_hit.wav"],
                synths: ["string_section.wav", "choir_pad.wav"]
            },
            fx_mixing: {
                global: ["orchestral_compression", "sidechain:kick:-15db"],
                samples: ["reverb:cathedral:3.0s"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Breakdown", "Outro"],
                transitions: ["orchestral_swell", "drum_roll"]
            }
        },
        "Swizz Beatz": {
            metadata: {
                genre: ["Hip-Hop", "East Coast"],
                producer: "Swizz Beatz",
                era: "1998-2010",
                signature: "Hard-hitting drums, orchestral samples, and aggressive synths.",
                bpm_range: [90, 105],
                default_bpm: 95,
                key_preference: ["A Minor", "C# Minor", "E Minor"],
                swing: 0.3
            },
            drums: {
                kick: {
                    sample: "hard_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 0, 1],
                    effects: ["distortion:0.7", "compressor:8:1"]
                },
                snare: {
                    sample: "aggressive_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:room:0.5s"]
                },
                hi_hats: {
                    sample: "fast_hats.wav",
                    pattern: [1, 1, 1, 1, 1, 1, 1, 1],
                    effects: ["delay:1/32"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "bIII", "bVI", "bVII"], // e.g., Am → C → F → G
                    ["i", "VI", "IV", "VII"] // e.g., Am → F → Dm → G
                ],
                voicings: {
                    preference: ["dissonant", "orchestral"],
                    example: ["Am(C-E-G)", "C(E-G-B)", "F(A-C-F)"]
                },
                bassline: {
                    type: "distorted_synth",
                    waveform: "square",
                    effects: ["distortion:0.8"]
                }
            },
            instrumentation: {
                synths: ["aggressive_lead.wav", "orchestral_hit.wav"],
                samples: ["choir_stab.wav"]
            },
            fx_mixing: {
                global: ["hard_compression", "sidechain:kick:-20db"],
                synths: ["distortion:0.6", "reverb:plate:1.0s"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Breakdown", "Outro"],
                transitions: ["drum_fill", "synth_rise"]
            }
        },
        "The Neptunes": {
            metadata: {
                genre: ["R&B", "Hip-Hop", "Pop"],
                producer: "The Neptunes",
                era: "1998-2010",
                signature: "Minimalist funk, plucky synths, and metallic drums.",
                bpm_range: [90, 110],
                default_bpm: 100,
                key_preference: ["F Minor", "A Minor", "C Major"],
                swing: 0.5
            },
            drums: {
                kick: {
                    sample: "short_kick.wav",
                    layer: ["sine_sub.wav"],
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["saturation:0.4"]
                },
                snare: {
                    sample: "metallic_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.0s"]
                },
                hi_hats: {
                    sample: "tight_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["highpass:600hz"]
                },
                percussion: {
                    finger_snaps: {
                        sample: "finger_snap.wav",
                        pattern: [0, 1, 0, 1, 0, 1, 0, 1],
                        effects: ["delay:1/16"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "IV", "V"], // e.g., Fm → Bbm → C
                    ["vi", "IV", "I", "V"] // e.g., Dm → Bb → F → C
                ],
                voicings: {
                    preference: ["7ths", "9ths"],
                    example: ["Fm9", "Bbm7", "Cmaj7"]
                },
                bassline: {
                    type: "plucky_funk",
                    waveform: "saw",
                    effects: ["pitch_modulation:0.1hz:2st"]
                }
            },
            instrumentation: {
                synths: ["rhodes.wav", "plucky_guitar.wav"],
                layers: ["atmospheric_pad.wav"]
            },
            fx_mixing: {
                global: ["tape_saturation:0.3", "sidechain:kick:-12db"],
                synths: ["chorus:0.2", "reverb:hall:1.5s"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Pre-Chorus", "Chorus", "Outro"],
                transitions: ["filter_sweep", "drum_fill"]
            }
        },
        "Mannie Fresh": {
            metadata: {
                genre: ["Hip-Hop", "Bounce"],
                producer: "Mannie Fresh",
                era: "1995-2010",
                signature: "Bouncy rhythms, brass stabs, and high-energy drums.",
                bpm_range: [95, 110],
                default_bpm: 100,
                key_preference: ["D Minor", "F Major", "A Minor"],
                swing: 0.6
            },
            drums: {
                kick: {
                    sample: "bouncy_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 1, 0],
                    effects: ["compressor:6:1"]
                },
                snare: {
                    sample: "brass_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:room:0.7s"]
                },
                hi_hats: {
                    sample: "fast_hats.wav",
                    pattern: [1, 1, 1, 1, 1, 1, 1, 1],
                    effects: ["delay:1/32"]
                },
                percussion: {
                    brass_stabs: {
                        sample: "brass_stab.wav",
                        pattern: [1, 0, 0, 0, 0, 0, 1, 0],
                        effects: ["distortion:0.4"]
                    }
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "bVI", "bVII", "i"], // e.g., Dm → Bb → C → Dm
                    ["I", "IV", "V", "I"] // e.g., F → Bb → C → F
                ],
                voicings: {
                    preference: ["brass", "7ths"],
                    example: ["Dm7", "Bbmaj7", "C7"]
                },
                bassline: {
                    type: "bouncy_synth",
                    waveform: "square",
                    effects: ["saturation:0.5"]
                }
            },
            instrumentation: {
                brass: ["trumpet_stab.wav", "trombone.wav"],
                synths: ["bounce_lead.wav"]
            },
            fx_mixing: {
                global: ["high_energy_compression", "sidechain:kick:-18db"],
                brass: ["distortion:0.3", "reverb:plate:1.0s"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Breakdown", "Outro"],
                transitions: ["brass_hit", "drum_roll"]
            }
        },
        "Scott Storch": {
            metadata: {
                genre: ["Pop", "Hip-Hop"],
                producer: "Scott Storch",
                era: "2000-2010",
                signature: "Piano-driven hooks, lush strings, and high-energy beats.",
                bpm_range: [90, 105],
                default_bpm: 95,
                key_preference: ["C Minor", "Eb Major", "G Minor"],
                swing: 0.4
            },
            drums: {
                kick: {
                    sample: "punchy_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["compressor:5:1"]
                },
                snare: {
                    sample: "crisp_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.2s"]
                },
                hi_hats: {
                    sample: "tight_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["highpass:700hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "VI", "III", "VII"], // e.g., Cm → Ab → Eb → Bb
                    ["I", "V", "vi", "IV"] // e.g., Eb → Bb → Cm → Ab
                ],
                voicings: {
                    preference: ["piano", "strings", "9ths"],
                    example: ["Cm9", "Abmaj7", "Ebmaj9"]
                },
                bassline: {
                    type: "piano_bass",
                    waveform: "sine",
                    effects: ["reverb:hall:1.5s"]
                }
            },
            instrumentation: {
                piano: ["grand_piano.wav"],
                strings: ["string_section.wav"]
            },
            fx_mixing: {
                global: ["lush_reverb", "sidechain:kick:-12db"],
                piano: ["reverb:hall:2.5s", "chorus:0.3"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Bridge", "Outro"],
                transitions: ["piano_riff", "string_swell"]
            }
        },
        "Danja": {
            metadata: {
                genre: ["R&B", "Hip-Hop"],
                producer: "Danja",
                era: "2005-2010",
                signature: "Futuristic synths, stuttering rhythms, and electronic textures.",
                bpm_range: [95, 110],
                default_bpm: 100,
                key_preference: ["A Minor", "C# Minor", "F Minor"],
                swing: 0.5
            },
            drums: {
                kick: {
                    sample: "electronic_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 1, 0],
                    effects: ["distortion:0.6", "compressor:7:1"]
                },
                snare: {
                    sample: "futuristic_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:0.8s", "delay:1/16"]
                },
                hi_hats: {
                    sample: "glitchy_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 1, 1, 0],
                    effects: ["bitcrush:8bit"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "bVI", "bIII", "bVII"], // e.g., Am → F → C → G
                    ["i", "bVII", "bVI", "bIII"] // e.g., Am → G → F → C
                ],
                voicings: {
                    preference: ["futuristic", "dissonant"],
                    example: ["Am7", "Fmaj9", "C#dim7"]
                },
                bassline: {
                    type: "synth_bass",
                    waveform: "saw",
                    effects: ["distortion:0.7", "lowpass:150hz"]
                }
            },
            instrumentation: {
                synths: ["futuristic_lead.wav", "electronic_pad.wav"],
                sound_fx: ["laser.wav", "robot_vocoder.wav"]
            },
            fx_mixing: {
                global: ["electronic_saturation", "sidechain:kick:-20db"],
                synths: ["bitcrush:12bit", "reverb:reverse:1.0s"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Breakdown", "Outro"],
                transitions: ["synth_rise", "glitch_effect"]
            }
        },
        "Cool & Dre": {
            metadata: {
                genre: ["Hip-Hop"],
                producer: "Cool & Dre",
                era: "2000-2010",
                signature: "Piano loops, hard-hitting drums, and epic strings.",
                bpm_range: [85, 95],
                default_bpm: 90,
                key_preference: ["C Minor", "Eb Major", "G Minor"],
                swing: 0.4
            },
            drums: {
                kick: {
                    sample: "epic_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["compressor:6:1", "saturation:0.5"]
                },
                snare: {
                    sample: "orchestral_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:hall:1.2s"]
                },
                hi_hats: {
                    sample: "tight_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["highpass:700hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "VI", "III", "VII"], // e.g., Cm → Ab → Eb → Bb
                    ["I", "V", "vi", "IV"] // e.g., Eb → Bb → Cm → Ab
                ],
                voicings: {
                    preference: ["piano", "strings", "epic"],
                    example: ["Cm9", "Abmaj7", "Ebmaj9"]
                },
                bassline: {
                    type: "orchestral_bass",
                    waveform: "sine",
                    effects: ["reverb:hall:1.5s"]
                }
            },
            instrumentation: {
                piano: ["grand_piano_loop.wav"],
                strings: ["epic_string_section.wav"]
            },
            fx_mixing: {
                global: ["epic_reverb", "sidechain:kick:-18db"],
                piano: ["reverb:cathedral:2.5s"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Bridge", "Outro"],
                transitions: ["string_swell", "piano_arpeggio"]
            }
        },
        "Polow da Don": {
            metadata: {
                genre: ["R&B", "Hip-Hop"],
                producer: "Polow da Don",
                era: "2005-2010",
                signature: "Smooth synths, punchy drums, and melodic hooks.",
                bpm_range: [80, 95],
                default_bpm: 88,
                key_preference: ["F Minor", "A Minor", "C Major"],
                swing: 0.5
            },
            drums: {
                kick: {
                    sample: "smooth_kick.wav",
                    pattern: [1, 0, 0, 0, 1, 0, 0, 0],
                    effects: ["compressor:4:1"]
                },
                snare: {
                    sample: "punchy_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.0s"]
                },
                hi_hats: {
                    sample: "smooth_hats.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["highpass:600hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "VI", "III", "VII"], // e.g., Fm → Db → Ab → Eb
                    ["I", "V", "vi", "IV"] // e.g., C → G → Am → F
                ],
                voicings: {
                    preference: ["smooth", "7ths", "9ths"],
                    example: ["Fm9", "Dbmaj7", "Abmaj9"]
                },
                bassline: {
                    type: "smooth_synth",
                    waveform: "sine",
                    effects: ["saturation:0.3"]
                }
            },
            instrumentation: {
                synths: ["smooth_lead.wav", "warm_pad.wav"],
                guitars: ["clean_guitar.wav"]
            },
            fx_mixing: {
                global: ["smooth_compression", "sidechain:kick:-12db"],
                synths: ["reverb:hall:1.5s", "chorus:0.2"]
            },
            arrangement: {
                structure: ["Intro", "Verse", "Chorus", "Bridge", "Outro"],
                transitions: ["synth_swell", "guitar_riff"]
            }
        },
        "Ludwig Göransson": {
            metadata: {
                genre: ["Funk", "R&B", "Electronic"],
                producer: "Ludwig Göransson",
                bpm_range: [80, 100],
                default_bpm: 90,
                key_preference: ["C# Minor"],
                swing: 0.5,
                key_characteristics: [
                    "Blends funk, R&B, and electronic music.",
                    "Incorporates traditional African and blues influences.",
                    "Uses intricate percussion and atmospheric effects.",
                    "Creates rich, layered sounds with depth and emotional resonance."
                ]
            },
            drums: {
                kick: {
                    sample: "funk_kick.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 1, 0],
                    effects: ["compressor:4:1"]
                },
                snare: {
                    sample: "funk_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.2s"]
                },
                hi_hats: {
                    sample: "open_hat.wav",
                    pattern: [0, 1, 0, 1, 0, 1, 0, 1],
                    effects: ["highpass:600hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "iv", "bVII", "bIII"], // Example from "Redbone"
                    ["I", "vi", "IV", "V"]      // Example from "No Excuses"
                ],
                voicings: {
                    preference: ["7ths", "9ths"],
                    example: ["C#m7", "F#m9", "B7", "Emaj7"]
                },
                bassline: {
                    type: "deep_sub-bass",
                    waveform: "sine",
                    effects: ["saturation:0.3"]
                }
            },
            instrumentation: {
                synths: ["atmospheric_pad.wav", "arp_synth.wav"],
                effects: ["reverb", "delay", "phaser"]
            },
            arrangement: {
                structure: ["Intro (4 bars)", "Verse (8 bars)", "Chorus (8 bars)", "Bridge (8 bars)", "Outro (4 bars)"],
                transitions: ["filter_sweep", "riser"]
            }
        },

        "Terrace Martin": {
            metadata: {
                genre: ["R&B", "Hip-Hop", "Jazz"],
                producer: "Terrace Martin",
                bpm_range: [70, 90],
                default_bpm: 80,
                key_preference: ["A Minor"],
                swing: 0.6,
                key_characteristics: [
                    "Blends R&B, hip-hop, and jazz.",
                    "Incorporates live instrumentation (piano, saxophone, bass).",
                    "Creates a warm and inviting atmosphere.",
                    "Focuses on emotional depth and sophistication."
                ]
            },
            drums: {
                kick: {
                    sample: "jazz_kick.wav",
                    pattern: [1, 0, 0, 1, 0, 0, 1, 0],
                    effects: ["compressor:3:1"]
                },
                snare: {
                    sample: "jazz_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:room:0.8s"]
                },
                hi_hats: {
                    sample: "jazz_hats.wav",
                    pattern: [1, 1, 1, 1, 1, 1, 1, 1],
                    effects: ["highpass:800hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "iv", "v", "i"],   // Simple and emotive
                    ["I", "V", "vi", "IV"]  // Example from "Close to You"
                ],
                voicings: {
                    preference: ["7ths"],
                    example: ["Am7", "Dm7", "Em7"]
                },
                bassline: {
                    type: "upright_bass",
                    waveform: "sine",
                    effects: ["compressor:2:1"]
                }
            },
            instrumentation: {
                piano: ["acoustic_piano.wav"],
                sax: ["tenor_sax.wav"],
                effects: ["reverb", "chorus"]
            },
            arrangement: {
                structure: ["Intro (4 bars)", "Verse (8 bars)", "Chorus (8 bars)", "Bridge (4 bars)", "Outro (4 bars)"],
                transitions: ["sax_fill", "piano_chord"]
            }
        },

        "Knxwledge": {
            metadata: {
                genre: ["Hip-Hop", "R&B", "Electronic"],
                producer: "Knxwledge",
                bpm_range: [85, 100],
                default_bpm: 92,
                key_preference: ["F# Minor"],
                swing: 0.7,
                key_characteristics: [
                    "Blends hip-hop, R&B, and electronic music.",
                    "Incorporates elements from jazz and funk.",
                    "Creates a lush and atmospheric sound.",
                    "Focuses on intricate drum patterns and smooth basslines."
                ]
            },
            drums: {
                kick: {
                    sample: "hip-hop_kick.wav",
                    pattern: [1, 0, 1, 0, 1, 0, 0, 1],
                    effects: ["saturation:0.5"]
                },
                snare: {
                    sample: "hip-hop_snare.wav",
                    pattern: [0, 0, 1, 0, 0, 0, 1, 0],
                    effects: ["reverb:plate:1.0s"]
                },
                hi_hats: {
                    sample: "closed_hats.wav",
                    pattern: [1, 1, 1, 1, 1, 1, 1, 1],
                    effects: ["highpass:700hz"]
                }
            },
            harmony: {
                chord_progressions: [
                    ["i", "bVII", "bVI", "V"], // Example from "Suede"
                    ["I", "vi", "IV", "V"]     // Common progression
                ],
                voicings: {
                    preference: ["7ths", "9ths"],
                    example: ["F#m9", "E7", "Dmaj7", "C#7"]
                },
                bassline: {
                    type: "smooth_bass",
                    waveform: "sine",
                    effects: ["saturation:0.4"]
                }
            },
            instrumentation: {
                synths: ["lush_pad.wav", "lead_synth.wav"],
                effects: ["reverb", "delay", "flanger"]
            },
            arrangement: {
                structure: ["Intro (4 bars)", "Verse (8 bars)", "Chorus (8 bars)", "Bridge (8 bars)", "Outro (4 bars)"],
                transitions: ["filter_sweep", "stutter_edit"]
            }
        }
    };


    /******************************************************************************
     *
     * @section Digital Signal Processing (DSP) Functions
     * @description Producer-specific drum synthesis functions
     *
     ******************************************************************************/

    const SR = 44100;

    const sine = (freq, length, sr = SR) => {
        const t = Array.from({
            length: Math.floor(sr * length)
        }, (_, i) => i / sr);
        return t.map(time => Math.sin(2 * Math.PI * freq * time));
    };

    const square = (freq, length, sr = SR) => {
        const t = Array.from({
            length: Math.floor(sr * length)
        }, (_, i) => i / sr);
        return t.map(time => Math.sign(Math.sin(2 * Math.PI * freq * time)));
    };

    const triangle = (freq, length, sr = SR) => {
        const t = Array.from({
            length: Math.floor(sr * length)
        }, (_, i) => i / sr);
        return t.map(time => 2 * Math.abs(2 * (time * freq - Math.floor(time * freq + 0.5))) - 1);
    };

    const env_adsr = (length, attack, decay, sustain_level, release, sr = SR) => {
        const len = Math.floor(sr * length);
        const attack_len = Math.floor(sr * attack);
        const decay_len = Math.floor(sr * decay);
        const release_len = Math.floor(sr * release);
        const sustain_len = len - attack_len - decay_len - release_len;

        const env = new Array(len).fill(0);

        for (let i = 0; i < attack_len; i++) {
            env[i] = i / attack_len;
        }
        for (let i = 0; i < decay_len; i++) {
            env[attack_len + i] = 1 - (1 - sustain_level) * (i / decay_len);
        }
        for (let i = 0; i < sustain_len; i++) {
            env[attack_len + decay_len + i] = sustain_level;
        }
        for (let i = 0; i < release_len; i++) {
            env[attack_len + decay_len + sustain_len + i] = sustain_level * (1 - i / release_len);
        }

        return env;
    };

    const one_pole_lowpass = (signal, cutoff, sr = SR) => {
        const out = new Array(signal.length).fill(0);
        const g = 1 - Math.cos(2 * Math.PI * cutoff / sr);
        out[0] = g * signal[0];
        for (let i = 1; i < signal.length; i++) {
            out[i] = g * signal[i] + (1 - g) * out[i - 1];
        }
        return out;
    };

    const normalize = (signal) => {
        const max = Math.max(...signal.map(Math.abs));
        if (max === 0) return signal;
        return signal.map(s => s / max);
    };

    const saturate = (signal, drive = 0.5) => {
        return signal.map(s => Math.tanh(s * drive));
    };

    const timbaland_kick = (frequency = 60.0, decay = 0.3, length = 0.6) => {
        const sub = sine(frequency, length).map((val, i) => val * env_adsr(length, 0.001, decay, 0.0, 0.001)[i]);
        const click = square(frequency * 3, 0.05).map((val, i) => val * env_adsr(0.05, 0.001, 0.02, 0.0, 0.01)[i]);
        const kick = sub.map((val, i) => val + 0.15 * (click[i] || 0));
        const filtered_kick = one_pole_lowpass(kick, 120.0);
        return normalize(saturate(filtered_kick, 0.25));
    };

    const kanye_kick = (frequency = 65.0, decay = 0.1, length = 0.4) => {
        const wave = sine(frequency, length).map((val, i) => val * env_adsr(length, 0.001, decay, 0.0, 0.001)[i]);
        const n = Math.floor(decay * SR);
        const truncated_wave = wave.slice(0, Math.max(1, n));
        const padded_wave = [...truncated_wave, ...new Array(Math.floor(length * SR) - truncated_wave.length).fill(0)];
        return normalize(saturate(padded_wave, 0.18));
    };

    const djquik_kick = (frequency = 70.0, decay = 0.4, length = 0.6) => {
        const sub = sine(frequency, length).map((val, i) => val * env_adsr(length, 0.001, decay, 0.0, 0.01)[i]);
        const body = triangle(frequency * 2, length).map((val, i) => val * env_adsr(length, 0.001, decay * 0.6, 0.0, 0.01)[i] * 0.15);
        const kick = sub.map((val, i) => val + body[i]);
        return normalize(saturate(kick, 0.12));
    };


    /******************************************************************************
     *
     * @section Tone.js Implementation
     * @description Implementation of Pharrell Williams' drum pattern and
     * Timbaland's stutter effect using Tone.js
     *
     ******************************************************************************/

    // Pharrell Williams' Drum Pattern
    const playPharrellPattern = async () => {

        const kick = new Tone.Player("path/to/kick.wav").toDestination();
        const snare = new Tone.Player("path/to/snare.wav").toDestination();
        const finger_snap = new Tone.Player("path/to/finger_snap.wav").toDestination();
        const hi_hats = new Tone.Player("path/to/hi_hats.wav").toDestination();

        const kick_pattern = [0, 0, 1, 0, 0, 0, 1, 0];
        const snare_pattern = [0, 0, 0, 0, 1, 0, 0, 0];
        const finger_snap_pattern = [0, 1, 0, 1, 0, 1, 0, 1];
        const hi_hats_pattern = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0];

        const kick_part = new Tone.Part((time, note) => {
            if (note) kick.start(time);
        }, kick_pattern.map((val, i) => [i * 0.5, val])).start(0);

        const snare_part = new Tone.Part((time, note) => {
            if (note) snare.start(time);
        }, snare_pattern.map((val, i) => [i * 0.5, val])).start(0);

        const finger_snap_part = new Tone.Part((time, note) => {
            if (note) finger_snap.start(time);
        }, finger_snap_pattern.map((val, i) => [i * 0.5 + 0.25, val])).start(0);

        const hi_hats_part = new Tone.Part((time, note) => {
            if (note) hi_hats.start(time);
        }, hi_hats_pattern.map((val, i) => [i * 0.25, val])).start(0);

        Tone.Transport.start();
    };

    // Timbaland's Stutter Effect
    const playTimbalandStutter = async () => {
        const kick = new Tone.Player({
            url: "path/to/kick.wav",
            attack: 0.01,
            release: 0.3
        }).toDestination();

        const snare = new Tone.Player({
            url: "path/to/snare.wav",
            attack: 0.01,
            release: 0.2
        }).toDestination();

        const hiHats = new Tone.Player({
            url: "path/to/hihats.wav",
            attack: 0.01,
            release: 0.1
        }).toDestination();

        const stutterEffect = (beatLength = "8n") => {
            const stutterLoop = new Tone.Loop((time) => {
                Tone.Transport.pause(time);
                Tone.Transport.scheduleOnce(() => Tone.Transport.start(time + "16n"), time);
            }, "8m").start(0);

            Tone.Transport.scheduleOnce(() => {
                stutterLoop.stop();
            }, "32m");
        }

        const drumLoop = new Tone.Loop((time) => {
            // Kick on 1 and 3 (half-time feel)
            kick.start(time);
            kick.start(time + "2n");

            // Snare on 3 with a stutter (triplet roll)
            snare.start(time + "1n");
            snare.start(time + "1n + 16n");
            snare.start(time + "1n + 32n");

            // Hi-hats: 1/16th notes with swing
            hiHats.start(time);
            hiHats.start(time + "16n");
            hiHats.start(time + "32n");
            hiHats.start(time + "48n");
        }, "2n").start(0);

        Tone.Transport.start();
        stutterEffect();
    };


    /******************************************************************************
     *
     * @section Helper Functions
     *
     ******************************************************************************/
    const ROMAN_TO_DEGREE = {
        'I': 0, 'i': 0, 'II': 1, 'ii': 1, 'III': 2, 'iii': 2,
        'IV': 3, 'iv': 3, 'V': 4, 'v': 4, 'VI': 5, 'vi': 5,
        'VII': 6, 'vii': 6,
    };
    const NOTE_MAP = {
        'C# minor': ['C#3', 'D#3', 'E3', 'F#3', 'G#3', 'A3', 'B3', 'C#4'],
        'A minor': ['A3', 'B3', 'C4', 'D4', 'E4', 'F4', 'G4', 'A4'],
        'F# minor': ['F#3', 'G#3', 'A3', 'B3', 'C#4', 'D4', 'E4', 'F#4'],
    };

    function generateChordProgression(progressions, scale) {
        const selectedProgression = progressions[Math.floor(Math.random() * progressions.length)];
        return selectedProgression.map(numeral => {
            const degree = ROMAN_TO_DEGREE[numeral];
            const rootNote = NOTE_MAP[scale][degree % NOTE_MAP[scale].length];
            return new Tone.Chord(rootNote, `m${numeral.includes('7') ? '7' : ''}`);
        });
    }

    /******************************************************************************
     *
     * @section Track Generation Functions
     *
     ******************************************************************************/

    function generateGoranssonTrack() {
        const goranssonPreset = producerPresets["Ludwig Göransson"];
        const track = {
            tempo: Math.floor(Math.random() * (goranssonPreset.metadata.bpm_range[1] - goranssonPreset.metadata.bpm_range[0] + 1)) + goranssonPreset.metadata.bpm_range[0],
            key: goranssonPreset.metadata.key_preference[0],
            chords: generateChordProgression(goranssonPreset.harmony.chord_progressions, goranssonPreset.metadata.key_preference[0]),
            instruments: goranssonPreset.instrumentation,
            structure: goranssonPreset.arrangement.structure,
        };
        return track;
    }

    function generateMartinTrack() {
        const martinPreset = producerPresets["Terrace Martin"];
        const track = {
            tempo: Math.floor(Math.random() * (martinPreset.metadata.bpm_range[1] - martinPreset.metadata.bpm_range[0] + 1)) + martinPreset.metadata.bpm_range[0],
            key: martinPreset.metadata.key_preference[0],
            chords: generateChordProgression(martinPreset.harmony.chord_progressions, martinPreset.metadata.key_preference[0]),
            instruments: martinPreset.instrumentation,
            structure: martinPreset.arrangement.structure,
        };
        return track;
    }

    function generateKnxledgeTrack() {
        const knxledgePreset = producerPresets["Knxwledge"];
        const track = {
            tempo: Math.floor(Math.random() * (knxledgePreset.metadata.bpm_range[1] - knxledgePreset.metadata.bpm_range[0] + 1)) + knxledgePreset.metadata.bpm_range[0],
            key: knxledgePreset.metadata.key_preference[0],
            chords: generateChordProgression(knxledgePreset.harmony.chord_progressions, knxledgePreset.metadata.key_preference[0]),
            instruments: knxledgePreset.instrumentation,
            structure: knxledgePreset.arrangement.structure,
        };
        return track;
    }


    /******************************************************************************
     *
     * @section React Component Render
     *
     ******************************************************************************/

    return (
        <div>
            <h1> Producer DSP </h1>
            <button onClick = {
                () => {
                    if (isPlaying) {
                        Tone.Transport.stop();
                        setIsPlaying(false);
                    } else {
                        playPharrellPattern();
                        setIsPlaying(true);
                    }
                }
            } > {
                isPlaying ? 'Stop' : 'Play Pharrell Pattern'
            }
            </button>
            <button onClick = {
                () => {
                    if (isPlaying) {
                        Tone.Transport.stop();
                        setIsPlaying(false);
                    } else {
                        playTimbalandStutter();
                        setIsPlaying(true);
                    }
                }
            } > {
                isPlaying ? 'Stop' : 'Play Timbaland Stutter'
            }
            </button>
        </div>
    );
};

export default ProducerDsp;