#include "RealEngine.h"
#include <cmath>

// =================================================================================
// --- SECTION 1: MUSIC THEORY DATA (Ported from JS) ---
// =================================================================================

const std::map<std::string, std::vector<std::string>> RealEngine::NOTE_MAP = {
    {"C major", {"C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5"}}, {"A minor", {"A3", "B3", "C4", "D4", "E4", "F4", "G4", "A4"}},
    {"G major", {"G3", "A3", "B3", "C4", "D4", "E4", "F#4", "G4"}}, {"E minor", {"E3", "F#3", "G3", "A3", "B3", "C4", "D4", "E4"}},
    {"F major", {"F3", "G3", "A3", "Bb3", "C4", "D4", "E4", "F4"}}, {"D minor", {"D3", "E3", "F3", "G3", "A3", "Bb3", "C4", "D4"}},
    {"C# minor", {"C#3", "D#3", "E3", "F#3", "G#3", "A3", "B3", "C#4"}}, {"F minor", {"F3", "G3", "Ab3", "Bb3", "C4", "Db4", "Eb4", "F4"}},
    {"F# minor", {"F#3", "G#3", "A3", "B3", "C#4", "D4", "E4", "F#4"}}, {"C minor", {"C3", "D3", "Eb3", "F3", "G3", "Ab3", "Bb3", "C4"}},
    {"Eb major", {"Eb3", "F3", "G3", "Ab3", "Bb3", "C4", "D4", "Eb4"}}, {"G minor", {"G3", "A3", "Bb3", "C4", "D4", "Eb4", "F4", "G4"}}
};

const std::map<std::string, int> RealEngine::ROMAN_TO_DEGREE = {
    {"I", 0}, {"i", 0}, {"II", 1}, {"ii", 1}, {"III", 2}, {"iii", 2},
    {"IV", 3}, {"iv", 3}, {"V", 4}, {"v", 4}, {"VI", 5}, {"vi", 5},
    {"VII", 6}, {"vii", 6}
};

// =================================================================================
// --- SECTION 2: PRNG & UTILITIES ---
// =================================================================================

void RealEngine::seedPrng(const std::string& seed)
{
    prng_h = 1779033703;
    for (char const& c : seed)
    {
        prng_h = std::imul(prng_h ^ (uint32_t)c, 3432918353);
        prng_h = (prng_h << 13) | (prng_h >> 19);
    }
}

double RealEngine::random()
{
    prng_h = std::imul(prng_h ^ (prng_h >> 16), 2246822507);
    prng_h = std::imul(prng_h ^ (prng_h >> 13), 3266489909);
    return ((prng_h ^= (prng_h >> 16)) >> 0) / 4294967296.0;
}

int RealEngine::noteNameToMidi(const std::string& noteName)
{
    if (noteName.empty()) return 0;
    
    static const std::map<char, int> noteValues = {
        {'C', 0}, {'D', 2}, {'E', 4}, {'F', 5}, {'G', 7}, {'A', 9}, {'B', 11}
    };
    
    int value = noteValues.at(noteName[0]);
    int octave = 0;
    int pos = 1;

    if (noteName.length() > 1)
    {
        if (noteName[1] == '#') {
            value++;
            pos++;
        } else if (noteName[1] == 'b') {
            value--;
            pos++;
        }
    }
    
    octave = std::stoi(noteName.substr(pos));
    return value + (octave + 1) * 12; // MIDI C4 = 60
}

// =================================================================================
// --- SECTION 3: CORE GENERATION LOGIC ---
// =================================================================================

void RealEngine::generate(const std::string& key, const std::vector<std::string>& progression, int tempo, int bars, double complexity, double swing, const std::string& seed)
{
    seedPrng(seed);
    midiFile.clear();
    midiFile.setTicksPerQuarterNote(960);
    const int ppqn = 960;

    auto& scale = NOTE_MAP.at(key);

    // Create tracks for each part
    auto* harmonyTrack = new juce::MidiMessageSequence();
    auto* melodyTrack = new juce::MidiMessageSequence();
    auto* bassTrack = new juce::MidiMessageSequence();
    auto* kickTrack = new juce::MidiMessageSequence();
    auto* snareTrack = new juce::MidiMessageSequence();
    auto* hihatTrack = new juce::MidiMessageSequence();

    // Add tempo and swing info (swing is handled by the host DAW)
    harmonyTrack->addEvent(juce::MidiMessage::tempoMetaEvent(60000000 / tempo));
    
    // Generate musical parts
    auto harmony = generateHarmony(scale, bars, progression);
    addHarmonyToMidi(*harmonyTrack, harmony, ppqn);
    generateLeadMelody(*melodyTrack, scale, bars, harmony, complexity, ppqn);
    generateBass(*bassTrack, harmony, ppqn);
    generateRhythm(*kickTrack, *snareTrack, *hihatTrack, bars, ppqn);

    // Add tracks to the MIDI file
    // JUCE MIDI channels are 1-16. We'll use different channels for different parts.
    midiFile.addTrack(*harmonyTrack); // Channel 1
    midiFile.addTrack(*melodyTrack);  // Channel 2
    midiFile.addTrack(*bassTrack);    // Channel 3
    
    // For drums, it's common to put them all on channel 10
    juce::MidiMessageSequence drumTrack;
    drumTrack.addSequence(*kickTrack, 0, 0, 9);   // Map all to channel 10 (index 9)
    drumTrack.addSequence(*snareTrack, 0, 0, 9);
    drumTrack.addSequence(*hihatTrack, 0, 0, 9);
    midiFile.addTrack(drumTrack);
}

std::vector<ChordEvent> RealEngine::generateHarmony(const std::vector<std::string>& scale, int bars, const std::vector<std::string>& progressionNumerals)
{
    std::vector<ChordEvent> chords;
    for (int bar = 0; bar < bars; ++bar)
    {
        std::string numeral = progressionNumerals[bar % progressionNumerals.size()];
        // A simple way to get the root numeral (e.g., 'i' from 'i7')
        std::string rootNumeral;
        for (char c : numeral) {
             if (c == 'i' || c == 'v' || c == 'I' || c == 'V') {
                 rootNumeral += c;
             }
        }
        if (rootNumeral.empty()) rootNumeral = "i";

        int degree = ROMAN_TO_DEGREE.count(rootNumeral) ? ROMAN_TO_DEGREE.at(rootNumeral) : 0;
        
        ChordEvent currentChord;
        currentChord.timeInBars = bar;
        currentChord.noteNames = {
            scale[degree % scale.size()],
            scale[(degree + 2) % scale.size()],
            scale[(degree + 4) % scale.size()]
        };

        if (numeral.find('7') != std::string::npos || random() > 0.4) {
            currentChord.noteNames.push_back(scale[(degree + 6) % scale.size()]);
        }
        
        for(const auto& name : currentChord.noteNames) {
            currentChord.midiNotes.push_back(noteNameToMidi(name));
        }

        chords.push_back(currentChord);
    }
    return chords;
}

void RealEngine::addHarmonyToMidi(juce::MidiMessageSequence& track, const std::vector<ChordEvent>& harmony, int ppqn)
{
    for (const auto& chord : harmony)
    {
        double startTime = chord.timeInBars * 4.0 * ppqn;
        double endTime = startTime + (4.0 * ppqn); // 1 measure duration
        for (int note : chord.midiNotes)
        {
            track.addEvent(juce::MidiMessage::noteOn(1, note, (juce::uint8)90));
            track.addEvent(juce::MidiMessage::noteOff(1, note, (juce::uint8)90), endTime);
        }
    }
}

void RealEngine::generateLeadMelody(juce::MidiMessageSequence& track, const std::vector<std::string>& scale, int bars, const std::vector<ChordEvent>& harmony, double complexity, int ppqn)
{
    std::vector<double> rhythmicMotif = random() > 0.5 ? 
        std::vector<double>{0.5, 0.25, 0.25} :  // 8n, 16n, 16n
        std::vector<double>{1.0, 0.5};          // 4n, 8n
    int motifIndex = 0;

    for (int b = 0; b < bars; ++b)
    {
        const ChordEvent& currentChord = harmony[b];
        
        for (int i = 0; i < 4; ++i) // 4 beats per bar
        {
            if (random() < 0.85 * complexity)
            {
                bool isStrongBeat = (i == 0 || i == 2);
                std::string noteToPlay;

                if (isStrongBeat && random() > 0.2) {
                    noteToPlay = currentChord.noteNames[floor(random() * currentChord.noteNames.size())];
                } else {
                    noteToPlay = scale[floor(random() * scale.size())];
                }

                // Transpose to a higher octave
                int originalOctave = noteToPlay.back() - '0';
                noteToPlay.back() = (originalOctave + 1) + '0';
                
                double durationInBeats = rhythmicMotif[motifIndex % rhythmicMotif.size()];
                motifIndex++;
                
                double startTime = (b * 4.0 + i) * ppqn;
                double endTime = startTime + (durationInBeats * ppqn);
                float velocity = 0.6f + (float)random() * 0.4f;

                track.addEvent(juce::MidiMessage::noteOn(2, noteNameToMidi(noteToPlay), velocity));
                track.addEvent(juce::MidiMessage::noteOff(2, noteNameToMidi(noteToPlay), velocity), endTime);
            }
        }
    }
}

void RealEngine::generateBass(juce::MidiMessageSequence& track, const std::vector<ChordEvent>& harmony, int ppqn)
{
    for (const auto& chord : harmony)
    {
        double startTime = chord.timeInBars * 4.0 * ppqn;
        double endTime = startTime + (2.0 * ppqn); // Half note duration
        
        // Get root note and transpose to octave 2
        std::string rootNoteName = chord.noteNames[0];
        rootNoteName.back() = '2';
        
        float velocity = 0.9f + (float)random() * 0.1f;

        track.addEvent(juce::MidiMessage::noteOn(3, noteNameToMidi(rootNoteName), velocity));
        track.addEvent(juce::MidiMessage::noteOff(3, noteNameToMidi(rootNoteName), velocity), endTime);
    }
}

void RealEngine::generateRhythm(juce::MidiMessageSequence& kickTrack, juce::MidiMessageSequence& snareTrack, juce::MidiMessageSequence& hihatTrack, int bars, int ppqn)
{
    const std::vector<int> kickPattern = {1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0};
    const std::vector<int> snarePattern = {0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0};

    // MIDI notes for General MIDI drums
    const int kickNote = 36;
    const int snareNote = 38;
    const int hihatNote = 42;

    for (int b = 0; b < bars; ++b)
    {
        for (int i = 0; i < 16; ++i)
        {
            double time = (b * 4.0 + (i / 4.0)) * ppqn;
            
            if (kickPattern[i] == 1 && random() < 0.95) {
                kickTrack.addEvent(juce::MidiMessage::noteOn(10, kickNote, (juce::uint8)115));
                kickTrack.addEvent(juce::MidiMessage::noteOff(10, kickNote), time + ppqn / 4);
            }
            if (snarePattern[i] == 1 && random() < 0.98) {
                snareTrack.addEvent(juce::MidiMessage::noteOn(10, snareNote, (juce::uint8)110));
                snareTrack.addEvent(juce::MidiMessage::noteOff(10, snareNote), time + ppqn / 4);
            }
            if (i % 2 == 0 || random() < 0.4) {
                float velocity = 0.4f + (float)random() * 0.2f;
                hihatTrack.addEvent(juce::MidiMessage::noteOn(10, hihatNote, velocity));
                hihatTrack.addEvent(juce::MidiMessage::noteOff(10, hihatNote), time + ppqn / 8);
            }
        }
    }
}