// Ensure progressions are musically correct
const validateProgression = (progression, key) => {
  const scale = NOTE_MAP[key];
  return progression.every(chord => {
    const notes = chord.notes;
    return notes.every(note => scale.includes(note));
  });
};

// Generate Harmony
generateHarmony(scale, bars, spec, structure, settings) {
  const chords = [];
  const getProgression = (isBridge = false) => {
    const producerProgs = (settings.useProducerProgressions &&
      PRODUCER_PROGRESSIONS[settings.producer as keyof typeof PRODUCER_PROGRESSIONS]) ||
      [];
    const genreProgs = GENRE_PROGRESSIONS[settings.genre as keyof typeof GENRE_PROGRESSIONS] || GENRE_PROGRESSIONS['R&B']; // Fallback
    const availableProgs = producerProgs.length > 0 ? producerProgs : genreProgs;
    if (availableProgs.length === 0) {
      return { id: 'default', roman: ['i', 'iv', 'v', 'i'], name: 'Default Fallback' };
    }
    return availableProgs[Math.floor(this.random() * availableProgs.length)];
  };

  const mainProgression = getProgression();
  let bridgeProgression = getProgression(true);
  while (bridgeProgression.id === mainProgression.id &&
    (PRODUCER_PROGRESSIONS[settings.producer as keyof typeof PRODUCER_PROGRESSIONS] ||
      []).length > 1) {
    bridgeProgression = getProgression(true);
  }

  let activeProgressionName = mainProgression.name;
  for (let bar = 0; bar < bars; bar++) {
    const section = structure?.find((s: any) => bar >= s.start && bar < s.end);
    const sectionType = section?.type || 'verse';
    const currentProg = sectionType === 'bridge' ? bridgeProgression : mainProgression;
    if(sectionType === 'bridge') activeProgressionName = bridgeProgression.name;
    else activeProgressionName = mainProgression.name;
    const progression = currentProg.roman;
    const progIndex = bar % progression.length;
    const numeral = progression[progIndex];
    const degree = ROMAN_TO_DEGREE[numeral] || 0;
    const notes = [
      scale[degree % scale.length],
      scale[(degree + 2) % scale.length],
      scale[(degree + 4) % scale.length]
    ];
    if (settings.complexity > 0.4 || sectionType === 'chorus') {
      notes.push(scale[(degree + 6) % scale.length]);
    }
    if (settings.complexity > 0.8 && (settings.genre === 'Neo-Soul' || settings.genre === 'R&B')) {
      const ninth = scale[(degree + 8) % scale.length];
      if(ninth) notes.push(ninth);
    }
    const duration = (sectionType === 'bridge' && this.random() < 0.3) ? '2m' : '1m';
    const validChord = validateProgression({ notes }, settings.key);
    if (validChord) {
      chords.push({ time: `${bar}:0:0`, notes, duration, section: sectionType, velocity: 0.7 });
    }
  }
  return { harmony: chords, progressionName: activeProgressionName };
}