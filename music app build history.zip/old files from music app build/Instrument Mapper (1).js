const INSTRUMENT_MAP = {
    // Kicks
    "short_punchy_kick.wav": { group: "drums", sample: "short_punchy_kick" },
    "deep_808_kick.wav": { group: "drums", sample: "deep_808_kick" },
    
    // Snares
    "metallic_snare.wav": { group: "drums", sample: "metallic_snare" },
    "snappy_snare.wav": { group: "drums", sample: "snappy_snare" },

    // Percussion
    "finger_snap.wav": { group: "perc", sample: "finger_snaps" }, // Note: Adjust group/name to match genreSampler
    "bongo.wav": { group: "perc", sample: "bongo" },

    // Keys (These are special, as they are pitched)
    "rhodes.wav": { group: "keys", sampleNote: "C4" },
    "wurlitzer.wav": { group: "keys", sampleNote: "D4" },
    "grand_piano.wav": { group: "keys", sampleNote: "F4" },

    // Guitars
    "funk_guitar.wav": { group: "guitars", sample: "funk" },
    "soul_guitar.wav": { group: "guitars", sample: "soul" },
    
    // ... and so on for every sample file.
};