export const INSTRUMENT_LIBRARY_VST = [
  {
    type: "synth",
    name: "fm-blip",
    description: "Short FM blip with metallic overtones for Timbaland-style rhythmic accents",
    oscillator: { type: "square" },
    envelope: { attack: 0.005, decay: 0.1, sustain: 0.2, release: 0.1 },
    modulation: { type: "sine", frequency: 300 },
    genres: ["Trap-Soul", "Timbaland", "Experimental"]
  },
  {
    type: "bass",
    name: "glide-saw",
    description: "Sawtooth bass with pitch glide for drill and trap slides",
    oscillator: { type: "sawtooth" },
    envelope: { attack: 0.01, decay: 0.3, sustain: 0.7, release: 0.5 },
    glide: 0.2,
    genres: ["Drill", "Trap", "Zaytoven"]
  },
  // ... all other VST presets
];