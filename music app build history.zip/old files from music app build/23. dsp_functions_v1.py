# TIMBALAND: deep tuned kick, click transient, saturation
def timbaland_kick(frequency: float = 60.0, decay: float = 0.3, length: float = 0.6) -> np.ndarray:
  sub = sine(frequency, length) * env_adsr(length, 0.001, decay, 0.0, 0.001)
  click = square(frequency * 3, 0.05) * env_adsr(0.05, 0.001, 0.02, 0.0, 0.01)
  kick = sub + 0.15 * click
  kick = one_pole_lowpass(kick, cutoff=120.0)
  return normalize(saturate(kick, drive=0.25))

# KANYE: short truncated kick
def kanye_kick(frequency: float = 65.0, decay: float = 0.1, length: float = 0.4) -> np.ndarray:
  wave = sine(frequency, length) * env_adsr(length, 0.001, decay, 0.0, 0.001)
  n = int(decay * SR)
  wave = wave[:max(1, n)]
  wave = np.pad(wave, (0, int(length*SR)-len(wave)))
  return normalize(saturate(wave, drive=0.18))

# DJ QUIK: sine-heavy kick with triangle body
def djquik_kick(frequency: float = 70.0, decay: float = 0.4, length: float = 0.6) -> np.ndarray:
  sub = sine(frequency, length) * env_adsr(length, 0.001, decay, 0.0, 0.01)
  body = triangle(frequency * 2, length) * env_adsr(length, 0.001, decay*0.6, 0.0, 0.01) * 0.15
  kick = sub + body
  return normalize(saturate(kick, drive=0.12))

# ... (and all other producer-specific functions for snares, percussion, etc.)